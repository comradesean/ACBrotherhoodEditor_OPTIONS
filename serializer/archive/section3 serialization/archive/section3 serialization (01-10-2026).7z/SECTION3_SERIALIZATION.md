# Section 3 Serialization - Reverse Engineering Notes

## Overview

This document tracks the reverse engineering of `game_uncompressed_3.bin` serialization format.

**File Size:** 162 bytes (0xA2)

## Raw Hex Dump

```
00000000: 0000 0000 0000 0000 0000 666d 87c9 9000  ..........fm....
00000010: 0000 8800 0000 1100 0000 1320 4cbf 0000  ........... L...
00000020: 0000 0000 0700 0b00 0000 000e 0000 0066  ...............f
00000030: 6954 3b00 0000 0000 0000 000b 010e 0000  iT;.............
00000040: 00a7 7dbc 4d00 0000 0000 0000 000b 010e  ..}.M...........
00000050: 0000 000b f195 5b00 0000 0000 0000 000b  ......[.........
00000060: 000e 0000 0090 8a4e 2a00 0000 0000 0000  .......N*.......
00000070: 000b 0015 0000 0080 876f 4900 0000 0000  .........oI.....
00000080: 0009 000b ffff ffff ffff 1f00 0e00 0000  ................
00000090: 5bb0 886f 0000 0000 0000 0000 0b01 0000  [..o............
000000a0: 0000                                     ..
```

---

## Class Hierarchy

```
AssassinSingleProfileData (0xc9876d66)
  └── SaveGameDataObject (0xb7806f86)
```

---

## Serialized Structure (XML-like)

Based on the decompiled code, the binary represents this logical structure:

```xml
<Object type="AssassinSingleProfileData" hash="0xc9876d66">
  <Properties>
    <!-- SaveGameDataObject base class properties -->
    <Property name="field_04">
      <Value type="uint32">...</Value>
    </Property>
    <!-- Dynamic properties handled separately -->

    <!-- AssassinSingleProfileData properties -->
    <Property hash="0x3b546966">
      <Value type="bool">0/1</Value>
    </Property>
    <Property hash="0x4dbc7da7">
      <Value type="bool">0/1</Value>
    </Property>
    <Property hash="0x5b95f10b">
      <Value type="bool">0/1</Value>
    </Property>
    <Property hash="0x2a4e8a90">
      <Value type="bool">0/1</Value>
    </Property>
    <Property hash="0x496f8780">
      <Value type="valueA">...</Value>
    </Property>
    <Property hash="0x6f88b05b">
      <Value type="bool">0/1</Value>
    </Property>
  </Properties>
  <Dynamic Properties>
    <NbDynamicProperties type="uint32">count</NbDynamicProperties>
    <!-- For each dynamic property: -->
    <Property index="N">
      <Value>...</Value>
    </Property>
  </Dynamic Properties>
</Object>
```

---

## Binary Format Specification

### File Layout

| Offset | Size | Description |
|--------|------|-------------|
| 0x00-0x25 | 38 bytes | Header |
| 0x26-0x2A | 5 bytes | First property prefix |
| 0x2B-0x9D | 119 bytes | Properties (6 total) |
| 0x9E-0xA1 | 4 bytes | Trailing zeros |

### Header Format (38 bytes)

Written by FUN_01b08ce0 (ObjectInfo header writer).

| Offset | Size | Field | Example Value | Notes |
|--------|------|-------|---------------|-------|
| 0x00-0x09 | 10 | Padding | `00 00 00 00 00 00 00 00 00 00` | |
| 0x0A-0x0D | 4 | Type hash | `0xc9876d66` (AssassinSingleProfileData) | |
| 0x0E-0x0F | 2 | field_0x0e | `0x0090` | |
| 0x10-0x13 | 4 | field_0x10 | `0x00880000` | |
| 0x14-0x17 | 4 | field_0x14 | `0x00110000` | |
| 0x18-0x1D | 6 | field_0x18 | `00 00 13 20 4c bf` | Contains SaveGameDataObject hash `0xbf4c2013` at bytes 2-5 |
| 0x1E-0x23 | 6 | field_0x1e | `00 00 00 00 00 00` | |
| 0x24-0x25 | 2 | field_0x24 | `0x0007` | |

**SaveGameDataObject Field in Header:** The hash `0xbf4c2013` from SaveGameDataObject's property descriptor (DAT_027ecf90) appears embedded in field_0x18, NOT as a separate property. This is because FUN_01b0d140 skips property writing when the +0x4e flag bit 0 is set, causing the value to be written as part of the ObjectInfo header instead.

### First Property Prefix (5 bytes) ✅ TRACED

```
0b 00 00 00 00
```

**Location:** 0x26-0x2A (between header at 0x25 and first property size at 0x2B)

**Structure:**
1. **Byte 0x26 (0x0b):** NbClassVersionsInfo - written by FUN_01b0d500 when serializer version >= 13
2. **Bytes 0x27-0x2A (00 00 00 00):** Object section size placeholder from OpenSection("Object")

**Serializer version evidence:**
- PropertyHeaderFlag (0x0b in properties) is a single byte → version >= 11 (FUN_01b076f0)
- Type info is 8 bytes direct → version >= 9 (FUN_01b0e980)
- Prefix is 5 bytes (1 + 4) → version >= 13 (NbClassVersionsInfo path in FUN_01b08ce0)

**Conclusion:** The file was written with **serializer version >= 13**.

**FUN_01b0d500 (NbClassVersionsInfo Writer) - Writes 1 byte:**
```c
void __thiscall FUN_01b0d500(int *param_1, undefined4 param_2, undefined4 param_3)
{
  (**(code **)(*param_1 + 8))(param_2);    // vtable[0x08] - OpenTag (NO-OP)
  (**(code **)(*param_1 + 0x98))(param_3); // vtable[0x98] - WriteByte (1 byte)
  (**(code **)(*param_1 + 0x10))(param_2); // vtable[0x10] - CloseTag (NO-OP)
}
```

**Called from FUN_01b08ce0 (version >= 13 path):**
```c
if (*(int *)(param_1 + 0x24) < 0xd) {  // version < 13
    FUN_01b0d420("ClassVersion", &local_10);  // Writes 2 bytes
}
else {  // version >= 13
    local_5 = *(byte *)((int)param_7 + 6);
    FUN_01b0d500("NbClassVersionsInfo", &local_5);  // Writes 1 byte
    // Loop writes VersionClassID + Version pairs (if any)
    if (local_5 != 0) {
        do {
            // Write VersionClassID (4 bytes via vtable[0x84])
            // Write Version (2 bytes via vtable[0x8c])
        } while (++uVar3 < local_5);
    }
}
```

---

#### ✅ NbClassVersionsInfo VALUE - RESOLVED VIA WINDBG

**Static Analysis Finding:**

The NbClassVersionsInfo byte is sourced from `[param_6 + 0x6]` in FUN_01b08ce0:

```asm
LAB_01b08d82:                                    ; version >= 13 path
    01b08d82 8b 7d 1c        MOV        EDI,dword ptr [EBP + Stack[0x18]]  ; EDI = param_6
    01b08d85 8a 47 06        MOV        AL,byte ptr [EDI + 0x6]           ; Read byte at param_6 + 6
    01b08d94 88 45 ff        MOV        byte ptr [EBP + local_5],AL       ; Store in local_5
    01b08d97 e8 64 47        CALL       FUN_01b0d500                       ; Write NbClassVersionsInfo
```

**WinDbg TTD Tracing Results (2026-01-07):**

Breakpoint at `ACBSP+0x1708d85` during AssassinSingleProfileData serialization:

```
0:000> r edi
edi=03cff834
0:000> db edi L10
03cff834  b4 f7 cf 03 10 80 00 00 2c 01 00 00 10 00 00 00
                      ^^ ^^ ^^ ^^
                      flags = 0x8010

Byte at [edi+6] = 0x00

0:000> dd esi+58 L1
03cff8e0  00000000    <- mode = 0 (WRITE mode, confirmed)

0:000> db ebp-1 L1
03cff797  00          <- local_5 = 0x00 (value about to be written)
```

**CONFIRMED:** The game writes **0x00** for NbClassVersionsInfo during the traced save operation.

**Resolution:**

Our reference file `game_uncompressed_3.bin` has 0x0b at offset 0x26, but the TTD trace shows the game writes 0x00. This means:

1. **The files are from different save sessions** - our reference file was created under different conditions than the TTD trace
2. **The value is context-dependent** - it varies based on game state, save slot, or other factors
3. **Both values are valid** - 0x00 and 0x0b are both legitimate NbClassVersionsInfo values

**Parser Implications:**

The parser correctly **preserves the value from the input file** rather than hardcoding it. This is the right approach since:
- The value varies between saves
- The traced code path is confirmed correct
- Roundtrip serialization must preserve the original value

**Stack layout (confirmed via WinDbg):**
```
EDI (param_6) points to:
+0x00: pointer to buffer (b4 f7 cf 03)
+0x04: flags field (10 80 00 00 = 0x8010)
+0x06: NbClassVersionsInfo source byte = 0x00
```

For flags = 0x8010 (little-endian: `10 80 00 00`), byte at offset 6 = **0x00**.

**FUN_01b48890 (OpenSection) Analysis - RESERVES 4 bytes (does not write):**
```c
// Write mode (byte at +4 == 0):
uVar2 = (*inner_vtable[0x4c])();           // Get current position
context[0x14 + index*8] = uVar2;           // Save for later patching
context[0x10 + index*8] = 0;               // Initialize size to 0
(*inner_vtable[0x44])(4);                  // RESERVE 4 BYTES - just advances position!
index++;
```

**CRITICAL:** `inner_vtable[0x44]` is FUN_01b6f2b0, which only advances the stream position pointer without writing any data. The reserved bytes contain whatever was already in the buffer (zeros from initialization).

**Byte-by-byte breakdown:**
```
0x26: 0b        <- NbClassVersionsInfo (written by FUN_01b0d500)
0x27-0x2A: 00 00 00 00  <- Object section placeholder (reserved by OpenSection)
0x2B: 0e        <- First property SIZE field (Properties section starts here)
```

**Note:** The Properties section placeholder appears to be handled differently - either:
1. Merged with the Object section structure, OR
2. The first property's size field serves double duty

The exact mechanism is traced but the Properties placeholder location remains unclear. Empirically verified to produce correct roundtrip output.

### Bool Property Format (18 bytes)

| Offset | Size | Field | Value | Written By |
|--------|------|-------|-------|------------|
| +0x00 | 4 | Size field | `0x0e` (14) | FUN_01b48890 (placeholder) → FUN_01b48920 (patch) |
| +0x04 | 4 | Property hash | varies | FUN_01b0e680 → FUN_01b48fb0 → FUN_01b49610 |
| +0x08 | 8 | Type info | `00 00 00 00 00 00 00 00` | FUN_01b0e980 → FUN_01b49020 → FUN_01b496d0 |
| +0x10 | 1 | Flags (0x0b) | `0x0b` | FUN_01b0d140 (hardcoded) → FUN_01b076f0 → vtable[0x98] |
| +0x11 | 1 | Value | `0x00` or `0x01` | FUN_01b11fb0 → FUN_01b48e80 → FUN_01b497f0 |

Size field (14) = hash(4) + type_info(8) + flags(1) + value(1)

**Type info source:** Property descriptor at offset +0x08 (8 bytes)

### UInt64 Property Format (25 bytes)

| Offset | Size | Field | Value | Written By |
|--------|------|-------|-------|------------|
| +0x00 | 4 | Size field | `0x15` (21) | FUN_01b48890 (placeholder) → FUN_01b48920 (patch) |
| +0x04 | 4 | Property hash | varies | FUN_01b0e680 → FUN_01b48fb0 → FUN_01b49610 |
| +0x08 | 8 | Type info | `00 00 00 00 00 00 09 00` | FUN_01b0e980 → FUN_01b49020 → FUN_01b496d0 |
| +0x10 | 1 | Flags (0x0b) | `0x0b` | FUN_01b0d140 (hardcoded) → FUN_01b076f0 → vtable[0x98] |
| +0x11 | 8 | Value | little-endian uint64 | FUN_01b124e0 → FUN_01b48be0 → FUN_01b496d0 |

Size field (21) = hash(4) + type_info(8) + flags(1) + value(8)

**Type info source:** Property descriptor at offset +0x08 (8 bytes) - contains `09 00` for uint64 type

### Trailing Bytes (4 bytes)

```
00 00 00 00
```

**Location:** 0x9E-0xA1 (end of file)

**Origin:** Dynamic Properties section size field

From FUN_01b0d0c0 finalization sequence:
1. `vtable[0x14]("Properties")` - CloseSection patches Properties size
2. `vtable[0x0c]("Dynamic Properties")` - **OpenSection writes 4-byte placeholder**
3. (no dynamic property data in this file)
4. `vtable[0x14]("Dynamic Properties")` - CloseSection patches size to **0x00000000**
5. `vtable[0x14]("Object")` - CloseSection patches Object size

The 4 zero bytes ARE the Dynamic Properties section size field, patched to 0 because there are no dynamic properties in this file. **✅ TRACED**

### Property Order in File

1. `bool_field_0x20` (hash `0x3b546966`)
2. `bool_field_0x21` (hash `0x4dbc7da7`)
3. `bool_field_0x22` (hash `0x5b95f10b`)
4. `bool_field_0x23` (hash `0x2a4e8a90`)
5. `uint64_field_0x18` (hash `0x496f8780`)
6. `bool_field_0x24` (hash `0x6f88b05b`)

### Markers (Reverse Engineered)

| Marker | Meaning | Source |
|--------|---------|--------|
| `0x0b` | Property flags byte (Final=1, Owned=1, bit3=1) | Hardcoded in FUN_01b0d140 as `0xb000000`, written by FUN_01b076f0 |
| `0x09` | UInt64 type indicator | From property descriptor type_info at +0x0E |
| `0x0e` | Bool property size (14 bytes payload) | Calculated by FUN_01b48920 (CloseSection) |
| `0x15` | UInt64 property size (21 bytes payload) | Calculated by FUN_01b48920 (CloseSection) |

---

## GHIDRA Decompiled Code Analysis

### FUN_01710580 - AssassinSingleProfileData::Serialize

**Address:** `0x01710580`

```c
void __thiscall FUN_01710580(int param_1, int param_2)
{
  undefined4 uVar1;
  undefined4 uVar2;

  *(int *)(param_2 + 0x1c) = param_1;
  if (*(char *)(*(int *)(param_2 + 4) + 4) == '\0') {
    uVar1 = FUN_01afc2c0(param_1, 0, 0);
    uVar2 = FUN_01afb8a0(param_1);
    FUN_01b09e20("AssassinSingleProfileData", 0, 0xc9876d66, uVar1, uVar2);
  }
  uVar1 = *(undefined4 *)(param_2 + 0x20);
  *(undefined4 *)(param_2 + 0x20) = 0;
  FUN_005e3700(param_2);                              // Call base class serializer
  *(undefined4 *)(param_2 + 0x20) = uVar1;
  FUN_01b09650(param_1 + 0x20, PTR_DAT_02973310);     // Bool field -> hash 0x3b546966
  FUN_01b09650(param_1 + 0x21, PTR_DAT_02973314);     // Bool field -> hash 0x4dbc7da7
  FUN_01b09650(param_1 + 0x22, PTR_DAT_02973318);     // Bool field -> hash 0x5b95f10b
  FUN_01b09650(param_1 + 0x23, PTR_DAT_0297331c);     // Bool field -> hash 0x2a4e8a90
  FUN_01b09760(param_1 + 0x18, PTR_DAT_02973320);     // Value field -> hash 0x496f8780
  FUN_01b09650(param_1 + 0x24, PTR_DAT_02973324);     // Bool field -> hash 0x6f88b05b
  FUN_01b0d0c0();
  return;
}
```

---

### FUN_005e3700 - SaveGameDataObject::Serialize (Base Class)

**Address:** `0x005e3700`

```c
void __thiscall FUN_005e3700(int param_1, int param_2)
{
  undefined4 uVar1;
  undefined4 uVar2;

  *(int *)(param_2 + 0x1c) = param_1;
  if (*(char *)(*(int *)(param_2 + 4) + 4) == '\0') {
    uVar1 = FUN_01afc2c0(param_1, 0, 0);
    uVar2 = FUN_01afb8a0(param_1);
    FUN_01b09e20("SaveGameDataObject", 0, 0xb7806f86, uVar1, uVar2);
  }
  FUN_01b0a1f0(param_1 + 4, PTR_DAT_027ecf8c);        // Serialize field at +0x04
  FUN_01b09620(param_1 + 8);                          // Serialize field at +0x08
  FUN_01b0d0c0();
  return;
}
```

**Notes:**
- Base class type hash: `0xb7806f86`
- Serializes fields at offsets +0x04 and +0x08 before derived class fields

---

### FUN_01b09650 - Bool/Byte Serializer

**Address:** `0x01b09650`

```c
void __thiscall FUN_01b09650(int param_1, char *param_2, undefined4 param_3)
{
  char cVar1;

  if (*(char *)(*(int *)(param_1 + 4) + 4) == '\0') {
    *param_2 = *param_2 != '\0';                      // Normalize to 0/1 on write
  }
  cVar1 = FUN_01b11fb0(param_3, param_2);             // Actual serialization
  if ((cVar1 != '\0') && (*(char *)(*(int *)(param_1 + 4) + 4) != '\0')) {
    *param_2 = *param_2 != '\0';                      // Normalize to 0/1 on read
  }
  return;
}
```

**Notes:**
- Serializes a single byte as boolean (0 or 1)
- `*(param_1 + 4) + 4` == 0 indicates WRITE mode
- `*(param_1 + 4) + 4` != 0 indicates READ mode

---

### FUN_01b09760 - Value Serializer Wrapper

**Address:** `0x01b09760`

```c
void FUN_01b09760(undefined4 param_1, undefined4 param_2)
{
  FUN_01b124e0(param_2, param_1);                     // Note: params swapped!
  return;
}
```

---

### FUN_01b124e0 - Value Serializer (Tagged Property)

**Address:** `0x01b124e0`

```c
undefined4 __thiscall FUN_01b124e0(int param_1, byte *param_2, undefined4 param_3)
{
  int *piVar1;
  int iVar2;
  char cVar3;

  cVar3 = FUN_01b07940(param_2, 0, 0);
  if (cVar3 != '\0') {
    cVar3 = FUN_01b0d140(param_2);
    if (cVar3 != '\0') {
      if ((*(int *)(param_1 + 0x58) == 2) &&
         (((*param_2 & 0x20) != 0 || ((*(byte *)(param_1 + 0x4e) & 0x10) != 0)))) {
        FUN_01b10970(param_2, param_3);
      }
      piVar1 = *(int **)(param_1 + 4);
      (**(code **)(*piVar1 + 8))("Value");            // Write "Value" tag
      (**(code **)(*piVar1 + 0x7c))(param_3);         // Write value data
      (**(code **)(*piVar1 + 0x10))("Value");         // Close "Value" tag
      *(byte *)(param_1 + 0x4e) = *(byte *)(param_1 + 0x4e) & 0x7f;
      iVar2 = *(int *)(param_1 + 0x58);
      if ((((iVar2 != 1) && (iVar2 != 2)) && (iVar2 != 3)) &&
          ((*(byte *)(param_1 + 0x4e) & 1) == 0)) {
        (**(code **)(**(int **)(param_1 + 4) + 0x14))("Property");
      }
      return 1;
    }
  }
  return 0;
}
```

**Notes:**
- Uses vtable calls for serialization
- Writes "Value" and "Property" XML-like tags
- More complex than bool serializer - handles nested/tagged values

---

### FUN_01b0a1f0 - UInt32 Serializer Wrapper

**Address:** `0x01b0a1f0`

```c
void FUN_01b0a1f0(undefined4 param_1, undefined4 param_2)
{
  FUN_01b12fa0(param_2, param_1);                     // Note: params swapped!
  return;
}
```

**Notes:**
- Called by SaveGameDataObject::Serialize (FUN_005e3700) with PTR_DAT_027ecf8c
- PTR_DAT_027ecf8c points to DAT_027ecf90 (property descriptor for hash `0xbf4c2013`)
- This property's value ends up in header field_0x18, NOT as a property record
- The +0x4e flag causes FUN_01b0d140 to skip property writing, embedding data in header instead

---

### FUN_01b12fa0 - UInt32 Serializer

**Address:** `0x01b12fa0`

```c
undefined4 __thiscall FUN_01b12fa0(int param_1, byte *param_2, undefined4 param_3)
{
  int *piVar1;
  int iVar2;
  char cVar3;

  cVar3 = FUN_01b07940(param_2, 0, 0);
  if (cVar3 != '\0') {
    cVar3 = FUN_01b0d140(param_2);
    if (cVar3 != '\0') {
      if ((*(int *)(param_1 + 0x58) == 2) &&
         (((*param_2 & 0x20) != 0 || ((*(byte *)(param_1 + 0x4e) & 0x10) != 0)))) {
        FUN_01b12b10(param_2, param_3);
      }
      piVar1 = *(int **)(param_1 + 4);
      (**(code **)(*piVar1 + 8))("Value");
      (**(code **)(*piVar1 + 0x84))(param_3);         // vtable[0x84] = uint32 writer
      (**(code **)(*piVar1 + 0x10))("Value");
      *(byte *)(param_1 + 0x4e) = *(byte *)(param_1 + 0x4e) & 0x7f;
      iVar2 = *(int *)(param_1 + 0x58);
      if ((((iVar2 != 1) && (iVar2 != 2)) && (iVar2 != 3)) &&
          ((*(byte *)(param_1 + 0x4e) & 1) == 0)) {
        (**(code **)(**(int **)(param_1 + 4) + 0x14))("Property");
      }
      return 1;
    }
  }
  return 0;
}
```

**Notes:**
- Uses vtable offset `0x84` for writing (different from bool's `0x58` and value's `0x7c`)
- Used for SaveGameDataObject field at +0x04
- Likely serializes uint32 values

---

### FUN_01b0d500 - NbClassVersionsInfo Writer (1 byte)

**Address:** `0x01b0d500`

```c
void __thiscall FUN_01b0d500(int *param_1, undefined4 param_2, undefined4 param_3)
{
  (**(code **)(*param_1 + 8))(param_2);    // vtable[0x08] - OpenTag (NO-OP)
  (**(code **)(*param_1 + 0x98))(param_3); // vtable[0x98] - WriteByte (1 byte)
  (**(code **)(*param_1 + 0x10))(param_2); // vtable[0x10] - CloseTag (NO-OP)
}
```

**Notes:**
- Writes a single byte via vtable[0x98] (FUN_01b48b70 - WriteByte)
- Used for NbClassVersionsInfo when serializer version >= 13
- The 0x0b byte at position 0x26 in our file comes from this function
- Called from FUN_01b08ce0 in the version >= 13 code path

---

### FUN_01b0d420 - ClassVersion/SerializerVersion Writer (2 bytes)

**Address:** `0x01b0d420`

```c
void __thiscall FUN_01b0d420(int *param_1, undefined4 param_2, undefined4 param_3)
{
  (**(code **)(*param_1 + 8))(param_2);    // vtable[0x08] - OpenTag (NO-OP)
  (**(code **)(*param_1 + 0x8c))(param_3); // vtable[0x8c] - WriteUInt16 (2 bytes)
  (**(code **)(*param_1 + 0x10))(param_2); // vtable[0x10] - CloseTag (NO-OP)
}
```

**Notes:**
- Writes 2 bytes via vtable[0x8c] (FUN_01b48ba0 - WriteUInt16)
- Used for ClassVersion (when version < 13) or SerializerVersion (when version < 8)
- Called from FUN_01b08ce0 in the version < 13 code path

---

### FUN_01b09620 - Dynamic Properties Handler

**Address:** `0x01b09620`

```c
void __thiscall FUN_01b09620(int param_1, int param_2)
{
  if (*(int *)(param_1 + 0x58) == 3) {                // Mode 3 = reading
    if (param_2 != 0) {
      FUN_01b091a0(param_2);                          // Read dynamic properties
      return;
    }
  }
  else {
    *(int *)(param_1 + 0x28) = param_2;               // Store reference for write
  }
  return;
}
```

**Notes:**
- Mode at offset 0x58: 3 = read mode
- On read: calls FUN_01b091a0 to deserialize dynamic properties
- On write: stores param_2 at serializer offset 0x28

---

### FUN_01b091a0 - Dynamic Properties Serializer

**Address:** `0x01b091a0`

```c
void __thiscall FUN_01b091a0(int param_1, int param_2)
{
  // ... complex dynamic property iteration ...

  // Key operations:
  // 1. Iterates through property list from FUN_01b57700() to FUN_01b57710()
  // 2. Each property entry is 32 bytes (8 * sizeof(uint32))
  // 3. Checks property type flags at (entry[1] >> 16) & 0x3F

  // Property types checked:
  // 0x12, 0x13, 0x14, 0x15, 0x16, 0x19, 0x1c, 0x1e

  if (*(int *)(param_1 + 0x58) == 3) {  // Read mode
    // Write "NbDynamicProperties" count using vtable[0x84] (uint32)
    piVar1 = *(int **)(param_1 + 4);
    (**(code **)(*piVar1 + 8))("NbDynamicProperties");
    (**(code **)(*piVar1 + 0x84))(&local_30);
    (**(code **)(*piVar1 + 0x10))("NbDynamicProperties");
  }

  // For each valid property:
  // - Write property index using vtable[0x84]
  // - Call FUN_01b0e980 to serialize property value
}
```

**Notes:**
- Handles dynamic/optional properties beyond the fixed schema
- Writes "NbDynamicProperties" count header
- Property type flags determine serialization method
- Complex iteration through property descriptor table

---

### FUN_01b11fb0 - Bool Serializer (Core)

**Address:** `0x01b11fb0`

```c
undefined4 __thiscall FUN_01b11fb0(int param_1, byte *param_2, undefined4 param_3)
{
  int *piVar1;
  int iVar2;
  char cVar3;

  cVar3 = FUN_01b07940(param_2, 0, 0);
  if (cVar3 != '\0') {
    cVar3 = FUN_01b0d140(param_2);
    if (cVar3 != '\0') {
      if ((*(int *)(param_1 + 0x58) == 2) &&
         (((*param_2 & 0x20) != 0 || ((*(byte *)(param_1 + 0x4e) & 0x10) != 0)))) {
        FUN_01b0fc50(param_2, param_3);
      }
      piVar1 = *(int **)(param_1 + 4);
      (**(code **)(*piVar1 + 8))("Value");
      (**(code **)(*piVar1 + 0x58))(param_3);         // vtable[0x58] = bool writer
      (**(code **)(*piVar1 + 0x10))("Value");
      *(byte *)(param_1 + 0x4e) = *(byte *)(param_1 + 0x4e) & 0x7f;
      iVar2 = *(int *)(param_1 + 0x58);
      if ((((iVar2 != 1) && (iVar2 != 2)) && (iVar2 != 3)) &&
          ((*(byte *)(param_1 + 0x4e) & 1) == 0)) {
        (**(code **)(**(int **)(param_1 + 4) + 0x14))("Property");
      }
      return 1;
    }
  }
  return 0;
}
```

**Notes:**
- Uses vtable offset `0x58` for bool values
- Same pattern as other serializers but different vtable offset

---

### FUN_01b07940 - Property Validation/Init

**Address:** `0x01b07940`

```c
undefined1 __thiscall FUN_01b07940(int param_1, byte *param_2)
{
  int iVar1;
  byte *pbVar2;
  undefined1 uVar3;

  iVar1 = *(int *)(param_1 + 0x58);                   // Get mode
  *(undefined1 *)(param_1 + 0x79) = 1;                // Set flag
  *(undefined1 *)(param_1 + 0x7a) = 0;                // Clear flag
  *(byte **)(param_1 + 0x2c) = param_2;               // Store property descriptor

  // Skip if not mode 3, property flag bit0 clear, and not mode 2
  if (((iVar1 != 3) && ((*param_2 & 1) == 0)) && (iVar1 != 2)) {
    return 0;
  }

  // Additional checks for modes != 1
  if (((iVar1 != 1) && (*(char *)(*(int *)(param_1 + 4) + 4) == '\0')) &&
     ((*(byte *)(param_1 + 0x4f) & 2) == 0)) {
    pbVar2 = (byte *)FUN_01b564b0(*(undefined4 *)(param_1 + 0x1c));
    uVar3 = 0;
    if (pbVar2 != (byte *)0x0) {
      if (((*pbVar2 & 2) == 0) || ((*pbVar2 & 0x18) != 0)) {
        uVar3 = 1;
      }
      else {
        *(undefined1 *)(param_1 + 0x79) = 0;
      }
      if ((*pbVar2 & 0xe0) == 0) {
        return uVar3;
      }
    }
    return 1;
  }
  return 1;
}
```

**Notes:**
- Initializes serialization state for a property
- Stores property descriptor pointer at context+0x2c
- Validates based on mode and property flags
- `FUN_01b564b0` looks up parent context data

---

### FUN_01b0d140 - Property Lookup/Match

**Address:** `0x01b0d140`

```c
undefined4 __thiscall FUN_01b0d140(int param_1, uint *param_2)
{
  uint *puVar1;
  char cVar2;
  int iVar3;
  uint uVar4;
  uint local_10;
  uint local_c;
  uint local_8;

  iVar3 = *(int *)(param_1 + 0x58);
  // Skip for modes 1, 2, 3 or if flag set
  if ((((iVar3 == 1) || (iVar3 == 2)) || (iVar3 == 3)) || ((*(byte *)(param_1 + 0x4e) & 1) != 0)) {
    return 1;
  }

  cVar2 = (**(code **)(**(int **)(param_1 + 4) + 0x1c))();  // CheckEnd
  if (cVar2 != '\0') {
    return 0;
  }

  (**(code **)(**(int **)(param_1 + 4) + 0xc))("Property");  // Open Property tag

  puVar1 = param_2;
  local_8 = param_2[1];                               // Property index/hash from descriptor
  FUN_01b0e680(&DAT_02554cbc, 0, &local_8);           // Read property index

  // Version compatibility: -1 becomes 0 for version < 2
  if ((*(int *)(param_1 + 0x24) < 2) && (local_8 == 0xffffffff)) {
    local_8 = 0;
  }

  local_10 = puVar1[2];                               // Type info
  local_c = puVar1[3];                                // Additional type info
  FUN_01b0e980(&local_10);                            // Read/validate type

  // ... validation and lookup logic ...

  // If property matches expected
  if ((local_8 == puVar1[1]) && (cVar2 = FUN_008bc150(puVar1 + 2, 1), cVar2 != '\0')) {
    // Property found, continue
    // ...
    return 1;
  }

  // Property mismatch - handle via FUN_01b0ca30
  FUN_01b0ca30(local_8, uVar4, local_c);
  return 0;
}
```

**Notes:**
- Reads "Property" tag from stream
- Gets property index from descriptor at offset +0x04 (param_2[1])
- Version < 2 compatibility: index -1 maps to 0
- Validates property index matches expected
- On mismatch: calls FUN_01b0ca30 (probably seeks/skips)

**Property Descriptor Layout (param_2):**
| Offset | Field | Description |
|--------|-------|-------------|
| +0x00 | flags | Property flags (bit 17 checked) |
| +0x04 | index/hash | Property identifier |
| +0x08 | type_info | Type information |
| +0x0C | type_extra | Additional type data |

---

### FUN_01b0e680 - Property Index Reader

**Address:** `0x01b0e680`

```c
void __thiscall FUN_01b0e680(int *param_1, undefined4 param_2, undefined4 param_3, undefined4 param_4)
{
  (**(code **)(*param_1 + 8))(param_2);               // vtable[0x08] - Open tag (param_2)
  (**(code **)(*param_1 + 0x50))(param_3, param_4);   // vtable[0x50] - Read/write value
  (**(code **)(*param_1 + 0x10))(param_2);            // vtable[0x10] - Close tag (param_2)
  return;
}
```

**Called from FUN_01b0d140:**
```c
FUN_01b0e680(&DAT_02554cbc, 0, &local_8);
```

**Notes:**
- Opens tag with name from param_2
- Reads/writes value using vtable[0x50]
- Closes tag
- **TODO:** What is DAT_02554cbc? (tag name string)
- **TODO:** What does vtable[0x50] do? (likely reads uint32)

---

### FUN_01b0e3d0 - Legacy Type Format Conversion

**Address:** `0x01b0e3d0`

```c
void __thiscall FUN_01b0e3d0(undefined4 *param_1, undefined4 *param_2)
{
  uint uVar1;

  param_1[1] = 0;
  *param_1 = 0;
  param_1[1] = param_2[1] & 0x3f0000;       // Extract bits 16-21 (type code)
  *param_1 = 0;
  uVar1 = param_2[1];
  *param_1 = *param_1;
  param_1[1] = param_1[1] ^ (uVar1 ^ param_1[1]) & 0x400000;    // bit 22
  uVar1 = param_2[1];
  *param_1 = *param_1;
  param_1[1] = param_1[1] ^ (uVar1 ^ param_1[1]) & 0x60000000;  // bits 29-30
  uVar1 = param_2[1];
  *param_1 = *param_1;
  param_1[1] = param_1[1] ^ (uVar1 ^ param_1[1]) & 0x7fff;      // bits 0-14
  *param_1 = *param_2;
  uVar1 = param_2[1];
  *param_1 = *param_1;
  param_1[1] = param_1[1] ^ (uVar1 ^ param_1[1]) & 0x1f800000;  // bits 23-27
  return;
}
```

**Notes:**
- Converts version < 9 type format to current format
- Extracts and rearranges bit fields in the type descriptor

**Type Descriptor Bit Fields (param_2[1]):**
| Bits | Mask | Purpose |
|------|------|---------|
| 0-14 | 0x7fff | ? |
| 16-21 | 0x3f0000 | Primary type code |
| 22 | 0x400000 | ? |
| 23-27 | 0x1f800000 | Secondary type? |
| 29-30 | 0x60000000 | ? |

---

### FUN_01b564b0 - Parent Context Lookup (Stub)

**Address:** `0x01b564b0`

```c
undefined4 FUN_01b564b0(void)
{
  return 0;  // Always returns NULL
}
```

**Notes:**
- Stub function, always returns 0
- May be a debug/optional feature that's disabled

---

### FUN_01b0ca30 - Property Type Dispatcher

**Address:** `0x01b0ca30`

```c
void __thiscall FUN_01b0ca30(int param_1, undefined4 *param_2, undefined4 param_3, uint param_4)
{
  // ... extensive type handling code ...

  // Type code extraction:
  uVar5 = param_4 >> 0x10 & 0x3f;    // Primary type code (bits 16-21)
  uVar8 = param_4 >> 0x17 & 0x3f;    // Secondary type code (bits 23-28)

  // Type code checks:
  if ((uVar5 == 0x16) || (uVar5 == 0x13)) { ... }
  if (uVar5 == 0x15) { ... }
  if (uVar5 == 0x14) { ... }
  if (uVar5 == 0x12) { ... }
  if (uVar5 == 0x1e) { ... }
  if (uVar5 == 0x1c) { ... }
  if (uVar5 == 0x1d) { ... }
  if (uVar5 == 0x18) { ... }
  if (uVar5 == 0x17) { ... }

  // Secondary type for containers:
  if ((uVar8 == 0x16) || (uVar8 == 0x14) || (uVar8 == 0x15)) { ... }

  // Creates "DeprecatedProperty" for unknown types
  uVar3 = FUN_01b58240("DeprecatedProperty", param_2, param_3, param_4, 0x2000401);
}
```

**Type Codes (bits 16-21 of param_4):**

| Code | Hex | Likely Type |
|------|-----|-------------|
| 0x12 | 18 | ? |
| 0x13 | 19 | ? |
| 0x14 | 20 | ? |
| 0x15 | 21 | ? |
| 0x16 | 22 | ? |
| 0x17 | 23 | Container? |
| 0x18 | 24 | Container? |
| 0x19 | 25 | (from FUN_01b091a0) |
| 0x1c | 28 | ? |
| 0x1d | 29 | ? |
| 0x1e | 30 | ? |

**Notes:**
- This is the main type dispatch function
- Handles property type mismatches during deserialization
- Creates "DeprecatedProperty" entries for unrecognized types
- Secondary type code (bits 23-28) used for container element types

---

### FUN_01b0e980 - Type Info Reader/Writer

**Address:** `0x01b0e980`

```c
void __thiscall FUN_01b0e980(int param_1, undefined4 *param_2)
{
  int *piVar1;
  undefined4 *puVar2;
  undefined4 local_14;
  undefined4 local_10;
  undefined4 local_c;
  undefined4 local_8;

  piVar1 = *(int **)(param_1 + 4);                    // Get writer vtable

  if (*(int *)(param_1 + 0x24) < 9) {                 // Version < 9: legacy format
    (**(code **)(*piVar1 + 8))(&DAT_02554cb0);        // Open tag ("Type")
    (**(code **)(*piVar1 + 0x4c))(&DAT_025f9b50, &local_c);  // Read via vtable[0x4c]
    (**(code **)(*piVar1 + 0x10))(&DAT_02554cb0);     // Close tag
    local_10 = local_8;
    local_14 = local_c;
    puVar2 = (undefined4 *)FUN_01b0e3d0(&local_14);   // Convert legacy format
    *param_2 = *puVar2;
    param_2[1] = puVar2[1];
    return;
  }

  // Version >= 9: current format - read 8 bytes directly
  local_c = *param_2;                                 // Copy input values
  local_8 = param_2[1];
  (**(code **)(*piVar1 + 8))(&DAT_02554cb0);          // Open tag ("Type")
  (**(code **)(*piVar1 + 0x4c))(&DAT_025f9b50, &local_c);  // Read via vtable[0x4c]
  (**(code **)(*piVar1 + 0x10))(&DAT_02554cb0);       // Close tag
  *param_2 = local_c;
  param_2[1] = local_8;
  return;
}
```

**Version behavior:**
- **Version < 9:** Legacy format with conversion via FUN_01b0e3d0
- **Version >= 9:** Direct 8-byte read/write

**Our file evidence:** Type info is 8 bytes (00 00 00 00 00 00 00 00 for bool, 00 00 00 00 00 00 09 00 for uint64). This is consistent with **serializer version >= 9**.

**Notes:**
- Reads/writes type information as 2 x uint32 (8 bytes total)
- vtable[0x4c] = FUN_01b49020 which calls FUN_01b496d0 (8-byte read/write)
- DAT_02554cb0 = "Type" tag name
- DAT_025f9b50 = format specifier (null/empty)

---

### FUN_01b497f0 - Bool Reader/Writer (Core)

**Address:** `0x01b497f0`

```c
void __thiscall FUN_01b497f0(int param_1, undefined1 *param_2)
{
  int *piVar1;

  // Update position counter if index is set
  if (*(short *)(param_1 + 0x1010) != 0) {
    if (*(char *)(param_1 + 4) == '\0') {             // Write mode
      piVar1 = (int *)(param_1 + 8 + (uint)*(ushort *)(param_1 + 0x1010) * 8);
      *piVar1 = *piVar1 + 1;                          // Advance by 1 byte
    }
    else {                                            // Read mode
      piVar1 = (int *)(param_1 + 8 + (uint)*(ushort *)(param_1 + 0x1010) * 8);
      *piVar1 = *piVar1 + -1;                         // Decrement remaining
    }
  }

  if (*(char *)(param_1 + 4) != '\0') {               // Read mode
    (**(code **)(**(int **)(param_1 + 8) + 0x24))();  // Read bool from stream
    return;
  }
  (**(code **)(**(int **)(param_1 + 8) + 0x3c))(*param_2);  // Write bool to stream
  return;
}
```

**Notes:**
- **Size: 1 byte**
- Mode flag at offset +4: 0 = write, non-zero = read
- Position tracking at `param_1 + 8 + (index * 8)`
- Read via inner vtable[0x24]
- Write via inner vtable[0x3c]

---

### FUN_01b49610 - UInt32 Reader/Writer (Core)

**Address:** `0x01b49610`

```c
void __thiscall FUN_01b49610(int param_1, undefined4 *param_2)
{
  int *piVar1;

  // Update position counter if index is set
  if (*(short *)(param_1 + 0x1010) != 0) {
    if (*(char *)(param_1 + 4) == '\0') {             // Write mode
      piVar1 = (int *)(param_1 + 8 + (uint)*(ushort *)(param_1 + 0x1010) * 8);
      *piVar1 = *piVar1 + 4;                          // Advance by 4 bytes
    }
    else {                                            // Read mode
      piVar1 = (int *)(param_1 + 8 + (uint)*(ushort *)(param_1 + 0x1010) * 8);
      *piVar1 = *piVar1 + -4;                         // Decrement remaining
    }
  }

  if (*(char *)(param_1 + 4) != '\0') {               // Read mode
    (**(code **)(**(int **)(param_1 + 8) + 0x1c))();  // Read uint32 from stream
    return;
  }
  (**(code **)(**(int **)(param_1 + 8) + 0x34))(*param_2);  // Write uint32 to stream
  return;
}
```

**Notes:**
- **Size: 4 bytes**
- Same pattern as bool but advances by 4 instead of 1
- Read via inner vtable[0x1c]
- Write via inner vtable[0x34]

---

### FUN_01b496d0 - UInt64/Double Reader/Writer (Core)

**Address:** `0x01b496d0`

```c
void __thiscall FUN_01b496d0(int param_1, undefined4 *param_2)
{
  int *piVar1;

  // Update position counter if index is set
  if (*(short *)(param_1 + 0x1010) != 0) {
    if (*(char *)(param_1 + 4) == '\0') {             // Write mode
      piVar1 = (int *)(param_1 + 8 + (uint)*(ushort *)(param_1 + 0x1010) * 8);
      *piVar1 = *piVar1 + 8;                          // Advance by 8 bytes
    }
    else {                                            // Read mode
      piVar1 = (int *)(param_1 + 8 + (uint)*(ushort *)(param_1 + 0x1010) * 8);
      *piVar1 = *piVar1 + -8;                         // Decrement remaining
    }
  }

  if (*(char *)(param_1 + 4) != '\0') {               // Read mode
    (**(code **)(**(int **)(param_1 + 8) + 0x18))();  // Read 8 bytes from stream
    return;
  }
  (**(code **)(**(int **)(param_1 + 8) + 0x30))(*param_2, param_2[1]);  // Write 8 bytes (2 x uint32)
  return;
}
```

**Notes:**
- **Size: 8 bytes** (2 x uint32 or 1 x uint64)
- Read via inner vtable[0x18]
- Write via inner vtable[0x30] - takes TWO parameters (low, high)

---

### FUN_01b48e80 / FUN_01b48bc0 / FUN_01b48be0 - Simple Wrappers

```c
void FUN_01b48e80(void) { FUN_01b497f0(); return; }   // Bool wrapper (1 byte)
void FUN_01b48bc0(void) { FUN_01b49610(); return; }   // UInt32 wrapper (4 bytes)
void FUN_01b48be0(void) { FUN_01b496d0(); return; }   // UInt64 wrapper (8 bytes)
```

---

### FUN_01b0d0c0 - Finalize/Close Tags

**Address:** `0x01b0d0c0`

```c
void __fastcall FUN_01b0d0c0(int param_1)
{
  int iVar1;

  iVar1 = *(int *)(param_1 + 0x58);
  if (((iVar1 == 1) || (iVar1 == 2)) || (iVar1 == 3)) {
    if (*(int *)(param_1 + 0x6c) != 0) {
      FUN_01b70d50();
      return;
    }
  }
  else if (*(int *)(param_1 + 0x20) != 0) {
    FUN_01b0d000();
    (**(code **)(**(int **)(param_1 + 4) + 0x14))("Properties");       // Close Properties
    (**(code **)(**(int **)(param_1 + 4) + 0xc))("Dynamic Properties"); // Open Dynamic Properties
    if (*(int *)(param_1 + 0x28) != 0) {
      FUN_01b091a0(*(int *)(param_1 + 0x28));                          // Serialize dynamic props
    }
    (**(code **)(**(int **)(param_1 + 4) + 0x14))("Dynamic Properties"); // Close Dynamic Properties
    (**(code **)(**(int **)(param_1 + 4) + 0x14))("Object");            // Close Object
  }
  return;
}
```

**Notes:**
- Closes the serialization tags
- In modes 1/2/3: special handling via FUN_01b70d50
- Otherwise: writes closing structure:
  1. Close "Properties"
  2. Open "Dynamic Properties"
  3. Serialize dynamic properties if present
  4. Close "Dynamic Properties"
  5. Close "Object"

---

### FUN_01b09e20 - Type Header Writer

**Address:** `0x01b09e20`

```c
void __thiscall FUN_01b09e20(int param_1, undefined4 param_2, undefined4 param_3,
                             undefined4 param_4, int param_5)
{
  // ... exception handling setup ...

  iVar2 = FUN_01aff5e0(param_4);
  local_1c = 0;
  local_18 = 0;
  local_14 = 0;
  if (((*(uint *)(iVar2 + 0x18) & 8) == 0) && (*(int *)(param_1 + 0x58) != 1)) {
    if (*(int *)(param_1 + 0x7c) == 2) {
      local_1c = 0;
    }
    else {
      iVar2 = param_5;
      if ((param_5 == 0) &&
         ((*(int *)(param_1 + 0x1c) == 0 ||
          (iVar2 = FUN_01afc2c0(*(int *)(param_1 + 0x1c), 1, 0), iVar2 == 0)))) {
        local_1c = 0;
      }
      else {
        local_1c = FUN_01afb9a0(iVar2);
      }
    }
  }
  // ... write header data via FUN_01b08ce0 ...

  FUN_01b08ce0(param_2, &param_3, &param_4, &local_1c, &local_18, &local_24, &local_14);

  // ... cleanup ...
}
```

**Parameters:**
- `param_2` = Type name string ("AssassinSingleProfileData")
- `param_3` = 0
- `param_4` = Type hash (0xc9876d66)

---

### FUN_01b0a210 - Object Deserializer (Reader)

**Address:** `0x01b0a210`

This function reads/deserializes objects and confirms the nested section structure.

```c
void __thiscall FUN_01b0a210(int param_1, int *param_2, int param_3, int param_4)
{
  // ... setup ...

  // Call FUN_01b08ce0 to read ObjectInfo header
  FUN_01b08ce0(0, &local_14, &local_24, &local_1c, &local_20, &local_2c, &param_3);

  // Store read values into output object
  *(undefined4 *)(*param_2 + 8) = local_24;
  *(undefined4 *)(*param_2 + 0x10) = local_20;
  *(undefined4 *)(*param_2 + 0xc) = local_1c;

  // Read properties in a loop
  while (cVar2 == '\0') {
    (**(code **)(**(int **)(param_1 + 4) + 0xc))("Property");  // OpenSection per property
    // ... read property type/hash via vtable[0x50] ...
    FUN_01b0e980(&local_18);                                   // Read type info
    FUN_01b0ca30(param_3, local_18, local_14);                 // Process property
    cVar2 = (**(code **)(**(int **)(param_1 + 4) + 0x1c))();   // Check if more
  }

  (**(code **)(**(int **)(param_1 + 4) + 0x14))("Properties");        // CloseSection

  (**(code **)(**(int **)(param_1 + 4) + 0xc))("Dynamic Properties"); // OpenSection
  if (cVar2 == '\0') {
    FUN_01b091a0(*param_2 + 0x18);                                    // Read dynamic props
  }
  (**(code **)(**(int **)(param_1 + 4) + 0x14))("Dynamic Properties"); // CloseSection

  (**(code **)(**(int **)(param_1 + 4) + 0x14))("Object");            // CloseSection
}
```

**Key findings:**
1. **Confirms nested section structure:**
   - Object section (outer)
     - Properties section
       - Individual Property sections (per property)
     - Dynamic Properties section
2. **Section close order:** Properties → Dynamic Properties → Object
3. **Property loop:** Reads properties until CheckEnd returns true

---

## Property Metadata Structures

Each property descriptor is 0x20 (32) bytes:

### Structure Layout

```c
struct PropertyDescriptor {
    uint8_t  flags[4];       // 0x00: Usually 01 00 00 02
    uint32_t name_hash;      // 0x04: Property name hash (little-endian)
    uint8_t  padding1[6];    // 0x08: Zeros
    uint16_t type_flags;     // 0x0E: Type-specific flags (09 00 for Value type)
    uint32_t offset;         // 0x10: Offset in serialization stream
    uint8_t  padding2[12];   // 0x14: Zeros
};
```

### Property Descriptors

| Address | Hash | Type | Stream Offset | Usage |
|---------|------|------|---------------|-------|
| DAT_027ecf90 | `0xbf4c2013` | UInt32 (01 00 00 02, flags=07) | 0x10 | **SaveGameDataObject** field +0x04 (in header!) |
| DAT_02973250 | `0x3b546966` | Bool (01 00 00 02) | 0x80 | FUN_01b09650 at +0x20 |
| DAT_02973270 | `0x4dbc7da7` | Bool (01 00 00 02) | 0x84 | FUN_01b09650 at +0x21 |
| DAT_02973290 | `0x5b95f10b` | Bool (01 00 00 02) | 0x88 | FUN_01b09650 at +0x22 |
| DAT_029732b0 | `0x2a4e8a90` | Bool (01 00 00 02) | 0x8C | FUN_01b09650 at +0x23 |
| DAT_029732d0 | `0x496f8780` | Value (01 00 00 02, flags=09) | 0x60 | FUN_01b09760 at +0x18 |
| DAT_029732f0 | `0x6f88b05b` | Bool (01 00 00 02) | 0x90 | FUN_01b09650 at +0x24 |

### Raw Property Descriptor Data

```
DAT_02973250 (hash 0x3b546966):
  02973250: 01 00 00 02  66 69 54 3b  00 00 00 00  00 00 00 00
  02973260: 00 00 80 00  00 00 00 00  00 00 00 00  00 00 00 00

DAT_02973270 (hash 0x4dbc7da7):
  02973270: 01 00 00 02  a7 7d bc 4d  00 00 00 00  00 00 00 00
  02973280: 00 00 84 00  00 00 00 00  00 00 00 00  00 00 00 00

DAT_02973290 (hash 0x5b95f10b):
  02973290: 01 00 00 02  0b f1 95 5b  00 00 00 00  00 00 00 00
  029732a0: 00 00 88 00  00 00 00 00  00 00 00 00  00 00 00 00

DAT_029732b0 (hash 0x2a4e8a90):
  029732b0: 01 00 00 02  90 8a 4e 2a  00 00 00 00  00 00 00 00
  029732c0: 00 00 8c 00  00 00 00 00  00 00 00 00  00 00 00 00

DAT_029732d0 (hash 0x496f8780) - VALUE TYPE:
  029732d0: 01 00 00 02  80 87 6f 49  00 00 00 00  00 00 09 00  <- Note: 09 at 0x0E
  029732e0: 00 00 60 00  00 00 00 00  00 00 00 00  00 00 00 00

DAT_029732f0 (hash 0x6f88b05b):
  029732f0: 01 00 00 02  5b b0 88 6f  00 00 00 00  00 00 00 00
  02973300: 00 00 90 00  00 00 00 00  00 00 00 00  00 00 00 00

DAT_027ecf90 (hash 0xbf4c2013) - SAVEGAMEDATAOBJECT FIELD (in header, not property section):
  027ecf90: 01 00 00 02  13 20 4c bf  00 00 00 00  00 00 07 00  <- Note: 07 at 0x0E (UInt32)
  027ecfa0: 00 00 10 00  00 00 00 00  00 00 00 00  00 00 00 00
  Used by: FUN_01b0a1f0 → FUN_01b12fa0 (UInt32 serializer)
  NOTE: This field's hash appears in header field_0x18, not as a property record!
```

---

## Binary Data Correlation

### Property Hashes Found in Binary

The property hashes appear in the serialized data:

| Binary Offset | Bytes | Hash (LE) | Property |
|---------------|-------|-----------|----------|
| 0x2E-0x31 | `66 69 54 3b` | 0x3b546966 | Bool field 1 |
| 0x40-0x43 | `a7 7d bc 4d` | 0x4dbc7da7 | Bool field 2 |
| 0x52-0x55 | `0b f1 95 5b` | 0x5b95f10b | Bool field 3 |
| 0x64-0x67 | `90 8a 4e 2a` | 0x2a4e8a90 | Bool field 4 |
| 0x76-0x79 | `80 87 6f 49` | 0x496f8780 | Value field |
| 0x90-0x93 | `5b b0 88 6f` | 0x6f88b05b | Bool field 5 |

### Annotated Binary Structure

```
Header (0x00-0x25):
00000000: 00 00 00 00 00 00 00 00 00 00           // 10 bytes padding/nulls
0000000a: 66 6d 87 c9                             // Type hash: 0xc9876d66 (AssassinSingleProfileData)
0000000e: 90 00                                   // ?
00000010: 00 00 88 00                             // ?
00000014: 00 00 11 00                             // 0x11 = 17 (count?)
00000018: 00 00 13 20 4c bf                       // ?
0000001e: 00 00 00 00 00 00                       // Padding
00000024: 07 00                                   // ?

Property 1 - SaveGameDataObject field (0x26-0x2D):
00000026: 0b 00 00 00 00 0e 00 00                 // Type 0x0b, size/flags

Property 2 - Bool 0x3b546966 (0x2E-0x3D):
0000002e: 00 66 69 54 3b                          // Hash 0x3b546966
00000033: 00 00 00 00 00 00 00 00                 // Value + padding
0000003b: 0b 01                                   // Type indicator
0000003d: 0e 00 00 00                             // ?

Property 3 - Bool 0x4dbc7da7 (0x41-0x50):
00000041: a7 7d bc 4d                             // Hash 0x4dbc7da7
00000045: 00 00 00 00 00 00 00 00                 // Value + padding
0000004d: 0b 01                                   // Type indicator
0000004f: 0e 00 00 00                             // ?

Property 4 - Bool 0x5b95f10b (0x53-0x62):
00000053: 0b f1 95 5b                             // Hash 0x5b95f10b
00000057: 00 00 00 00 00 00 00 00                 // Value + padding
0000005f: 0b 00                                   // Type indicator
00000061: 0e 00 00 00                             // ?

Property 5 - Bool 0x2a4e8a90 (0x65-0x74):
00000065: 90 8a 4e 2a                             // Hash 0x2a4e8a90
00000069: 00 00 00 00 00 00 00 00                 // Value + padding
00000071: 0b 00                                   // Type indicator
00000073: 15 00 00 00                             // ?

Property 6 - Value 0x496f8780 (0x77-0x8D):
00000077: 80 87 6f 49                             // Hash 0x496f8780
0000007b: 00 00 00 00 00 09 00 0b                 // Value data
00000083: ff ff ff ff ff ff                       // 0xFFFFFFFFFFFF (-1 or sentinel?)
00000089: 1f 00                                   // ?
0000008b: 0e 00 00 00                             // ?

Property 7 - Bool 0x6f88b05b (0x8F-0x9E):
0000008f: 5b b0 88 6f                             // Hash 0x6f88b05b  (actually at 0x90)
00000093: 00 00 00 00 00 00 00 00                 // Value + padding
0000009b: 0b 01                                   // Type indicator

Trailer (0x9D-0xA1):
0000009d: 00 00 00 00 00                          // Padding
```

---

## Serialization Architecture

### VTable-Based Type Dispatch

All serializers follow an identical pattern, differing only in the vtable offset for value writing:

```c
// Common serializer pattern:
cVar3 = FUN_01b07940(param_2, 0, 0);              // Validate property descriptor
if (cVar3 != '\0') {
    cVar3 = FUN_01b0d140(param_2);                // Additional validation
    if (cVar3 != '\0') {
        // Optional: Call type-specific pre-handler in mode 2

        piVar1 = *(int **)(param_1 + 4);          // Get writer vtable
        (**(code **)(*piVar1 + 0x08))("Value");   // Open tag
        (**(code **)(*piVar1 + TYPE_OFFSET))(param_3);  // Write value
        (**(code **)(*piVar1 + 0x10))("Value");   // Close tag

        // Optional: Write "Property" tag in certain modes
    }
}
```

### VTable Offsets by Type

| Offset | Type | Size | Serializer Function | Core Reader/Writer |
|--------|------|------|---------------------|-------------------|
| `0x58` | bool | 1 byte | FUN_01b11fb0 | FUN_01b497f0 |
| `0x7c` | uint64 | 8 bytes | FUN_01b124e0 | FUN_01b496d0 |
| `0x84` | uint32 | 4 bytes | FUN_01b12fa0 | FUN_01b49610 |

### Confirmed Data Sizes

| Type | Size (bytes) | Core Function | Inner VTable (Read) | Inner VTable (Write) |
|------|--------------|---------------|---------------------|----------------------|
| bool | 1 | FUN_01b497f0 | 0x24 | 0x3c |
| uint32 | 4 | FUN_01b49610 | 0x1c | 0x34 |
| uint64 | 8 | FUN_01b496d0 | 0x18 | 0x30 |

### Tag Names (Strings)

| Tag | Used For |
|-----|----------|
| `"Value"` | Property value wrapper |
| `"Property"` | Individual property |
| `"Properties"` | All properties container |
| `"Dynamic Properties"` | Dynamic properties section |
| `"Object"` | Root object container |
| `"Name"` | Property name/hash |
| `"Type"` | Type information |
| `"ID"` | Property ID |
| `"NbDynamicProperties"` | Dynamic property count |

### Binary Writer VTable (at 0x02555c60)

**Discovered via WinDbg:** Context+0x04 → Writer interface → VTable at 0x02555c60

| Offset | Function | Purpose | Notes |
|--------|----------|---------|-------|
| 0x00 | FUN_01b49b10 | Constructor/destructor | |
| 0x04 | FUN_01b48830 | Get position | |
| 0x08 | LAB_01b48770 | **OpenTag - NO-OP!** | Just `RET 4` - tags not written to binary |
| 0x0c | FUN_01b48890 | **OpenSection** | Writes 4-byte size placeholder |
| 0x10 | LAB_01b487a0 | **CloseTag - NO-OP!** | Just `RET 4` |
| 0x14 | FUN_01b48920 | **CloseSection** | Seeks back and patches size field |
| 0x1c | LAB_01b48a10 | CheckEnd | |
| 0x4c | FUN_01b49020 | WriteTypeInfo | Calls FUN_01b496d0 (8 bytes) |
| 0x50 | FUN_01b48fb0 | WritePropertyHash | Calls FUN_01b49610 (4 bytes) |
| 0x54 | FUN_01b48e90 | WriteString | ObjectName |
| 0x58 | FUN_01b48e80 | **WriteBool** | → FUN_01b497f0 (1 byte) |
| 0x5c | FUN_01b48e00 | Write 4x uint32 | 16 bytes |
| 0x7c | FUN_01b48be0 | **WriteUInt64** | → FUN_01b496d0 (8 bytes) |
| 0x84 | FUN_01b48bc0 | **WriteUInt32** | → FUN_01b49610 (4 bytes) |
| 0x8c | FUN_01b48ba0 | WriteUInt16 | SerializerVersion, ClassVersion |
| 0x98 | FUN_01b48b70 | **WriteByte** | PropertyHeaderFlag (0x0b marker) |
| 0x9c | FUN_01b48e70 | WriteObjectID | |

**Key Discovery:** OpenTag (0x08) and CloseTag (0x10) are NO-OPs (`RET 4`). Tag names like "Value", "Property" are NOT written to the binary - they're just logical markers in the code.

### Property Serialization Flow (FUN_01b0d140)

Complete traced flow for writing a property:

```c
// 1. Open "Property" section - writes 4-byte size placeholder
(*vtable[0x0c])("Property");  // FUN_01b48890

// 2. Write property hash (4 bytes) via "Name" tag
FUN_01b0e680("Name", 0, &hash);
  → (*vtable[0x50])(&hash)    // FUN_01b48fb0
    → FUN_01b49610(hash)      // Write uint32

// 3. Write type info (8 bytes) via "Type" tag
FUN_01b0e980(&type_info);
  → (*vtable[0x4c])(&type_info)  // FUN_01b49020
    → FUN_01b496d0(type_info)    // Write 8 bytes from descriptor

// 4. Write flags byte (0x0b) - HARDCODED in FUN_01b0d140!
param_2 = ... | 0xb000000;        // Sets byte to 0x0b
FUN_01b076f0(&flags_byte);
  → (*vtable[0x98])(&flags_byte)  // FUN_01b48b70 - write 1 byte

// 5. Value serializer writes actual value
(*vtable[0x58/0x7c/0x84])(value);  // Type-specific

// 6. Close "Property" section - patches size field
(*vtable[0x14])();  // FUN_01b48920
  → Seeks to saved position
  → Writes actual size as uint32
  → Seeks back to end
```

### FUN_01b076f0 - PropertyHeaderFlag Reader/Writer

**Address:** `0x01b076f0`

**Full decompilation:**
```c
void __thiscall FUN_01b076f0(int param_1, byte *param_2)
{
  if (10 < *(int *)(param_1 + 0x24)) {  // If serializer version > 10 (>= 11)
    // Version 11+: Read/write single byte as "PropertyHeaderFlag"
    (**(code **)(*piVar1 + 8))("PropertyHeaderFlag");   // OpenTag (NO-OP)
    (**(code **)(*piVar1 + 0x98))(param_2);             // vtable[0x98] = ReadByte/WriteByte
    (**(code **)(*piVar1 + 0x10))("PropertyHeaderFlag"); // CloseTag (NO-OP)
    return;
  }

  // Version <= 10: Read/write as two separate bool flags
  // "Final" flag -> bit 0
  (**(code **)(*piVar1 + 8))("Final");
  (**(code **)(*piVar1 + 0x58))((int)&param_2 + 3);     // ReadBool/WriteBool
  (**(code **)(*piVar1 + 0x10))("Final");
  *pbVar2 = *pbVar2 ^ (*pbVar2 ^ param_2._3_1_) & 1;   // Set bit 0 from "Final"

  // "Owned" flag -> bit 1
  (**(code **)(*piVar1 + 8))("Owned");
  (**(code **)(*piVar1 + 0x58))((int)&uStack_8 + 3);   // ReadBool/WriteBool
  (**(code **)(*piVar1 + 0x10))("Owned");
  *pbVar2 = *pbVar2 ^ (uStack_8._3_1_ * '\x02' ^ *pbVar2) & 2;  // Set bit 1 from "Owned"
}
```

**Version behavior:**
- **Version >= 11:** Single byte read/write via vtable[0x98]
- **Version <= 10:** Two separate bools combined into bits 0-1

**Our file evidence:** The flags byte is 0x0b (binary: 00001011), which has bits beyond 0-1 set. This proves the file was written with **serializer version >= 11**.

The 0x0b marker (binary: 00001011) contains:
- Bit 0 = "Final" flag (1)
- Bit 1 = "Owned" flag (1)
- Bit 3 = set (1)

### FUN_01b48890 - OpenSection (Size Placeholder)

```c
// Write mode:
position = (*inner_vtable[0x4c])();           // Get current position
context[0x14 + index*8] = position;           // Save position
context[0x10 + index*8] = 0;                  // Initialize size
(*inner_vtable[0x44])(4);                     // Write 4-byte placeholder
index++;
```

### FUN_01b48920 - CloseSection (Patch Size)

**Address:** `0x01b48920`

**Complete traced implementation:**

```c
void __thiscall FUN_01b48920(void *context)
{
  int *piVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  undefined4 uVar5;
  undefined4 uVar6;

  if (*(char *)(context + 0x04) != '\0') {
    // READ MODE - decrement index, check remaining size
    short current_index = *(short *)(context + 0x1010);
    *(short *)(context + 0x1010) = current_index - 1;

    if (current_index - 1 != 0) {
      int remaining = *(int *)(context + 8 + (current_index - 1) * 8);
      if (remaining != 0) {
        // Skip remaining bytes via inner_vtable[0x44]
        (**(code **)(**(int **)(context + 8) + 0x44))(remaining);
      }
    }
    return;
  }

  // WRITE MODE:
  short old_index = *(short *)(context + 0x1010);
  int accumulated_size = *(int *)(context + 0x08 + old_index * 8);  // Get accumulated size
  short new_index = old_index - 1;
  *(short *)(context + 0x1010) = new_index;

  int saved_position = *(int *)(context + 0x14 + new_index * 8);    // Get saved position

  // Seek to saved position (where size placeholder was)
  (**(code **)(**(int **)(context + 8) + 0x50))(saved_position);    // inner_vtable[0x50] = Seek

  // Write the accumulated size as uint32
  (**(code **)(**(int **)(context + 8) + 0x34))(accumulated_size);  // inner_vtable[0x34] = Write uint32

  // Seek back to current end position
  (**(code **)(**(int **)(context + 8) + 0x54))(...);               // inner_vtable[0x54] = Seek

  // Flush the stream
  (**(code **)(**(int **)(context + 8) + 0x58))();                  // inner_vtable[0x58] = Flush

  // Propagate size to parent section (size + 4 for the size field itself)
  if (new_index > 0) {
    FUN_01b493f0(context, accumulated_size + 4);  // Add to parent's accumulated size
  }
  return;
}
```

**Summary (write mode):**
```c
index = context[0x1010];                      // Get current section index
size = context[0x08 + index*8];               // Get accumulated size for this section
index--;
context[0x1010] = index;                      // Decrement index

saved_pos = context[0x14 + index*8];          // Get saved position (where placeholder was)
(*inner_vtable[0x50])(saved_pos);             // Seek to placeholder
(*inner_vtable[0x34])(size);                  // Write actual size as uint32
(*inner_vtable[0x54])(...);                   // Seek back to end
(*inner_vtable[0x58])();                      // Flush

if (index > 0) {
  FUN_01b493f0(size + 4);                     // Add (size + 4) to parent section
}
```

**Size Propagation:** The `size + 4` passed to FUN_01b493f0 accounts for both the section's content size AND the 4-byte size field itself. This allows nested sections to correctly calculate their total sizes.

### FUN_01b493f0 - Size Propagation to Parent

**Address:** `0x01b493f0`

Called by CloseSection to add the closed section's total size to the parent section's accumulated size.

```c
void __thiscall FUN_01b493f0(void *context, int size_to_add)
{
  if (*(char *)(context + 0x04) == '\0') {
    // Write mode: ADD to parent's accumulated size
    short index = *(short *)(context + 0x1010);
    int *size_field = (int *)(context + 0x08 + index * 8);
    *size_field = *size_field + size_to_add;
  }
  else {
    // Read mode: SUBTRACT from remaining (validation)
    short index = *(short *)(context + 0x1010);
    int *size_field = (int *)(context + 0x08 + index * 8);
    *size_field = *size_field - size_to_add;
  }
  return;
}
```

**Context Structure (offset 0x08+ array):**

The context maintains a stack of section states. Each entry is 8 bytes:
- `context[0x08 + index*8]` = Accumulated size (write) / Remaining size (read)
- `context[0x14 + index*8]` = Saved position (where size placeholder was written)

The stack index at `context[0x1010]` tracks the current nesting depth.

### Legacy Writer VTable Reference

| Offset | Method | Purpose | Used By |
|--------|--------|---------|---------|
| 0x08 | OpenTag | NO-OP (tags not written) | All serializers |
| 0x0c | OpenSection | Write size placeholder | FUN_01b0d140 |
| 0x10 | CloseTag | NO-OP | All serializers |
| 0x14 | CloseSection | Patch size field | FUN_01b0d0c0 |
| 0x1c | CheckEnd | Check if at end of data | FUN_01b0d140 |
| 0x4c | WriteTypeInfo | Write 8 bytes | FUN_01b0e980 |
| 0x50 | WritePropertyHash | Write 4 bytes | FUN_01b0e680 |
| 0x58 | WriteBool | Write 1 byte | FUN_01b11fb0 |
| 0x7c | WriteUInt64 | Write 8 bytes | FUN_01b124e0 |
| 0x84 | WriteUInt32 | Write 4 bytes | FUN_01b12fa0 |
| 0x98 | WriteByte | Write 1 byte | FUN_01b076f0 |

### Serializer Context (param_1)

| Offset | Type | Field | Notes |
|--------|------|-------|-------|
| +0x04 | ptr | writer_vtable | Pointer to writer interface |
| +0x1c | ptr | parent_context | Parent serialization context |
| +0x24 | int | version | Version number (checked for -1 fallback) |
| +0x28 | ptr | dynamic_props | Dynamic properties reference |
| +0x4e | byte | flags | Bit flags for state |
| +0x58 | int | mode | 1=?, 2=write?, 3=read |

---

## Recurring Patterns

### Type Indicators

| Byte(s) | Meaning |
|---------|---------|
| `0b` | Property type marker (bool?) |
| `0e` | End marker / next section? |
| `01` | Value present / true |
| `00` | No value / false |
| `ff ff ff ff ff ff` | Sentinel / null / -1 |

---

## Open Questions

- [x] What is the overall structure layout? → Nested properties with hashes
- [x] What do the `0b` and `0e` bytes represent? → 0x0b at position 0x26 is NbClassVersionsInfo; 0x0b in properties is flags byte; 0x0e is size field
- [x] Is `ffff ffff ffff` a sentinel/terminator? → Yes, appears in Value field
- [x] What are FUN_01b0a1f0 and FUN_01b09620? → UInt32 serializer wrapper and dynamic properties handler
- [x] What is the exact property record format? → [size 4][hash 4][type_info 8][flags 1][value N]
- [x] What do stream offsets 0x80, 0x84, 0x88, 0x8C, 0x60, 0x90 reference? → Property descriptor stream offsets
- [x] Where does 0x0b marker come from? → Hardcoded in FUN_01b0d140, written by FUN_01b076f0 via vtable[0x98]
- [x] Where does 0x09 marker come from? → Type info from property descriptor (8 bytes at +0x08)
- [x] What writes the size field? → FUN_01b48890 (OpenSection) writes placeholder, FUN_01b48920 (CloseSection) patches it
- [x] Are tag names written to binary? → NO! OpenTag/CloseTag (vtable 0x08/0x10) are NO-OPs (just RET 4)
- [x] What is the serializer version? → **>= 11** based on PropertyHeaderFlag being single byte (FUN_01b076f0)
- [x] What is the 0x0b byte at position 0x26? → NbClassVersionsInfo when version >= 13
- [x] What are the 5 prefix bytes before first property? → 1 byte NbClassVersionsInfo + 4 bytes Object section placeholder (version >= 13 confirmed)
- [x] Type info version? → **>= 9** based on 8-byte direct format (FUN_01b0e980)
- [x] NbClassVersionsInfo source traced → Read from `[param_6 + 6]` in FUN_01b08ce0
- [x] **NbClassVersionsInfo value RESOLVED** → WinDbg confirmed game writes 0x00; our file's 0x0b is from different save session. Value is context-dependent.
- [~] Where is the Properties section placeholder? → May be implicit within Object section or merged with first property's size field

### Serializer Version Summary

Based on traced functions, our file was written with:

| Feature | Version Requirement | Status |
|---------|---------------------|--------|
| Type info as 8 bytes | >= 9 | ✅ Confirmed |
| PropertyHeaderFlag as single byte | >= 11 | ✅ Confirmed (0x0b has bits 2-7) |
| NbClassVersionsInfo path | >= 13 | ✅ Likely (5-byte prefix fits) |

---

## WinDbg Tracing Plan

### Priority 1: NbClassVersionsInfo Value Discrepancy ✅ RESOLVED

**Problem:** Static analysis of FUN_01b08ce0 shows NbClassVersionsInfo should be 0x00, but file contains 0x0b.

**Resolution:** WinDbg TTD tracing confirmed the game writes 0x00. Our reference file's 0x0b value is from a different save session. The value is context-dependent and varies between saves.

**Breakpoints to set (adjust for actual base address):**

```
; Calculate actual addresses: GHIDRA_base = 0x00400000, actual_base = ?
; Example: if loaded at 0x00AE0000, add 0x006E0000 to GHIDRA addresses

; BP 1: When byte is read for NbClassVersionsInfo
bp game.exe+0x1708d85
; At hit: r edi; db edi L10; ? poi(edi+6)

; BP 2: Before FUN_01b0d500 writes the byte
bp game.exe+0x1708d97
; At hit: db ebp-1 L1  (shows local_5 value about to be written)

; BP 3: FUN_01b09e20 entry to check stack setup
bp game.exe+0x1709e20
; At hit: step to after local_20 init, then: dd ebp-20 L1

; BP 4: On FUN_01b0d500 to see all NbClassVersionsInfo writes
bp game.exe+0x170d500
; At hit: dd esp+8 L1  (shows value being written)
```

**What to look for:**
1. What is in `EDI` when BP1 hits?
2. What is the byte at `[EDI + 6]`?
3. Is `local_20` actually 0x8004 or something else?
4. Is there any code modifying the stack between initialization and read?

### Priority 2: Header Field Sources

**Goal:** Understand where header fields 0x0E-0x25 get their values.

```
; BP on FUN_01b08ce0 entry
bp game.exe+0x1708ce0

; When hit, examine parameters:
; dd esp+4 L7   (all 7 parameters)
; Then step through and watch what gets written
```

### Expected Session Workflow

1. Launch game under WinDbg
2. Set BP on FUN_01b08ce0 (or FUN_01b09e20)
3. Trigger save game operation
4. Capture register/memory state at each breakpoint
5. Compare runtime values with static analysis predictions

### Notes

- Remember base address adjustment (WinDbg vs Ghidra)
- Previous WinDbg session showed base at ~0x00AE0000 (offset +0x006E0000 from Ghidra)
- Stream VTable was at 0x02c36168 (runtime)

**Conclusion:** Serializer version is **>= 13** (most likely).

---

## Functions To Trace

| Function | Purpose | Status |
|----------|---------|--------|
| FUN_01710580 | AssassinSingleProfileData::Serialize | ✅ Done |
| FUN_005e3700 | SaveGameDataObject::Serialize | ✅ Done |
| FUN_01b09650 | Bool serializer wrapper | ✅ Done |
| FUN_01b11fb0 | Bool serializer (vtable 0x58) | ✅ Done |
| FUN_01b09760 | Value wrapper | ✅ Done |
| FUN_01b124e0 | Value serializer (vtable 0x7c) | ✅ Done |
| FUN_01b0a1f0 | UInt32 wrapper | ✅ Done |
| FUN_01b12fa0 | UInt32 serializer (vtable 0x84) | ✅ Done |
| FUN_01b09620 | Dynamic properties handler | ✅ Done |
| FUN_01b091a0 | Dynamic properties serializer | ✅ Done |
| FUN_01b09e20 | Type header writer | ✅ Done |
| FUN_01b07940 | Property validation/init | ✅ Done |
| FUN_01b0d140 | Property lookup/match + flags writer | ✅ Done |
| FUN_01b0d0c0 | Finalize/close tags | ✅ Done |
| FUN_01b0e680 | Write property hash (vtable 0x50) | ✅ Done |
| FUN_01b0e980 | Write type info (vtable 0x4c) | ✅ Done |
| FUN_01b497f0 | Bool reader/writer core (1 byte) | ✅ Done |
| FUN_01b49610 | UInt32 reader/writer core (4 bytes) | ✅ Done |
| FUN_01b496d0 | UInt64 reader/writer core (8 bytes) | ✅ Done |
| FUN_01b0e3d0 | Legacy type format conversion | ✅ Done |
| FUN_01b564b0 | Parent context lookup (stub, returns 0) | ✅ Done |
| FUN_01b0ca30 | Property type dispatcher | ✅ Done |
| FUN_01b08ce0 | ObjectInfo header writer | ✅ Done |
| FUN_01b0d500 | NbClassVersionsInfo writer (1 byte) | ✅ Done |
| FUN_01b0d420 | ClassVersion/SerializerVersion writer (2 bytes) | ✅ Done |
| FUN_01b076f0 | Property flags writer (0x0b marker) | ✅ Done |
| **Binary Writer VTable (0x02555c60)** | | |
| LAB_01b48770 | OpenTag - NO-OP (vtable 0x08) | ✅ Done |
| LAB_01b487a0 | CloseTag - NO-OP (vtable 0x10) | ✅ Done |
| FUN_01b48890 | OpenSection - size placeholder (vtable 0x0c) | ✅ Done |
| FUN_01b48920 | CloseSection - patch size (vtable 0x14) | ✅ Done |
| FUN_01b48fb0 | WritePropertyHash (vtable 0x50) | ✅ Done |
| FUN_01b49020 | WriteTypeInfo (vtable 0x4c) | ✅ Done |
| FUN_01b48e80 | WriteBool wrapper (vtable 0x58) | ✅ Done |
| FUN_01b48be0 | WriteUInt64 wrapper (vtable 0x7c) | ✅ Done |
| FUN_01b48bc0 | WriteUInt32 wrapper (vtable 0x84) | ✅ Done |
| FUN_01b48b70 | WriteByte (vtable 0x98) | ✅ Done |
| Inner vtable | Stream read/write (confirmed via WinDbg) | ✅ Done |

## WinDbg Live Debug Findings

### Stream Object Structure (confirmed at runtime)

```
Stream Object (example at 0xf6c302d8):
+0x00: vtable pointer (0x02c36168)
+0x04: endian flag (0 = little-endian, 1 = big-endian swap)
+0x08: (reserved)
+0x0C: (reserved)
+0x10: (reserved)
+0x14: buffer start pointer
+0x18: current read position pointer  <-- KEY FIELD
+0x1C: (reserved)
+0x20: total buffer size (0xa2 = 162 bytes)
```

### Stream VTable (at 0x02c36168)

**Note:** WinDbg base is 0xae0000, GHIDRA base is 0x400000. Conversion: `GHIDRA_addr = WinDbg_addr - 0x006e0000`

| Offset | WinDbg Addr | GHIDRA Addr | Purpose |
|--------|-------------|-------------|---------|
| 0x18 | 0x0224f080 | 0x01b6f080 | Read uint64 (8 bytes) |
| 0x1c | 0x0224f440 | 0x01b6f440 | Read uint32 (4 bytes) |
| 0x24 | 0x0224f150 | 0x01b6f150 | Read bool (1 byte) |
| 0x30 | 0x0224f4f0 | 0x01b6f4f0 | Write uint64 |
| 0x34 | 0x0224f4d0 | 0x01b6f4d0 | Write uint32 |
| 0x3c | 0x0224f370 | 0x01b6f370 | Write bool |
| 0x44 | 0x0224f2b0 | 0x01b6f2b0 | **Skip/Reserve N bytes** (advances position only) |
| 0x4c | - | - | Get current position |
| 0x50 | - | - | Seek to position |
| 0x54 | - | - | Seek (restore position) |
| 0x58 | - | - | Flush |

### Read Bool Implementation (0x0224f150)

```asm
mov     eax,dword ptr [ecx+18h]    ; Get current buffer pointer
mov     dl,byte ptr [eax]          ; Read 1 byte
mov     eax,dword ptr [ebp+8]      ; Get output parameter
mov     byte ptr [eax],dl          ; Store result
inc     dword ptr [ecx+18h]        ; Advance pointer by 1
pop     ebp
ret     4
```

### Read UInt32 Implementation (0x0224f440)

```asm
mov     eax,dword ptr [esi+18h]    ; Get buffer pointer
mov     ecx,dword ptr [eax]        ; Read 4 bytes (little-endian)
mov     eax,dword ptr [ebp+8]      ; Get output param
mov     dword ptr [eax],ecx        ; Store result
test    byte ptr [esi+4],1         ; Check endian flag
je      skip_swap                  ; If 0, data is little-endian
; BYTE SWAP (for big-endian files):
; Swaps bytes 0<->3, then 1<->2
...
skip_swap:
add     dword ptr [esi+18h],4      ; Advance pointer by 4
ret     4
```

### FUN_01b6f2b0 - Skip/Reserve N Bytes (inner_vtable[0x44])

**Address:** GHIDRA `0x01b6f2b0` / WinDbg `0x0224f2b0`

**CRITICAL DISCOVERY:** This function does NOT write zeros - it only advances the stream position pointer. This is used by OpenSection to reserve space for the size field that will be patched later.

```c
void __thiscall FUN_01b6f2b0(void *stream, int bytes_to_skip)
{
  if (*(int *)(stream + 0x30) == 0) {
    // Fast path - no buffer management needed
    *(int *)(stream + 0x18) = *(int *)(stream + 0x18) + bytes_to_skip;  // Just advance position
    return;
  }

  // Buffer management path - grow buffer if needed
  int current_pos = *(int *)(stream + 0x18);
  int buffer_start = *(int *)(stream + 0x14);
  int capacity = *(int *)(stream + 0x1c);
  int needed = current_pos - buffer_start + bytes_to_skip;

  if (capacity < needed) {
    int overflow = needed - capacity;
    FUN_01b6f1b0(stream, overflow);  // Grow buffer
  }

  *(int *)(stream + 0x18) = *(int *)(stream + 0x18) + bytes_to_skip;  // Advance position
  return;
}
```

**Key Insight:** When OpenSection calls `inner_vtable[0x44](4)`, it's reserving 4 bytes by moving the write position forward WITHOUT writing any data. The data at those positions is whatever was already in the buffer (likely zeros from buffer initialization, or previous data). CloseSection later seeks back and writes the actual size.

### Confirmed Binary Format

| Aspect | Value | Evidence |
|--------|-------|----------|
| Byte order | **Little-endian** | Native x86 read, no swap in our file |
| Bool size | 1 byte | `inc dword ptr [ecx+18h]` |
| UInt32 size | 4 bytes | `add dword ptr [esi+18h],4` |
| UInt64 size | 8 bytes | `add dword ptr [esi+18h],8` |
| File size | 162 bytes (0xa2) | Confirmed at stream+0x20 |

---

## Data References (Resolved)

| Address | String | Used For |
|---------|--------|----------|
| DAT_02554cbc | `"Name"` | Property name tag |
| DAT_02554cb0 | `"Type"` | Type info tag |
| DAT_02554cb8 | `"ID"` | Property ID tag |
| DAT_025f9b50 | `0x00` (null) | Format specifier (empty) |

---

## Changelog

| Date | Change |
|------|--------|
| 2026-01-07 | Initial document created |
| 2026-01-07 | Added FUN_01b09650, FUN_01b09760, FUN_01b124e0, FUN_005e3700, FUN_01b09e20 |
| 2026-01-07 | Documented property descriptor structures (DAT_02973250 etc) |
| 2026-01-07 | Correlated property hashes with binary data |
| 2026-01-07 | Added FUN_01b0a1f0, FUN_01b12fa0 (UInt32 serializer) |
| 2026-01-07 | Added FUN_01b09620, FUN_01b091a0 (Dynamic properties) |
| 2026-01-07 | Added FUN_01b11fb0 (Bool core serializer) |
| 2026-01-07 | Documented VTable-based serialization architecture |
| 2026-01-07 | Added FUN_01b07940 (Property validation/init) |
| 2026-01-07 | Added FUN_01b0d140 (Property lookup/match) |
| 2026-01-07 | Added FUN_01b0d0c0 (Finalize/close tags) |
| 2026-01-07 | Documented XML-like serialization structure |
| 2026-01-07 | Added FUN_01b0e680 (Property index reader) |
| 2026-01-07 | Added FUN_01b0e980 (Type info reader) |
| 2026-01-07 | Expanded vtable structure (0x4c, 0x50) |
| 2026-01-07 | Resolved DAT_ strings: "Name", "Type", "ID" |
| 2026-01-07 | Added FUN_01b497f0 (Bool core - 1 byte) |
| 2026-01-07 | Added FUN_01b49610 (UInt32 core - 4 bytes) |
| 2026-01-07 | Added FUN_01b496d0 (UInt64 core - 8 bytes) - vtable 0x7c |
| 2026-01-07 | Added FUN_01b0e3d0 (Legacy type conversion) |
| 2026-01-07 | Added FUN_01b0ca30 (Type dispatcher) - type codes in bits 16-21 |
| 2026-01-07 | WinDbg: Confirmed stream structure and read implementations |
| 2026-01-07 | WinDbg: Verified little-endian format, sequential reads |
| 2026-01-07 | Added DAT_027ecf90 (SaveGameDataObject property descriptor, hash 0xbf4c2013) |
| 2026-01-07 | Discovered SaveGameDataObject field appears in header field_0x18, not property section |
| 2026-01-07 | Documented FUN_01b08ce0 as header writer, section prefix origin |
| 2026-01-07 | **RESOLVED** prefix mystery: 0x0b at 0x26 is NbClassVersionsInfo from FUN_01b0d500 |
| 2026-01-07 | Added FUN_01b0d500 (NbClassVersionsInfo, 1 byte) and FUN_01b0d420 (ClassVersion, 2 bytes) |
| 2026-01-07 | Confirmed FUN_01b48890 (OpenSection) reserves 4 bytes without writing data |
| 2026-01-07 | Prefix is: 1 byte NbClassVersionsInfo + 4 bytes Object section placeholder |
| 2026-01-07 | Added FUN_01b076f0 full analysis: PropertyHeaderFlag, version > 10 = single byte |
| 2026-01-07 | Added FUN_01b0e980 full analysis: Type info reader, version >= 9 = 8 bytes direct |
| 2026-01-07 | Added FUN_01b0a210 (Object deserializer) - confirms nested section structure |
| 2026-01-07 | Updated FUN_01b0ca30 with type encoding: bits 16-21 = primary type, bits 23-28 = secondary |
| 2026-01-07 | **RESOLVED** serializer version: >= 11 (PropertyHeaderFlag), >= 9 (type info), likely >= 13 |
| 2026-01-07 | Resolved Open Questions: serializer version, prefix bytes, type info format |
| 2026-01-07 | **AUDIT**: Full parser audit - property format 100% traced, header fields preserved for roundtrip |
| 2026-01-07 | **TRACED**: NbClassVersionsInfo byte source = `[param_6 + 6]` in FUN_01b08ce0 |
| 2026-01-07 | **DISCREPANCY FOUND**: Static analysis predicts NbClassVersionsInfo = 0x00, file has 0x0b |
| 2026-01-07 | Added WinDbg Tracing Plan section with breakpoints to resolve value discrepancy |
| 2026-01-07 | **WINDBG RESOLVED**: TTD trace confirmed game writes 0x00; file's 0x0b is from different session |
| 2026-01-07 | Confirmed: NbClassVersionsInfo is context-dependent, varies between saves, parser correctly preserves it |
