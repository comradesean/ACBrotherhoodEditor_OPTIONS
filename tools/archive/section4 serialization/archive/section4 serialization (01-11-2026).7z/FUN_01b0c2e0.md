                             **************************************************************
                             *                          FUNCTION                          *
                             **************************************************************
                             undefined FUN_01b0c2e0()
                               assume FS_OFFSET = 0xffdff000
             undefined         <UNASSIGNED>   <RETURN>
             undefined4        Stack[-0x8]:4  local_8                                 XREF[2]:     01b0c5bf(W), 
                                                                                                   01b0c5e0(W)  
             undefined4        Stack[-0x10]:4 local_10                                XREF[1]:     01b0c9a1(R)  
             undefined4        Stack[-0x14]:4 local_14                                XREF[11]:    01b0c50c(*), 
                                                                                                   01b0c514(W), 
                                                                                                   01b0c599(R), 
                                                                                                   01b0c5d9(R), 
                                                                                                   01b0c608(R), 
                                                                                                   01b0c60d(W), 
                                                                                                   01b0c624(R), 
                                                                                                   01b0c63c(R), 
                                                                                                   01b0c653(R), 
                                                                                                   01b0c7ea(W), 
                                                                                                   01b0c849(R)  
             undefined4        Stack[-0x18]:4 local_18                                XREF[9]:     01b0c51f(W), 
                                                                                                   01b0c535(W), 
                                                                                                   01b0c5f2(W), 
                                                                                                   01b0c64f(R), 
                                                                                                   01b0c72b(W), 
                                                                                                   01b0c735(W), 
                                                                                                   01b0c753(R), 
                                                                                                   01b0c7fc(W), 
                                                                                                   01b0c846(R)  
             undefined1        Stack[-0x1c]:1 local_1c                                XREF[4]:     01b0c6c0(W), 
                                                                                                   01b0c6f3(R), 
                                                                                                   01b0c720(R), 
                                                                                                   01b0c7f5(R)  
             undefined4        Stack[-0x20]:4 local_20                                XREF[12]:    01b0c6b7(W), 
                                                                                                   01b0c6bd(*), 
                                                                                                   01b0c6d0(*), 
                                                                                                   01b0c701(R), 
                                                                                                   01b0c717(R), 
                                                                                                   01b0c726(R), 
                                                                                                   01b0c730(R), 
                                                                                                   01b0c79e(*), 
                                                                                                   01b0c801(R), 
                                                                                                   01b0c81a(R), 
                                                                                                   01b0c870(R), 
                                                                                                   01b0c94a(*)  
             undefined4        Stack[-0x24]:4 local_24                                XREF[2]:     01b0c31d(W), 
                                                                                                   01b0c5fb(R)  
             undefined4        Stack[-0x28]:4 local_28                                XREF[9]:     01b0c31a(W), 
                                                                                                   01b0c4ce(R), 
                                                                                                   01b0c4f8(R), 
                                                                                                   01b0c51c(*), 
                                                                                                   01b0c52d(*), 
                                                                                                   01b0c552(*), 
                                                                                                   01b0c564(*), 
                                                                                                   01b0c585(*), 
                                                                                                   01b0c618(*)  
             undefined4        Stack[-0x2c]:4 local_2c                                XREF[5]:     01b0c310(W), 
                                                                                                   01b0c610(*), 
                                                                                                   01b0c627(R), 
                                                                                                   01b0c68c(R), 
                                                                                                   01b0c903(R)  
             undefined4        Stack[-0x30]:4 local_30                                XREF[4]:     01b0c614(*), 
                                                                                                   01b0c62a(R), 
                                                                                                   01b0c807(W), 
                                                                                                   01b0c84f(R)  
             undefined4        Stack[-0x34]:4 local_34                                XREF[1]:     01b0c694(W)  
             undefined4        Stack[-0x38]:4 local_38                                XREF[6]:     01b0c69f(W), 
                                                                                                   01b0c6e3(*), 
                                                                                                   01b0c7ca(*), 
                                                                                                   01b0c7d7(*), 
                                                                                                   01b0c8a1(*), 
                                                                                                   01b0c941(*)  
             undefined1        Stack[-0x3c]:1 local_3c                                XREF[2]:     01b0c590(W), 
                                                                                                   01b0c5a5(R)  
             undefined4        Stack[-0x40]:4 local_40                                XREF[5]:     01b0c57e(W), 
                                                                                                   01b0c589(*), 
                                                                                                   01b0c5ab(R), 
                                                                                                   01b0c5b2(R), 
                                                                                                   01b0c916(W)  
             undefined4        Stack[-0x44]:4 local_44                                XREF[3]:     01b0c5bc(W), 
                                                                                                   01b0c89d(*), 
                                                                                                   01b0c8b3(R)  
             undefined         Stack[-0x5c]:1 local_5c                                XREF[4]:     01b0c7a2(*), 
                                                                                                   01b0c87f(*), 
                                                                                                   01b0c88f(*), 
                                                                                                   01b0c8d1(*)  
             undefined         Stack[-0x74]:1 local_74                                XREF[2]:     01b0c58d(*), 
                                                                                                   01b0c59d(*)  
             undefined1        Stack[-0x79]:1 local_79                                XREF[2]:     01b0c66a(R), 
                                                                                                   01b0c682(W)  
             undefined         Stack[-0xc0]:1 local_c0                                XREF[4]:     01b0c544(*), 
                                                                                                   01b0c679(*), 
                                                                                                   01b0c740(*), 
                                                                                                   01b0c781(*)  
                             FUN_01b0c2e0                                    XREF[7]:     FUN_01b091a0:01b09471(c), 
                                                                                          FUN_01b091a0:01b095af(c), 
                                                                                          01b0c64a(c), 01b0c75f(c), 
                                                                                          01b0c8df(c), 
                                                                                          FUN_01b0ca30:01b0cd7b(c), 
                                                                                          FUN_01b0ca30:01b0cf79(c)  
        01b0c2e0 55              PUSH       EBP
        01b0c2e1 8b ec           MOV        EBP,ESP
        01b0c2e3 6a ff           PUSH       -0x1
        01b0c2e5 68 37 1d        PUSH       LAB_023c1d37
                 3c 02
        01b0c2ea 64 a1 00        MOV        EAX,FS:[0x0]=>ExceptionList                      = 00000000
                 00 00 00
        01b0c2f0 50              PUSH       EAX
        01b0c2f1 64 89 25        MOV        dword ptr FS:[0x0]=>ExceptionList,ESP            = 00000000
                 00 00 00 00
        01b0c2f8 81 ec b0        SUB        ESP,0xb0
                 00 00 00
        01b0c2fe 53              PUSH       EBX
        01b0c2ff 56              PUSH       ESI
        01b0c300 8b 75 0c        MOV        ESI,dword ptr [EBP + Stack[0x8]]
        01b0c303 8d 46 08        LEA        EAX,[ESI + 0x8]
        01b0c306 8b d9           MOV        EBX,ECX
        01b0c308 8a 4d 10        MOV        CL,byte ptr [EBP + Stack[0xc]]
        01b0c30b 84 c9           TEST       CL,CL
        01b0c30d 57              PUSH       EDI
        01b0c30e 8b 38           MOV        EDI,dword ptr [EAX]
        01b0c310 89 45 d8        MOV        dword ptr [EBP + local_2c],EAX
        01b0c313 8b 40 04        MOV        EAX,dword ptr [EAX + 0x4]
        01b0c316 0f 94 45 13     SETZ       byte ptr [EBP + Stack[0xf]]
        01b0c31a 89 7d dc        MOV        dword ptr [EBP + local_28],EDI
        01b0c31d 89 45 e0        MOV        dword ptr [EBP + local_24],EAX
        01b0c320 84 c9           TEST       CL,CL
        01b0c322 74 05           JZ         LAB_01b0c329
        01b0c324 c1 e8 17        SHR        EAX,0x17
        01b0c327 eb 03           JMP        LAB_01b0c32c
                             LAB_01b0c329                                    XREF[1]:     01b0c322(j)  
        01b0c329 c1 e8 10        SHR        EAX,0x10
                             LAB_01b0c32c                                    XREF[1]:     01b0c327(j)  
        01b0c32c 83 e0 3f        AND        EAX,0x3f
        01b0c32f 83 f8 1e        CMP        EAX,0x1e
        01b0c332 0f 87 4e        JA         switchD_01b0c338::default
                 06 00 00
                             switchD_01b0c338::switchD
        01b0c338 ff 24 85        JMP        dword ptr [EAX*0x4 + switchD_01b0c338::switchd   = 01b0c33f
                 b4 c9 b0 01
                             switchD_01b0c338::caseD_0                       XREF[2]:     01b0c338(j), 01b0c9b4(*)  
        01b0c33f 8b 45 08        MOV        EAX,dword ptr [EBP + Stack[0x4]]
        01b0c342 56              PUSH       ESI
        01b0c343 50              PUSH       EAX
        01b0c344 8b cb           MOV        ECX,EBX
        01b0c346 e8 05 d3        CALL       FUN_01b09650                                     undefined FUN_01b09650()
                 ff ff
        01b0c34b e9 36 06        JMP        switchD_01b0c338::default
                 00 00
                             switchD_01b0c338::caseD_1                       XREF[2]:     01b0c338(j), 01b0c9b8(*)  
        01b0c350 8b 4d 08        MOV        ECX,dword ptr [EBP + Stack[0x4]]
        01b0c353 51              PUSH       ECX
        01b0c354 56              PUSH       ESI
        01b0c355 8b cb           MOV        ECX,EBX
        01b0c357 e8 04 5d        CALL       FUN_01b12060                                     undefined FUN_01b12060()
                 00 00
        01b0c35c e9 25 06        JMP        switchD_01b0c338::default
                 00 00
                             switchD_01b0c338::caseD_2                       XREF[2]:     01b0c338(j), 01b0c9bc(*)  
        01b0c361 8b 55 08        MOV        EDX,dword ptr [EBP + Stack[0x4]]
        01b0c364 52              PUSH       EDX
        01b0c365 56              PUSH       ESI
        01b0c366 8b cb           MOV        ECX,EBX
        01b0c368 e8 73 5e        CALL       FUN_01b121e0                                     undefined FUN_01b121e0()
                 00 00
        01b0c36d e9 14 06        JMP        switchD_01b0c338::default
                 00 00
                             switchD_01b0c338::caseD_3                       XREF[2]:     01b0c338(j), 01b0c9c0(*)  
        01b0c372 8b 45 08        MOV        EAX,dword ptr [EBP + Stack[0x4]]
        01b0c375 50              PUSH       EAX
        01b0c376 56              PUSH       ESI
        01b0c377 8b cb           MOV        ECX,EBX
        01b0c379 e8 a2 5d        CALL       FUN_01b12120                                     undefined FUN_01b12120()
                 00 00
        01b0c37e e9 03 06        JMP        switchD_01b0c338::default
                 00 00
                             switchD_01b0c338::caseD_4                       XREF[2]:     01b0c338(j), 01b0c9c4(*)  
        01b0c383 8b 4d 08        MOV        ECX,dword ptr [EBP + Stack[0x4]]
        01b0c386 51              PUSH       ECX
        01b0c387 56              PUSH       ESI
        01b0c388 8b cb           MOV        ECX,EBX
        01b0c38a e8 d1 5f        CALL       FUN_01b12360                                     undefined FUN_01b12360()
                 00 00
        01b0c38f e9 f2 05        JMP        switchD_01b0c338::default
                 00 00
                             switchD_01b0c338::caseD_5                       XREF[2]:     01b0c338(j), 01b0c9c8(*)  
        01b0c394 8b 55 08        MOV        EDX,dword ptr [EBP + Stack[0x4]]
        01b0c397 52              PUSH       EDX
        01b0c398 56              PUSH       ESI
        01b0c399 8b cb           MOV        ECX,EBX
        01b0c39b e8 00 5f        CALL       FUN_01b122a0                                     undefined FUN_01b122a0()
                 00 00
        01b0c3a0 e9 e1 05        JMP        switchD_01b0c338::default
                 00 00
                             switchD_01b0c338::caseD_6                       XREF[2]:     01b0c338(j), 01b0c9cc(*)  
        01b0c3a5 8b 45 08        MOV        EAX,dword ptr [EBP + Stack[0x4]]
        01b0c3a8 50              PUSH       EAX
        01b0c3a9 56              PUSH       ESI
        01b0c3aa 8b cb           MOV        ECX,EBX
        01b0c3ac e8 6f 60        CALL       FUN_01b12420                                     undefined FUN_01b12420()
                 00 00
        01b0c3b1 e9 d0 05        JMP        switchD_01b0c338::default
                 00 00
                             switchD_01b0c338::caseD_7                       XREF[2]:     01b0c338(j), 01b0c9d0(*)  
        01b0c3b6 8b 4d 08        MOV        ECX,dword ptr [EBP + Stack[0x4]]
        01b0c3b9 51              PUSH       ECX
        01b0c3ba 56              PUSH       ESI
        01b0c3bb 8b cb           MOV        ECX,EBX
        01b0c3bd e8 de 6b        CALL       FUN_01b12fa0                                     undefined FUN_01b12fa0()
                 00 00
        01b0c3c2 e9 bf 05        JMP        switchD_01b0c338::default
                 00 00
                             switchD_01b0c338::caseD_8                       XREF[2]:     01b0c338(j), 01b0c9d4(*)  
        01b0c3c7 8b 55 08        MOV        EDX,dword ptr [EBP + Stack[0x4]]
        01b0c3ca 52              PUSH       EDX
        01b0c3cb 56              PUSH       ESI
        01b0c3cc 8b cb           MOV        ECX,EBX
        01b0c3ce e8 bd 61        CALL       FUN_01b12590                                     undefined FUN_01b12590()
                 00 00
        01b0c3d3 e9 ae 05        JMP        switchD_01b0c338::default
                 00 00
                             switchD_01b0c338::caseD_9                       XREF[2]:     01b0c338(j), 01b0c9d8(*)  
        01b0c3d8 8b 45 08        MOV        EAX,dword ptr [EBP + Stack[0x4]]
        01b0c3db 50              PUSH       EAX
        01b0c3dc 56              PUSH       ESI
        01b0c3dd 8b cb           MOV        ECX,EBX
        01b0c3df e8 fc 60        CALL       FUN_01b124e0                                     undefined FUN_01b124e0()
                 00 00
        01b0c3e4 e9 9d 05        JMP        switchD_01b0c338::default
                 00 00
                             switchD_01b0c338::caseD_a                       XREF[2]:     01b0c338(j), 01b0c9dc(*)  
        01b0c3e9 8b 4d 08        MOV        ECX,dword ptr [EBP + Stack[0x4]]
        01b0c3ec 51              PUSH       ECX
        01b0c3ed 56              PUSH       ESI
        01b0c3ee 8b cb           MOV        ECX,EBX
        01b0c3f0 e8 4b 62        CALL       FUN_01b12640                                     undefined FUN_01b12640()
                 00 00
        01b0c3f5 e9 8c 05        JMP        switchD_01b0c338::default
                 00 00
                             switchD_01b0c338::caseD_b                       XREF[2]:     01b0c338(j), 01b0c9e0(*)  
        01b0c3fa 8b 55 08        MOV        EDX,dword ptr [EBP + Stack[0x4]]
        01b0c3fd 52              PUSH       EDX
        01b0c3fe 56              PUSH       ESI
        01b0c3ff 8b cb           MOV        ECX,EBX
        01b0c401 e8 ea 62        CALL       FUN_01b126f0                                     undefined FUN_01b126f0()
                 00 00
        01b0c406 e9 7b 05        JMP        switchD_01b0c338::default
                 00 00
                             switchD_01b0c338::caseD_c                       XREF[2]:     01b0c338(j), 01b0c9e4(*)  
        01b0c40b 8b 45 08        MOV        EAX,dword ptr [EBP + Stack[0x4]]
        01b0c40e 50              PUSH       EAX
        01b0c40f 56              PUSH       ESI
        01b0c410 8b cb           MOV        ECX,EBX
        01b0c412 e8 89 63        CALL       FUN_01b127a0                                     undefined FUN_01b127a0()
                 00 00
        01b0c417 e9 6a 05        JMP        switchD_01b0c338::default
                 00 00
                             switchD_01b0c338::caseD_d                       XREF[2]:     01b0c338(j), 01b0c9e8(*)  
        01b0c41c 8b 4d 08        MOV        ECX,dword ptr [EBP + Stack[0x4]]
        01b0c41f 51              PUSH       ECX
        01b0c420 56              PUSH       ESI
        01b0c421 8b cb           MOV        ECX,EBX
        01b0c423 e8 28 64        CALL       FUN_01b12850                                     undefined FUN_01b12850()
                 00 00
        01b0c428 e9 59 05        JMP        switchD_01b0c338::default
                 00 00
                             switchD_01b0c338::caseD_e                       XREF[2]:     01b0c338(j), 01b0c9ec(*)  
        01b0c42d 8b 55 08        MOV        EDX,dword ptr [EBP + Stack[0x4]]
        01b0c430 52              PUSH       EDX
        01b0c431 56              PUSH       ESI
        01b0c432 8b cb           MOV        ECX,EBX
        01b0c434 e8 27 66        CALL       FUN_01b12a60                                     undefined FUN_01b12a60()
                 00 00
        01b0c439 e9 48 05        JMP        switchD_01b0c338::default
                 00 00
                             switchD_01b0c338::caseD_f                       XREF[2]:     01b0c338(j), 01b0c9f0(*)  
        01b0c43e 8b 45 08        MOV        EAX,dword ptr [EBP + Stack[0x4]]
        01b0c441 50              PUSH       EAX
        01b0c442 56              PUSH       ESI
        01b0c443 8b cb           MOV        ECX,EBX
        01b0c445 e8 b6 64        CALL       FUN_01b12900                                     undefined FUN_01b12900()
                 00 00
        01b0c44a e9 37 05        JMP        switchD_01b0c338::default
                 00 00
                             switchD_01b0c338::caseD_10                      XREF[2]:     01b0c338(j), 01b0c9f4(*)  
        01b0c44f 8b 4d 08        MOV        ECX,dword ptr [EBP + Stack[0x4]]
        01b0c452 51              PUSH       ECX
        01b0c453 56              PUSH       ESI
        01b0c454 8b cb           MOV        ECX,EBX
        01b0c456 e8 55 65        CALL       FUN_01b129b0                                     undefined FUN_01b129b0()
                 00 00
        01b0c45b e9 26 05        JMP        switchD_01b0c338::default
                 00 00
                             switchD_01b0c338::caseD_11                      XREF[2]:     01b0c338(j), 01b0c9f8(*)  
        01b0c460 8b 55 08        MOV        EDX,dword ptr [EBP + Stack[0x4]]
        01b0c463 56              PUSH       ESI
        01b0c464 52              PUSH       EDX
        01b0c465 8b cb           MOV        ECX,EBX
        01b0c467 e8 14 d4        CALL       FUN_01b09880                                     undefined FUN_01b09880()
                 ff ff
        01b0c46c e9 15 05        JMP        switchD_01b0c338::default
                 00 00
                             switchD_01b0c338::caseD_1e                      XREF[3]:     01b0c338(j), 01b0c9fc(*), 
                             switchD_01b0c338::caseD_12                                   01b0ca2c(*)  
        01b0c471 8b 45 08        MOV        EAX,dword ptr [EBP + Stack[0x4]]
        01b0c474 56              PUSH       ESI
        01b0c475 50              PUSH       EAX
        01b0c476 57              PUSH       EDI
        01b0c477 8b cb           MOV        ECX,EBX
        01b0c479 e8 22 d5        CALL       FUN_01b099a0                                     undefined FUN_01b099a0()
                 ff ff
        01b0c47e e9 03 05        JMP        switchD_01b0c338::default
                 00 00
                             switchD_01b0c338::caseD_1c                      XREF[2]:     01b0c338(j), 01b0ca24(*)  
        01b0c483 8b 4d 08        MOV        ECX,dword ptr [EBP + Stack[0x4]]
        01b0c486 56              PUSH       ESI
        01b0c487 51              PUSH       ECX
        01b0c488 57              PUSH       EDI
        01b0c489 8b cb           MOV        ECX,EBX
        01b0c48b e8 d0 e9        CALL       FUN_01b0ae60                                     undefined FUN_01b0ae60()
                 ff ff
        01b0c490 e9 f1 04        JMP        switchD_01b0c338::default
                 00 00
                             switchD_01b0c338::caseD_13                      XREF[2]:     01b0c338(j), 01b0ca00(*)  
        01b0c495 8b 55 08        MOV        EDX,dword ptr [EBP + Stack[0x4]]
        01b0c498 56              PUSH       ESI
        01b0c499 52              PUSH       EDX
        01b0c49a 8b cb           MOV        ECX,EBX
        01b0c49c e8 bf df        CALL       FUN_01b0a460                                     undefined FUN_01b0a460()
                 ff ff
        01b0c4a1 e9 e0 04        JMP        switchD_01b0c338::default
                 00 00
                             switchD_01b0c338::caseD_14                      XREF[2]:     01b0c338(j), 01b0ca04(*)  
        01b0c4a6 8b 45 08        MOV        EAX,dword ptr [EBP + Stack[0x4]]
        01b0c4a9 56              PUSH       ESI
        01b0c4aa 50              PUSH       EAX
        01b0c4ab 8b cb           MOV        ECX,EBX
        01b0c4ad e8 0e ee        CALL       FUN_01b0b2c0                                     undefined FUN_01b0b2c0()
                 ff ff
        01b0c4b2 e9 cf 04        JMP        switchD_01b0c338::default
                 00 00
                             switchD_01b0c338::caseD_16                      XREF[2]:     01b0c338(j), 01b0ca0c(*)  
        01b0c4b7 57              PUSH       EDI
        01b0c4b8 b9 b0 24        MOV        ECX,DAT_02a624b0
                 a6 02
        01b0c4bd e8 1e 31        CALL       FUN_01aff5e0                                     undefined FUN_01aff5e0()
                 ff ff
        01b0c4c2 33 c9           XOR        ECX,ECX
        01b0c4c4 85 c0           TEST       EAX,EAX
        01b0c4c6 74 03           JZ         LAB_01b0c4cb
        01b0c4c8 8b 48 30        MOV        ECX,dword ptr [EAX + 0x30]
                             LAB_01b0c4cb                                    XREF[1]:     01b0c4c6(j)  
        01b0c4cb 8b 55 08        MOV        EDX,dword ptr [EBP + Stack[0x4]]
        01b0c4ce 8b 45 dc        MOV        EAX,dword ptr [EBP + local_28]
        01b0c4d1 56              PUSH       ESI
        01b0c4d2 52              PUSH       EDX
        01b0c4d3 51              PUSH       ECX
        01b0c4d4 50              PUSH       EAX
        01b0c4d5 8b cb           MOV        ECX,EBX
        01b0c4d7 e8 34 f2        CALL       FUN_01b0b710                                     undefined FUN_01b0b710()
                 ff ff
        01b0c4dc e9 a5 04        JMP        switchD_01b0c338::default
                 00 00
                             switchD_01b0c338::caseD_15                      XREF[2]:     01b0c338(j), 01b0ca08(*)  
        01b0c4e1 57              PUSH       EDI
        01b0c4e2 b9 b0 24        MOV        ECX,DAT_02a624b0
                 a6 02
        01b0c4e7 e8 f4 30        CALL       FUN_01aff5e0                                     undefined FUN_01aff5e0()
                 ff ff
        01b0c4ec 33 c9           XOR        ECX,ECX
        01b0c4ee 85 c0           TEST       EAX,EAX
        01b0c4f0 74 03           JZ         LAB_01b0c4f5
        01b0c4f2 8b 48 30        MOV        ECX,dword ptr [EAX + 0x30]
                             LAB_01b0c4f5                                    XREF[1]:     01b0c4f0(j)  
        01b0c4f5 8b 55 08        MOV        EDX,dword ptr [EBP + Stack[0x4]]
        01b0c4f8 8b 45 dc        MOV        EAX,dword ptr [EBP + local_28]
        01b0c4fb 56              PUSH       ESI
        01b0c4fc 52              PUSH       EDX
        01b0c4fd 51              PUSH       ECX
        01b0c4fe 50              PUSH       EAX
        01b0c4ff 8b cb           MOV        ECX,EBX
        01b0c501 e8 9a f3        CALL       FUN_01b0b8a0                                     undefined FUN_01b0b8a0()
                 ff ff
        01b0c506 e9 7b 04        JMP        switchD_01b0c338::default
                 00 00
                             switchD_01b0c338::caseD_17                      XREF[2]:     01b0c338(j), 01b0ca10(*)  
        01b0c50b 56              PUSH       ESI
        01b0c50c 8d 4d f0        LEA        ECX=>local_14,[EBP + -0x10]
        01b0c50f 51              PUSH       ECX
        01b0c510 33 ff           XOR        EDI,EDI
        01b0c512 8b cb           MOV        ECX,EBX
        01b0c514 89 7d f0        MOV        dword ptr [EBP + local_14],EDI
        01b0c517 e8 c4 b6        CALL       FUN_01b07be0                                     undefined FUN_01b07be0()
                 ff ff
        01b0c51c 8d 4d dc        LEA        ECX=>local_28,[EBP + -0x24]
        01b0c51f 89 7d ec        MOV        dword ptr [EBP + local_18],EDI
        01b0c522 e8 89 42        CALL       FUN_01b607b0                                     undefined FUN_01b607b0()
                 05 00
        01b0c527 84 c0           TEST       AL,AL
        01b0c529 74 0d           JZ         LAB_01b0c538
        01b0c52b 6a 01           PUSH       0x1
        01b0c52d 8d 4d dc        LEA        ECX=>local_28,[EBP + -0x24]
        01b0c530 e8 5b 3f        CALL       FUN_01b60490                                     undefined FUN_01b60490()
                 05 00
        01b0c535 89 45 ec        MOV        dword ptr [EBP + local_18],EAX
                             LAB_01b0c538                                    XREF[1]:     01b0c529(j)  
        01b0c538 f6 43 4e 02     TEST       byte ptr [EBX + 0x4e],0x2
        01b0c53c 8d 73 08        LEA        ESI,[EBX + 0x8]
        01b0c53f b9 13 00        MOV        ECX,0x13
                 00 00
        01b0c544 8d bd 44        LEA        EDI=>local_c0,[EBP + 0xffffff44]
                 ff ff ff
        01b0c54a f3 a5           MOVSD.REP  ES:EDI,ESI
        01b0c54c 0f 84 a9        JZ         LAB_01b0c5fb
                 00 00 00
        01b0c552 8d 4d dc        LEA        ECX=>local_28,[EBP + -0x24]
        01b0c555 e8 56 42        CALL       FUN_01b607b0                                     undefined FUN_01b607b0()
                 05 00
        01b0c55a 84 c0           TEST       AL,AL
        01b0c55c 74 5b           JZ         LAB_01b0c5b9
        01b0c55e f6 43 4e 08     TEST       byte ptr [EBX + 0x4e],0x8
        01b0c562 74 0c           JZ         LAB_01b0c570
        01b0c564 8d 4d dc        LEA        ECX=>local_28,[EBP + -0x24]
        01b0c567 e8 04 1f        CALL       FUN_0073e470                                     undefined FUN_0073e470()
                 c3 fe
        01b0c56c 84 c0           TEST       AL,AL
        01b0c56e 75 49           JNZ        LAB_01b0c5b9
                             LAB_01b0c570                                    XREF[1]:     01b0c562(j)  
        01b0c570 8b 45 0c        MOV        EAX,dword ptr [EBP + Stack[0x8]]
        01b0c573 8b 08           MOV        ECX,dword ptr [EAX]
        01b0c575 8b 55 08        MOV        EDX,dword ptr [EBP + Stack[0x4]]
        01b0c578 c1 e9 09        SHR        ECX,0x9
        01b0c57b 80 e1 01        AND        CL,0x1
        01b0c57e 89 55 c4        MOV        dword ptr [EBP + local_40],EDX
        01b0c581 0f b6 d1        MOVZX      EDX,CL
        01b0c584 52              PUSH       EDX
        01b0c585 8d 45 dc        LEA        EAX=>local_28,[EBP + -0x24]
        01b0c588 50              PUSH       EAX
        01b0c589 8d 4d c4        LEA        ECX=>local_40,[EBP + -0x3c]
        01b0c58c 51              PUSH       ECX
        01b0c58d 8d 4d 90        LEA        ECX=>local_74,[EBP + -0x70]
        01b0c590 c6 45 c8 00     MOV        byte ptr [EBP + local_3c],0x0
        01b0c594 e8 c7 5b        CALL       FUN_01b42160                                     undefined FUN_01b42160()
                 03 00
        01b0c599 8b 55 f0        MOV        EDX,dword ptr [EBP + local_14]
        01b0c59c 52              PUSH       EDX
        01b0c59d 8d 4d 90        LEA        ECX=>local_74,[EBP + -0x70]
        01b0c5a0 e8 fb 65        CALL       FUN_01b42ba0                                     undefined FUN_01b42ba0()
                 03 00
        01b0c5a5 80 7d c8 00     CMP        byte ptr [EBP + local_3c],0x0
        01b0c5a9 74 07           JZ         LAB_01b0c5b2
        01b0c5ab 8b 45 c4        MOV        EAX,dword ptr [EBP + local_40]
        01b0c5ae 8b 30           MOV        ESI,dword ptr [EAX]
        01b0c5b0 eb 5e           JMP        LAB_01b0c610
                             LAB_01b0c5b2                                    XREF[1]:     01b0c5a9(j)  
        01b0c5b2 8b 4d c4        MOV        ECX,dword ptr [EBP + local_40]
        01b0c5b5 8b 31           MOV        ESI,dword ptr [ECX]
        01b0c5b7 eb 57           JMP        LAB_01b0c610
                             LAB_01b0c5b9                                    XREF[2]:     01b0c55c(j), 01b0c56e(j)  
        01b0c5b9 8b 75 08        MOV        ESI,dword ptr [EBP + Stack[0x4]]
        01b0c5bc 89 75 c0        MOV        dword ptr [EBP + local_44],ESI
        01b0c5bf c7 45 fc        MOV        dword ptr [EBP + local_8],0x0
                 00 00 00 00
        01b0c5c6 85 f6           TEST       ESI,ESI
        01b0c5c8 74 09           JZ         LAB_01b0c5d3
        01b0c5ca 6a 00           PUSH       0x0
        01b0c5cc 8b ce           MOV        ECX,ESI
        01b0c5ce e8 9d 80        CALL       FUN_01ae4670                                     undefined FUN_01ae4670()
                 fd ff
                             LAB_01b0c5d3                                    XREF[1]:     01b0c5c8(j)  
        01b0c5d3 8b 15 a8        MOV        EDX,dword ptr [DAT_02a622a8]
                 22 a6 02
        01b0c5d9 8b 45 f0        MOV        EAX,dword ptr [EBP + local_14]
        01b0c5dc 52              PUSH       EDX
        01b0c5dd 50              PUSH       EAX
        01b0c5de 8b ce           MOV        ECX,ESI
        01b0c5e0 c7 45 fc        MOV        dword ptr [EBP + local_8],0xffffffff
                 ff ff ff ff
        01b0c5e7 e8 74 68        CALL       FUN_01b12e60                                     undefined FUN_01b12e60()
                 00 00
        01b0c5ec 8b 36           MOV        ESI,dword ptr [ESI]
        01b0c5ee 80 4b 4e 08     OR         byte ptr [EBX + 0x4e],0x8
        01b0c5f2 c7 45 ec        MOV        dword ptr [EBP + local_18],0x30
                 30 00 00 00
        01b0c5f9 eb 15           JMP        LAB_01b0c610
                             LAB_01b0c5fb                                    XREF[1]:     01b0c54c(j)  
        01b0c5fb 8b 45 e0        MOV        EAX,dword ptr [EBP + local_24]
        01b0c5fe 25 ff 7f        AND        EAX,0x7fff
                 00 00
        01b0c603 8b 75 08        MOV        ESI,dword ptr [EBP + Stack[0x4]]
        01b0c606 74 08           JZ         LAB_01b0c610
        01b0c608 39 45 f0        CMP        dword ptr [EBP + local_14],EAX
        01b0c60b 76 03           JBE        LAB_01b0c610
        01b0c60d 89 45 f0        MOV        dword ptr [EBP + local_14],EAX
                             LAB_01b0c610                                    XREF[5]:     01b0c5b0(j), 01b0c5b7(j), 
                                                                                          01b0c5f9(j), 01b0c606(j), 
                                                                                          01b0c60b(j)  
        01b0c610 8d 4d d8        LEA        ECX=>local_2c,[EBP + -0x28]
        01b0c613 51              PUSH       ECX
        01b0c614 8d 55 d4        LEA        EDX=>local_30,[EBP + -0x2c]
        01b0c617 52              PUSH       EDX
        01b0c618 8d 4d dc        LEA        ECX=>local_28,[EBP + -0x24]
        01b0c61b e8 00 40        CALL       FUN_01b60620                                     undefined FUN_01b60620()
                 05 00
        01b0c620 84 c0           TEST       AL,AL
        01b0c622 74 16           JZ         LAB_01b0c63a
        01b0c624 8b 45 f0        MOV        EAX,dword ptr [EBP + local_14]
        01b0c627 8b 4d d8        MOV        ECX,dword ptr [EBP + local_2c]
        01b0c62a 8b 55 d4        MOV        EDX,dword ptr [EBP + local_30]
        01b0c62d 50              PUSH       EAX
        01b0c62e 51              PUSH       ECX
        01b0c62f 52              PUSH       EDX
        01b0c630 56              PUSH       ESI
        01b0c631 8b cb           MOV        ECX,EBX
        01b0c633 e8 68 ae        CALL       FUN_01b074a0                                     undefined FUN_01b074a0()
                 ff ff
        01b0c638 eb 1e           JMP        LAB_01b0c658
                             LAB_01b0c63a                                    XREF[1]:     01b0c622(j)  
        01b0c63a 33 ff           XOR        EDI,EDI
        01b0c63c 39 7d f0        CMP        dword ptr [EBP + local_14],EDI
        01b0c63f 76 17           JBE        LAB_01b0c658
                             LAB_01b0c641                                    XREF[1]:     01b0c656(j)  
        01b0c641 8b 45 0c        MOV        EAX,dword ptr [EBP + Stack[0x8]]
        01b0c644 6a 01           PUSH       0x1
        01b0c646 50              PUSH       EAX
        01b0c647 56              PUSH       ESI
        01b0c648 8b cb           MOV        ECX,EBX
        01b0c64a e8 91 fc        CALL       FUN_01b0c2e0                                     undefined FUN_01b0c2e0()
                 ff ff
        01b0c64f 03 75 ec        ADD        ESI,dword ptr [EBP + local_18]
        01b0c652 47              INC        EDI
        01b0c653 3b 7d f0        CMP        EDI,dword ptr [EBP + local_14]
        01b0c656 72 e9           JC         LAB_01b0c641
                             LAB_01b0c658                                    XREF[2]:     01b0c638(j), 01b0c63f(j)  
        01b0c658 8b 4b 04        MOV        ECX,dword ptr [EBX + 0x4]
        01b0c65b 8b 11           MOV        EDX,dword ptr [ECX]
        01b0c65d 8b 42 10        MOV        EAX,dword ptr [EDX + 0x10]
        01b0c660 68 4c 4c        PUSH       s_Values_02554c4c                                = "Values"
                 55 02
        01b0c665 ff d0           CALL       EAX
        01b0c667 8a 4b 4f        MOV        CL,byte ptr [EBX + 0x4f]
        01b0c66a 8a 45 8b        MOV        AL,byte ptr [EBP + local_79]
        01b0c66d 32 c8           XOR        CL,AL
        01b0c66f 80 e1 01        AND        CL,0x1
        01b0c672 32 c1           XOR        AL,CL
        01b0c674 b9 13 00        MOV        ECX,0x13
                 00 00
        01b0c679 8d b5 44        LEA        ESI=>local_c0,[EBP + 0xffffff44]
                 ff ff ff
        01b0c67f 8d 7b 08        LEA        EDI,[EBX + 0x8]
        01b0c682 88 45 8b        MOV        byte ptr [EBP + local_79],AL
        01b0c685 f3 a5           MOVSD.REP  ES:EDI,ESI
        01b0c687 e9 fa 02        JMP        switchD_01b0c338::default
                 00 00
                             switchD_01b0c338::caseD_1d                      XREF[3]:     01b0c338(j), 01b0ca14(*), 
                             switchD_01b0c338::caseD_18                                   01b0ca28(*)  
        01b0c68c 8b 7d d8        MOV        EDI,dword ptr [EBP + local_2c]
        01b0c68f 8b 47 04        MOV        EAX,dword ptr [EDI + 0x4]
        01b0c692 8b 17           MOV        EDX,dword ptr [EDI]
        01b0c694 89 45 d0        MOV        dword ptr [EBP + local_34],EAX
        01b0c697 c1 e8 10        SHR        EAX,0x10
        01b0c69a 83 e0 3f        AND        EAX,0x3f
        01b0c69d 33 c9           XOR        ECX,ECX
        01b0c69f 89 55 cc        MOV        dword ptr [EBP + local_38],EDX
        01b0c6a2 83 f8 18        CMP        EAX,0x18
        01b0c6a5 75 09           JNZ        LAB_01b0c6b0
        01b0c6a7 85 c9           TEST       ECX,ECX
        01b0c6a9 75 05           JNZ        LAB_01b0c6b0
        01b0c6ab 8d 41 01        LEA        EAX,[ECX + 0x1]
        01b0c6ae eb 02           JMP        LAB_01b0c6b2
                             LAB_01b0c6b0                                    XREF[2]:     01b0c6a5(j), 01b0c6a9(j)  
        01b0c6b0 33 c0           XOR        EAX,EAX
                             LAB_01b0c6b2                                    XREF[1]:     01b0c6ae(j)  
        01b0c6b2 8b 4d 08        MOV        ECX,dword ptr [EBP + Stack[0x4]]
        01b0c6b5 84 c0           TEST       AL,AL
        01b0c6b7 89 4d e4        MOV        dword ptr [EBP + local_20],ECX
        01b0c6ba 0f 94 c2        SETZ       DL
        01b0c6bd 8d 4d e4        LEA        ECX=>local_20,[EBP + -0x1c]
        01b0c6c0 88 55 e8        MOV        byte ptr [EBP + local_1c],DL
        01b0c6c3 e8 38 29        CALL       FUN_01b0f000                                     undefined FUN_01b0f000()
                 00 00
        01b0c6c8 89 45 08        MOV        dword ptr [EBP + Stack[0x4]],EAX
        01b0c6cb 56              PUSH       ESI
        01b0c6cc 8d 45 08        LEA        EAX=>Stack[0x4],[EBP + 0x8]
        01b0c6cf 50              PUSH       EAX
        01b0c6d0 8d 4d e4        LEA        ECX=>local_20,[EBP + -0x1c]
        01b0c6d3 51              PUSH       ECX
        01b0c6d4 8b cb           MOV        ECX,EBX
        01b0c6d6 e8 15 f6        CALL       FUN_01b0bcf0                                     undefined FUN_01b0bcf0()
                 ff ff
        01b0c6db 84 c0           TEST       AL,AL
        01b0c6dd 0f 84 74        JZ         LAB_01b0c957
                 02 00 00
        01b0c6e3 8d 4d cc        LEA        ECX=>local_38,[EBP + -0x34]
        01b0c6e6 e8 c5 40        CALL       FUN_01b607b0                                     undefined FUN_01b607b0()
                 05 00
        01b0c6eb 84 c0           TEST       AL,AL
        01b0c6ed 0f 85 9e        JNZ        LAB_01b0c791
                 00 00 00
        01b0c6f3 38 45 e8        CMP        byte ptr [EBP + local_1c],AL
        01b0c6f6 74 15           JZ         LAB_01b0c70d
        01b0c6f8 8b 15 a8        MOV        EDX,dword ptr [DAT_02a622a8]
                 22 a6 02
        01b0c6fe 8b 45 08        MOV        EAX,dword ptr [EBP + Stack[0x4]]
        01b0c701 8b 4d e4        MOV        ECX,dword ptr [EBP + local_20]
        01b0c704 52              PUSH       EDX
        01b0c705 50              PUSH       EAX
        01b0c706 e8 d5 67        CALL       FUN_01b12ee0                                     undefined FUN_01b12ee0()
                 00 00
        01b0c70b eb 13           JMP        LAB_01b0c720
                             LAB_01b0c70d                                    XREF[1]:     01b0c6f6(j)  
        01b0c70d 8b 0d a8        MOV        ECX,dword ptr [DAT_02a622a8]
                 22 a6 02
        01b0c713 8b 55 08        MOV        EDX,dword ptr [EBP + Stack[0x4]]
        01b0c716 51              PUSH       ECX
        01b0c717 8b 4d e4        MOV        ECX,dword ptr [EBP + local_20]
        01b0c71a 52              PUSH       EDX
        01b0c71b e8 40 67        CALL       FUN_01b12e60                                     undefined FUN_01b12e60()
                 00 00
                             LAB_01b0c720                                    XREF[1]:     01b0c70b(j)  
        01b0c720 80 7d e8 00     CMP        byte ptr [EBP + local_1c],0x0
        01b0c724 74 0a           JZ         LAB_01b0c730
        01b0c726 8b 45 e4        MOV        EAX,dword ptr [EBP + local_20]
        01b0c729 8b 08           MOV        ECX,dword ptr [EAX]
        01b0c72b 89 4d ec        MOV        dword ptr [EBP + local_18],ECX
        01b0c72e eb 08           JMP        LAB_01b0c738
                             LAB_01b0c730                                    XREF[1]:     01b0c724(j)  
        01b0c730 8b 55 e4        MOV        EDX,dword ptr [EBP + local_20]
        01b0c733 8b 02           MOV        EAX,dword ptr [EDX]
        01b0c735 89 45 ec        MOV        dword ptr [EBP + local_18],EAX
                             LAB_01b0c738                                    XREF[1]:     01b0c72e(j)  
        01b0c738 8d 73 08        LEA        ESI,[EBX + 0x8]
        01b0c73b b9 13 00        MOV        ECX,0x13
                 00 00
        01b0c740 8d bd 44        LEA        EDI=>local_c0,[EBP + 0xffffff44]
                 ff ff ff
        01b0c746 f3 a5           MOVSD.REP  ES:EDI,ESI
        01b0c748 80 4b 4e 08     OR         byte ptr [EBX + 0x4e],0x8
        01b0c74c 33 f6           XOR        ESI,ESI
        01b0c74e 39 75 08        CMP        dword ptr [EBP + Stack[0x4]],ESI
        01b0c751 76 1a           JBE        LAB_01b0c76d
        01b0c753 8b 7d ec        MOV        EDI,dword ptr [EBP + local_18]
                             LAB_01b0c756                                    XREF[1]:     01b0c76b(j)  
        01b0c756 8b 4d 0c        MOV        ECX,dword ptr [EBP + Stack[0x8]]
        01b0c759 6a 01           PUSH       0x1
        01b0c75b 51              PUSH       ECX
        01b0c75c 57              PUSH       EDI
        01b0c75d 8b cb           MOV        ECX,EBX
        01b0c75f e8 7c fb        CALL       FUN_01b0c2e0                                     undefined FUN_01b0c2e0()
                 ff ff
        01b0c764 46              INC        ESI
        01b0c765 83 c7 30        ADD        EDI,0x30
        01b0c768 3b 75 08        CMP        ESI,dword ptr [EBP + Stack[0x4]]
        01b0c76b 72 e9           JC         LAB_01b0c756
                             LAB_01b0c76d                                    XREF[1]:     01b0c751(j)  
        01b0c76d 8b 4b 04        MOV        ECX,dword ptr [EBX + 0x4]
        01b0c770 8b 11           MOV        EDX,dword ptr [ECX]
        01b0c772 8b 42 10        MOV        EAX,dword ptr [EDX + 0x10]
        01b0c775 68 4c 4c        PUSH       s_Values_02554c4c                                = "Values"
                 55 02
        01b0c77a ff d0           CALL       EAX
        01b0c77c b9 13 00        MOV        ECX,0x13
                 00 00
        01b0c781 8d b5 44        LEA        ESI=>local_c0,[EBP + 0xffffff44]
                 ff ff ff
        01b0c787 8d 7b 08        LEA        EDI,[EBX + 0x8]
        01b0c78a f3 a5           MOVSD.REP  ES:EDI,ESI
        01b0c78c e9 f5 01        JMP        switchD_01b0c338::default
                 00 00
                             LAB_01b0c791                                    XREF[1]:     01b0c6ed(j)  
        01b0c791 8b 0e           MOV        ECX,dword ptr [ESI]
        01b0c793 c1 e9 09        SHR        ECX,0x9
        01b0c796 80 e1 01        AND        CL,0x1
        01b0c799 0f b6 d1        MOVZX      EDX,CL
        01b0c79c 52              PUSH       EDX
        01b0c79d 57              PUSH       EDI
        01b0c79e 8d 45 e4        LEA        EAX=>local_20,[EBP + -0x1c]
        01b0c7a1 50              PUSH       EAX
        01b0c7a2 8d 4d a8        LEA        ECX=>local_5c,[EBP + -0x58]
        01b0c7a5 e8 b6 59        CALL       FUN_01b42160                                     undefined FUN_01b42160()
                 03 00
        01b0c7aa 8b cb           MOV        ECX,EBX
        01b0c7ac e8 8f 43        CALL       FUN_00600b40                                     undefined FUN_00600b40()
                 af fe
        01b0c7b1 84 c0           TEST       AL,AL
        01b0c7b3 0f 84 c2        JZ         LAB_01b0c87b
                 00 00 00
        01b0c7b9 f7 06 00        TEST       dword ptr [ESI],0x10000
                 00 01 00
        01b0c7bf 0f 85 b6        JNZ        LAB_01b0c87b
                 00 00 00
        01b0c7c5 8b 7b 40        MOV        EDI,dword ptr [EBX + 0x40]
        01b0c7c8 6a 01           PUSH       0x1
        01b0c7ca 8d 4d cc        LEA        ECX=>local_38,[EBP + -0x34]
        01b0c7cd e8 be 3c        CALL       FUN_01b60490                                     undefined FUN_01b60490()
                 05 00
        01b0c7d2 0f af 45 08     IMUL       EAX,dword ptr [EBP + Stack[0x4]]
        01b0c7d6 50              PUSH       EAX
        01b0c7d7 8d 4d cc        LEA        ECX=>local_38,[EBP + -0x34]
        01b0c7da e8 b1 3d        CALL       FUN_01b60590                                     undefined FUN_01b60590()
                 05 00
        01b0c7df 0f b6 c8        MOVZX      ECX,AL
        01b0c7e2 51              PUSH       ECX
        01b0c7e3 8b cf           MOV        ECX,EDI
        01b0c7e5 e8 96 ce        CALL       FUN_01b29680                                     undefined FUN_01b29680()
                 01 00
        01b0c7ea 89 45 f0        MOV        dword ptr [EBP + local_14],EAX
        01b0c7ed 85 c0           TEST       EAX,EAX
        01b0c7ef 0f 84 86        JZ         LAB_01b0c87b
                 00 00 00
        01b0c7f5 80 7d e8 00     CMP        byte ptr [EBP + local_1c],0x0
        01b0c7f9 8b 4d 08        MOV        ECX,dword ptr [EBP + Stack[0x4]]
        01b0c7fc 89 4d ec        MOV        dword ptr [EBP + local_18],ECX
        01b0c7ff 74 66           JZ         LAB_01b0c867
        01b0c801 8b 7d e4        MOV        EDI,dword ptr [EBP + local_20]
        01b0c804 8b 57 04        MOV        EDX,dword ptr [EDI + 0x4]
        01b0c807 89 7d d4        MOV        dword ptr [EBP + local_30],EDI
        01b0c80a 83 c7 04        ADD        EDI,0x4
        01b0c80d c1 ea 0f        SHR        EDX,0xf
        01b0c810 f6 d2           NOT        DL
        01b0c812 89 7d 0c        MOV        dword ptr [EBP + Stack[0x8]],EDI
        01b0c815 f6 c2 01        TEST       DL,0x1
        01b0c818 74 35           JZ         LAB_01b0c84f
        01b0c81a 8b 45 e4        MOV        EAX,dword ptr [EBP + local_20]
        01b0c81d 8b 38           MOV        EDI,dword ptr [EAX]
        01b0c81f 85 ff           TEST       EDI,EDI
        01b0c821 74 26           JZ         LAB_01b0c849
        01b0c823 8b 0d f8        MOV        ECX,dword ptr [DAT_02a5e0f8]
                 e0 a5 02
        01b0c829 57              PUSH       EDI
        01b0c82a e8 91 fa        CALL       FUN_01abc2c0                                     undefined FUN_01abc2c0()
                 fa ff
        01b0c82f 8b 0d f4        MOV        ECX,dword ptr [DAT_02a5e0f4]
                 e0 a5 02
        01b0c835 8b 09           MOV        ECX,dword ptr [ECX]
        01b0c837 8b 11           MOV        EDX,dword ptr [ECX]
        01b0c839 6a 00           PUSH       0x0
        01b0c83b 6a 00           PUSH       0x0
        01b0c83d 50              PUSH       EAX
        01b0c83e 8b 42 14        MOV        EAX,dword ptr [EDX + 0x14]
        01b0c841 57              PUSH       EDI
        01b0c842 6a 04           PUSH       0x4
        01b0c844 ff d0           CALL       EAX
        01b0c846 8b 4d ec        MOV        ECX,dword ptr [EBP + local_18]
                             LAB_01b0c849                                    XREF[1]:     01b0c821(j)  
        01b0c849 8b 45 f0        MOV        EAX,dword ptr [EBP + local_14]
        01b0c84c 8b 7d 0c        MOV        EDI,dword ptr [EBP + Stack[0x8]]
                             LAB_01b0c84f                                    XREF[1]:     01b0c818(j)  
        01b0c84f 8b 55 d4        MOV        EDX,dword ptr [EBP + local_30]
        01b0c852 89 02           MOV        dword ptr [EDX],EAX
        01b0c854 8b 07           MOV        EAX,dword ptr [EDI]
        01b0c856 25 00 40        AND        EAX,0x40004000
                 00 40
        01b0c85b 81 e1 ff        AND        ECX,0x3fff
                 3f 00 00
        01b0c861 0b c1           OR         EAX,ECX
        01b0c863 89 07           MOV        dword ptr [EDI],EAX
        01b0c865 eb 14           JMP        LAB_01b0c87b
                             LAB_01b0c867                                    XREF[1]:     01b0c7ff(j)  
        01b0c867 6a 01           PUSH       0x1
        01b0c869 6a 01           PUSH       0x1
        01b0c86b 6a 01           PUSH       0x1
        01b0c86d 6a 01           PUSH       0x1
        01b0c86f 51              PUSH       ECX
        01b0c870 8b 4d e4        MOV        ECX,dword ptr [EBP + local_20]
        01b0c873 6a 00           PUSH       0x0
        01b0c875 50              PUSH       EAX
        01b0c876 e8 e5 8a        CALL       FUN_00425360                                     undefined FUN_00425360()
                 91 fe
                             LAB_01b0c87b                                    XREF[4]:     01b0c7b3(j), 01b0c7bf(j), 
                                                                                          01b0c7ef(j), 01b0c865(j)  
        01b0c87b 8b 4d 08        MOV        ECX,dword ptr [EBP + Stack[0x4]]
        01b0c87e 51              PUSH       ECX
        01b0c87f 8d 4d a8        LEA        ECX=>local_5c,[EBP + -0x58]
        01b0c882 e8 19 63        CALL       FUN_01b42ba0                                     undefined FUN_01b42ba0()
                 03 00
        01b0c887 83 7d 08 00     CMP        dword ptr [EBP + Stack[0x4]],0x0
        01b0c88b 76 5d           JBE        LAB_01b0c8ea
        01b0c88d 6a 00           PUSH       0x0
        01b0c88f 8d 4d a8        LEA        ECX=>local_5c,[EBP + -0x58]
        01b0c892 e8 59 5a        CALL       FUN_01b422f0                                     undefined FUN_01b422f0()
                 03 00
        01b0c897 8d 55 0c        LEA        EDX=>Stack[0x8],[EBP + 0xc]
        01b0c89a 8b f8           MOV        EDI,EAX
        01b0c89c 52              PUSH       EDX
        01b0c89d 8d 45 c0        LEA        EAX=>local_44,[EBP + -0x40]
        01b0c8a0 50              PUSH       EAX
        01b0c8a1 8d 4d cc        LEA        ECX=>local_38,[EBP + -0x34]
        01b0c8a4 e8 77 3d        CALL       FUN_01b60620                                     undefined FUN_01b60620()
                 05 00
        01b0c8a9 84 c0           TEST       AL,AL
        01b0c8ab 74 16           JZ         LAB_01b0c8c3
        01b0c8ad 8b 4d 08        MOV        ECX,dword ptr [EBP + Stack[0x4]]
        01b0c8b0 8b 55 0c        MOV        EDX,dword ptr [EBP + Stack[0x8]]
        01b0c8b3 8b 45 c0        MOV        EAX,dword ptr [EBP + local_44]
        01b0c8b6 51              PUSH       ECX
        01b0c8b7 52              PUSH       EDX
        01b0c8b8 50              PUSH       EAX
        01b0c8b9 57              PUSH       EDI
        01b0c8ba 8b cb           MOV        ECX,EBX
        01b0c8bc e8 df ab        CALL       FUN_01b074a0                                     undefined FUN_01b074a0()
                 ff ff
        01b0c8c1 eb 27           JMP        LAB_01b0c8ea
                             LAB_01b0c8c3                                    XREF[1]:     01b0c8ab(j)  
        01b0c8c3 33 ff           XOR        EDI,EDI
        01b0c8c5 39 7d 08        CMP        dword ptr [EBP + Stack[0x4]],EDI
        01b0c8c8 76 20           JBE        LAB_01b0c8ea
        01b0c8ca 8d 9b 00        LEA        EBX,[EBX]
                 00 00 00
                             LAB_01b0c8d0                                    XREF[1]:     01b0c8e8(j)  
        01b0c8d0 57              PUSH       EDI
        01b0c8d1 8d 4d a8        LEA        ECX=>local_5c,[EBP + -0x58]
        01b0c8d4 e8 17 5a        CALL       FUN_01b422f0                                     undefined FUN_01b422f0()
                 03 00
        01b0c8d9 6a 01           PUSH       0x1
        01b0c8db 56              PUSH       ESI
        01b0c8dc 50              PUSH       EAX
        01b0c8dd 8b cb           MOV        ECX,EBX
        01b0c8df e8 fc f9        CALL       FUN_01b0c2e0                                     undefined FUN_01b0c2e0()
                 ff ff
        01b0c8e4 47              INC        EDI
        01b0c8e5 3b 7d 08        CMP        EDI,dword ptr [EBP + Stack[0x4]]
        01b0c8e8 72 e6           JC         LAB_01b0c8d0
                             LAB_01b0c8ea                                    XREF[3]:     01b0c88b(j), 01b0c8c1(j), 
                                                                                          01b0c8c8(j)  
        01b0c8ea 8b 4b 04        MOV        ECX,dword ptr [EBX + 0x4]
        01b0c8ed 8b 11           MOV        EDX,dword ptr [ECX]
        01b0c8ef 8b 42 10        MOV        EAX,dword ptr [EDX + 0x10]
        01b0c8f2 68 4c 4c        PUSH       s_Values_02554c4c                                = "Values"
                 55 02
        01b0c8f7 ff d0           CALL       EAX
        01b0c8f9 f6 43 4e 04     TEST       byte ptr [EBX + 0x4e],0x4
        01b0c8fd 0f 84 83        JZ         switchD_01b0c338::default
                 00 00 00
        01b0c903 8b 75 d8        MOV        ESI,dword ptr [EBP + local_2c]
        01b0c906 8b ce           MOV        ECX,ESI
        01b0c908 e8 43 f0        CALL       FUN_008bb950                                     undefined FUN_008bb950()
                 da fe
        01b0c90d 84 c0           TEST       AL,AL
        01b0c90f 74 75           JZ         switchD_01b0c338::default
        01b0c911 8b 0e           MOV        ECX,dword ptr [ESI]
        01b0c913 8b 46 04        MOV        EAX,dword ptr [ESI + 0x4]
        01b0c916 89 4d c4        MOV        dword ptr [EBP + local_40],ECX
        01b0c919 8b d0           MOV        EDX,EAX
        01b0c91b 81 e2 00        AND        EDX,IMAGE_DOS_HEADER_00400000
                 00 40 00
        01b0c921 33 c9           XOR        ECX,ECX
        01b0c923 0b ca           OR         ECX,EDX
        01b0c925 75 5f           JNZ        switchD_01b0c338::default
        01b0c927 c1 e8 17        SHR        EAX,0x17
        01b0c92a 83 e0 3f        AND        EAX,0x3f
        01b0c92d 83 f8 15        CMP        EAX,0x15
        01b0c930 75 04           JNZ        LAB_01b0c936
        01b0c932 85 c9           TEST       ECX,ECX
        01b0c934 74 09           JZ         LAB_01b0c93f
                             LAB_01b0c936                                    XREF[1]:     01b0c930(j)  
        01b0c936 83 f8 14        CMP        EAX,0x14
        01b0c939 75 4b           JNZ        switchD_01b0c338::default
        01b0c93b 85 c9           TEST       ECX,ECX
        01b0c93d 75 47           JNZ        switchD_01b0c338::default
                             LAB_01b0c93f                                    XREF[1]:     01b0c934(j)  
        01b0c93f 6a 01           PUSH       0x1
        01b0c941 8d 4d cc        LEA        ECX=>local_38,[EBP + -0x34]
        01b0c944 e8 47 3b        CALL       FUN_01b60490                                     undefined FUN_01b60490()
                 05 00
        01b0c949 50              PUSH       EAX
        01b0c94a 8d 55 e4        LEA        EDX=>local_20,[EBP + -0x1c]
        01b0c94d 52              PUSH       EDX
        01b0c94e 8b cb           MOV        ECX,EBX
        01b0c950 e8 5b b6        CALL       FUN_01b07fb0                                     undefined FUN_01b07fb0()
                 ff ff
        01b0c955 eb 2f           JMP        switchD_01b0c338::default
                             LAB_01b0c957                                    XREF[1]:     01b0c6dd(j)  
        01b0c957 c6 45 13 00     MOV        byte ptr [EBP + Stack[0xf]],0x0
        01b0c95b eb 29           JMP        switchD_01b0c338::default
                             switchD_01b0c338::caseD_19                      XREF[2]:     01b0c338(j), 01b0ca18(*)  
        01b0c95d 8b 45 08        MOV        EAX,dword ptr [EBP + Stack[0x4]]
        01b0c960 56              PUSH       ESI
        01b0c961 50              PUSH       EAX
        01b0c962 57              PUSH       EDI
        01b0c963 8b cb           MOV        ECX,EBX
        01b0c965 e8 a6 d2        CALL       FUN_01b09c10                                     undefined FUN_01b09c10()
                 ff ff
        01b0c96a eb 1a           JMP        switchD_01b0c338::default
                             switchD_01b0c338::caseD_1a                      XREF[2]:     01b0c338(j), 01b0ca1c(*)  
        01b0c96c 8b 4d 08        MOV        ECX,dword ptr [EBP + Stack[0x4]]
        01b0c96f 51              PUSH       ECX
        01b0c970 56              PUSH       ESI
        01b0c971 8b cb           MOV        ECX,EBX
        01b0c973 e8 78 63        CALL       FUN_01b12cf0                                     undefined FUN_01b12cf0()
                 00 00
        01b0c978 eb 0c           JMP        switchD_01b0c338::default
                             switchD_01b0c338::caseD_1b                      XREF[2]:     01b0c338(j), 01b0ca20(*)  
        01b0c97a 8b 55 08        MOV        EDX,dword ptr [EBP + Stack[0x4]]
        01b0c97d 52              PUSH       EDX
        01b0c97e 56              PUSH       ESI
        01b0c97f 8b cb           MOV        ECX,EBX
        01b0c981 e8 fa 67        CALL       FUN_01b13180                                     undefined FUN_01b13180()
                 00 00
                             switchD_01b0c338::default                       XREF[20]:    01b0c332(j), 01b0c34b(j), 
                                                                                          01b0c35c(j), 01b0c36d(j), 
                                                                                          01b0c37e(j), 01b0c38f(j), 
                                                                                          01b0c3a0(j), 01b0c3b1(j), 
                                                                                          01b0c3c2(j), 01b0c3d3(j), 
                                                                                          01b0c3e4(j), 01b0c3f5(j), 
                                                                                          01b0c406(j), 01b0c417(j), 
                                                                                          01b0c428(j), 01b0c439(j), 
                                                                                          01b0c44a(j), 01b0c45b(j), 
                                                                                          01b0c46c(j), 01b0c47e(j), [more]
        01b0c986 83 7b 58 00     CMP        dword ptr [EBX + 0x58],0x0
        01b0c98a 75 15           JNZ        LAB_01b0c9a1
        01b0c98c 80 7d 13 00     CMP        byte ptr [EBP + Stack[0xf]],0x0
        01b0c990 74 0f           JZ         LAB_01b0c9a1
        01b0c992 8b 4b 04        MOV        ECX,dword ptr [EBX + 0x4]
        01b0c995 8b 01           MOV        EAX,dword ptr [ECX]
        01b0c997 8b 50 14        MOV        EDX,dword ptr [EAX + 0x14]
        01b0c99a 68 40 4c        PUSH       s_Property_02554c40                              = "Property"
                 55 02
        01b0c99f ff d2           CALL       EDX
                             LAB_01b0c9a1                                    XREF[2]:     01b0c98a(j), 01b0c990(j)  
        01b0c9a1 8b 4d f4        MOV        ECX,dword ptr [EBP + local_10]
        01b0c9a4 5f              POP        EDI
        01b0c9a5 5e              POP        ESI
        01b0c9a6 5b              POP        EBX
        01b0c9a7 64 89 0d        MOV        dword ptr FS:[0x0]=>ExceptionList,ECX            = 00000000
                 00 00 00 00
        01b0c9ae 8b e5           MOV        ESP,EBP
        01b0c9b0 5d              POP        EBP
        01b0c9b1 c2 0c 00        RET        0xc
                             switchD_01b0c338::switchdataD_01b0c9b4          XREF[1]:     FUN_01b0c2e0:01b0c338(*)  
        01b0c9b4 3f c3 b0 01     addr       switchD_01b0c338::caseD_0
        01b0c9b8 50 c3 b0 01     addr       switchD_01b0c338::caseD_1
        01b0c9bc 61 c3 b0 01     addr       switchD_01b0c338::caseD_2
        01b0c9c0 72 c3 b0 01     addr       switchD_01b0c338::caseD_3
        01b0c9c4 83 c3 b0 01     addr       switchD_01b0c338::caseD_4
        01b0c9c8 94 c3 b0 01     addr       switchD_01b0c338::caseD_5
        01b0c9cc a5 c3 b0 01     addr       switchD_01b0c338::caseD_6
        01b0c9d0 b6 c3 b0 01     addr       switchD_01b0c338::caseD_7
        01b0c9d4 c7 c3 b0 01     addr       switchD_01b0c338::caseD_8
        01b0c9d8 d8 c3 b0 01     addr       switchD_01b0c338::caseD_9
        01b0c9dc e9 c3 b0 01     addr       switchD_01b0c338::caseD_a
        01b0c9e0 fa c3 b0 01     addr       switchD_01b0c338::caseD_b
        01b0c9e4 0b c4 b0 01     addr       switchD_01b0c338::caseD_c
        01b0c9e8 1c c4 b0 01     addr       switchD_01b0c338::caseD_d
        01b0c9ec 2d c4 b0 01     addr       switchD_01b0c338::caseD_e
        01b0c9f0 3e c4 b0 01     addr       switchD_01b0c338::caseD_f
        01b0c9f4 4f c4 b0 01     addr       switchD_01b0c338::caseD_10
        01b0c9f8 60 c4 b0 01     addr       switchD_01b0c338::caseD_11
        01b0c9fc 71 c4 b0 01     addr       switchD_01b0c338::caseD_12
        01b0ca00 95 c4 b0 01     addr       switchD_01b0c338::caseD_13
        01b0ca04 a6 c4 b0 01     addr       switchD_01b0c338::caseD_14
        01b0ca08 e1 c4 b0 01     addr       switchD_01b0c338::caseD_15
        01b0ca0c b7 c4 b0 01     addr       switchD_01b0c338::caseD_16
        01b0ca10 0b c5 b0 01     addr       switchD_01b0c338::caseD_17
        01b0ca14 8c c6 b0 01     addr       switchD_01b0c338::caseD_18
        01b0ca18 5d c9 b0 01     addr       switchD_01b0c338::caseD_19
        01b0ca1c 6c c9 b0 01     addr       switchD_01b0c338::caseD_1a
        01b0ca20 7a c9 b0 01     addr       switchD_01b0c338::caseD_1b
        01b0ca24 83 c4 b0 01     addr       switchD_01b0c338::caseD_1c
        01b0ca28 8c c6 b0 01     addr       switchD_01b0c338::caseD_18
        01b0ca2c 71 c4 b0 01     addr       switchD_01b0c338::caseD_12
