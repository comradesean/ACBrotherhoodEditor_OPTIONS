# Section 4 Serialization - Project Requirements

## Core Philosophy

**100% TRACED CODE ONLY** - No guesswork, no assumptions, no hacks.

Every line of parsing/serialization code MUST be directly traceable to decompiled
Ghidra output. If we can't trace it, we don't implement it - we go back to Ghidra
and reverse engineer more functions.

## Prohibited Practices

1. **No Magic Values** - Don't use hex values found by scanning unless traced to code
2. **No Hardcoded Sizes** - Entry sizes must come from traced structure definitions
3. **No Hex Blobs** - Don't store "unknown bytes" as opaque blobs
4. **No Marker Scanning** - Don't search for patterns; follow the code's read sequence
5. **No Assumptions** - If unsure what a field means, trace more code
6. **No Shortcuts** - Roundtrip success doesn't validate understanding
7. **No Invented Names** - Hash meanings must come from traced string references

## Required Practices

1. **Trace Before Implement** - Read the decompiled code before writing parser code
2. **Document Source** - Every parser field must cite its source function
3. **Follow Call Chain** - Parse in the same order the game code reads
4. **Verify Understanding** - Trace both read AND write paths when possible
5. **Gap Documentation** - When hitting unknowns, document exactly what's missing

## Workflow

```
1. Identify next untraced section in binary
2. Find the function that reads/writes it (via call chain)
3. Decompile and document the function
4. Update SECTION4_SERIALIZATION.md with findings
5. Update parser to match traced code
6. Repeat until complete
```

## Current Gaps Requiring Tracing

### High Priority
- [ ] FUN_01b09650 NULL handler - confirm inner_type + null_value structure
- [ ] FUN_01b12fa0 UInt32 handler - confirm trailing 0x00 byte source

### Completed
- [x] **MAP CLASS entries - FULLY PARSED** (85 bytes/entry with type_hash 0xF95FCFA8)

### Medium Priority
- [ ] What sets ctx+0x58 to enable binary mode (1/2/3)?
- [ ] FUN_01afd600 entry point initialization
- [ ] FUN_01b48e90 VarString reader behavior in binary mode

### Low Priority (Resolved via Binary Analysis)
- [x] **NULL extra byte - inner_type (wrapped type) + null_value**
- [x] **Fixed type extra byte - trailing 0x00 (terminator/padding)**
- [x] **MAP 2-byte prefix - marker (0x0B) + flag (0x01)**
- [x] **MAP element_type - from type_info bits 23-28, determines entry size**
- [x] **MAP fixed entries - UINT32/INT8 entries parse correctly**
- [x] 0xF95FCFA8 marker - TYPE_HASH for nested CLASS objects in MAP
- [x] 85-byte entries - CLASS objects with type_hash 0xF95FCFA8
- [x] File footer (4 bytes at 0x76B-0x76F) - likely section terminator

### Known Traced (Verified)
- [x] Object header 14 bytes (FUN_01b08ce0) - SKIPPED in binary mode
- [x] Little-endian byte order (FUN_01b6f440)
- [x] Type sizes (BinarySerializer vtable complete)
- [x] PropertyType enum (FUN_01b0c2e0) - all 31 cases
- [x] field_0x04 at 0x0E (FUN_01b12fa0)
- [x] content_size at 0x12 (BeginSection/FUN_01b48890 - exactly 4 bytes)
- [x] **FUN_01b091a0 READ path uses IsAtEnd loop (no count read!)**
- [x] **FUN_01b077d0 property header (MODE 3: 12 bytes, flags SKIPPED!)**
- [x] FUN_01b076f0 property flags (SKIPPED in mode 3)
- [x] FUN_01b0e980 TypeDescriptor reader (8 bytes)
- [x] All primitive type handlers (exact byte counts verified)

## Parser Test Status (January 2026 - ROUNDTRIP VERIFIED)

| Metric | Value |
|--------|-------|
| Properties Parsed | 15/15 |
| Bytes Parsed | 1903/1903 (100%) |
| **ROUNDTRIP** | **SUCCESS - 100% byte-identical** |
| NULL Properties | **FIXED** - inner_type + null_value parsed |
| Fixed Types | **FIXED** - trailing byte handled |
| MAP/MAP_ALT Header | **FIXED** - marker + flag + count parsed |
| MAP Entries | **FIXED** - element_type from type_info bits 23-28 |
| - UINT32 entries | Parsed as hex values (e.g., 0x57554DCF) |
| - INT8 entries | Parsed as byte array |
| - CLASS entries | **FULLY PARSED** - 85-byte nested objects with 3 properties each |

### Roundtrip Test
```bash
python section4_parser.py game_uncompressed_4.bin --roundtrip
# Output: ROUNDTRIP SUCCESS: Files are identical!
```

### Nested CLASS Entry Structure (Discovered)
```
Bytes 0-9:   Key (10 zeros for index-based MAP)
Bytes 10-13: Type hash (0xF95FCFA8)
Bytes 14-17: Content size (67 = prop_size_field + props + padding)
Bytes 18-21: Property data size (59)
Bytes 22-80: Nested properties (section_size + prop_id + type_desc + value)
Bytes 81-84: Trailing padding (4 zeros)
```

## File Structure

- `SECTION4_SERIALIZATION.md` - Traced code documentation
- `section4_parser.py` - Parser (must match traced code only)
- `game_uncompressed_4.bin` - Test binary (1903 bytes)
- `CLAUDE.md` - This file (project requirements)

## Quality Gates

Before merging any parser changes:
1. Every new field must cite source function
2. No `# HACK` or `# TODO: trace` comments allowed in final code
3. Roundtrip test passes
4. SECTION4_SERIALIZATION.md updated with new findings
