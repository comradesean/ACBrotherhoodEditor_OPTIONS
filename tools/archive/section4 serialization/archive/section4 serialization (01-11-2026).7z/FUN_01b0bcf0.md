                             **************************************************************
                             *                          FUNCTION                          *
                             **************************************************************
                             undefined FUN_01b0bcf0()
                               assume FS_OFFSET = 0xffdff000
             undefined         <UNASSIGNED>   <RETURN>
             undefined4        Stack[-0x10]:4 local_10                                XREF[3]:     01b0bd67(R), 
                                                                                                   01b0be6f(R), 
                                                                                                   01b0c2b7(R)  
             undefined         Stack[-0x11]:1 local_11                                XREF[2]:     01b0bd7c(*), 
                                                                                                   01b0bd85(W)  
             undefined1        Stack[-0x18]:1 local_18                                XREF[2]:     01b0be94(W), 
                                                                                                   01b0bf0b(W)  
             undefined4        Stack[-0x1c]:4 local_1c                                XREF[3]:     01b0be91(W), 
                                                                                                   01b0bf05(W), 
                                                                                                   01b0bf1e(*)  
             undefined4        Stack[-0x28]:4 local_28                                XREF[1]:     01b0bf36(W)  
             undefined4        Stack[-0x2c]:4 local_2c                                XREF[5]:     01b0bdb6(W), 
                                                                                                   01b0be9b(W), 
                                                                                                   01b0bf2a(*), 
                                                                                                   01b0bf33(W), 
                                                                                                   01b0bf3e(*)  
             undefined         Stack[-0x58]:1 local_58                                XREF[2]:     01b0bf22(*), 
                                                                                                   01b0bf42(*)  
             undefined         Stack[-0x16c   local_16c                               XREF[1]:     01b0bdfc(*)  
                             FUN_01b0bcf0                                    XREF[20]:    FUN_005fd120:005fd1a9(c), 
                                                                                          FUN_005fd370:005fd40e(c), 
                                                                                          FUN_005fd730:005fd7e6(c), 
                                                                                          FUN_005fda60:005fdb1e(c), 
                                                                                          FUN_005fda60:005fdc02(c), 
                                                                                          FUN_0073d820:0073d8a9(c), 
                                                                                          FUN_0097d5a0:0097d610(c), 
                                                                                          FUN_00a1aa90:00a1ab29(c), 
                                                                                          FUN_00a1aa90:00a1ac07(c), 
                                                                                          FUN_00a1aa90:00a1ad27(c), 
                                                                                          FUN_00a1aa90:00a1ae9b(c), 
                                                                                          FUN_00a1b5d0:00a1b656(c), 
                                                                                          FUN_00a1b5d0:00a1b737(c), 
                                                                                          FUN_00a1bc00:00a1bc73(c), 
                                                                                          FUN_00a1bc00:00a1bd5f(c), 
                                                                                          FUN_00a1bc00:00a1be28(c), 
                                                                                          FUN_00a1bc00:00a1bef3(c), 
                                                                                          FUN_00a1de40:00a1deb3(c), 
                                                                                          FUN_00a1de40:00a1df97(c), 
                                                                                          FUN_00a1de40:00a1e08c(c), [more]
        01b0bcf0 55              PUSH       EBP
        01b0bcf1 8b ec           MOV        EBP,ESP
        01b0bcf3 64 a1 00        MOV        EAX,FS:[0x0]=>ExceptionList                      = 00000000
                 00 00 00
        01b0bcf9 6a ff           PUSH       -0x1
        01b0bcfb 68 1c 1d        PUSH       LAB_023c1d1c
                 3c 02
        01b0bd00 50              PUSH       EAX
        01b0bd01 64 89 25        MOV        dword ptr FS:[0x0]=>ExceptionList,ESP            = 00000000
                 00 00 00 00
        01b0bd08 81 ec 50        SUB        ESP,0x150
                 01 00 00
        01b0bd0e 53              PUSH       EBX
        01b0bd0f 56              PUSH       ESI
        01b0bd10 8b 75 10        MOV        ESI,dword ptr [EBP + Stack[0xc]]
        01b0bd13 57              PUSH       EDI
        01b0bd14 33 ff           XOR        EDI,EDI
        01b0bd16 57              PUSH       EDI
        01b0bd17 57              PUSH       EDI
        01b0bd18 56              PUSH       ESI
        01b0bd19 8b d9           MOV        EBX,ECX
        01b0bd1b e8 20 bc        CALL       FUN_01b07940                                     undefined FUN_01b07940()
                 ff ff
        01b0bd20 84 c0           TEST       AL,AL
        01b0bd22 75 05           JNZ        LAB_01b0bd29
        01b0bd24 38 43 7a        CMP        byte ptr [EBX + 0x7a],AL
        01b0bd27 74 39           JZ         LAB_01b0bd62
                             LAB_01b0bd29                                    XREF[1]:     01b0bd22(j)  
        01b0bd29 56              PUSH       ESI
        01b0bd2a 8b cb           MOV        ECX,EBX
        01b0bd2c e8 0f 14        CALL       FUN_01b0d140                                     undefined FUN_01b0d140()
                 00 00
        01b0bd31 84 c0           TEST       AL,AL
        01b0bd33 74 2d           JZ         LAB_01b0bd62
        01b0bd35 83 7b 24 04     CMP        dword ptr [EBX + 0x24],0x4
        01b0bd39 0f 8c 36        JL         LAB_01b0c275
                 05 00 00
        01b0bd3f 8b 4b 04        MOV        ECX,dword ptr [EBX + 0x4]
        01b0bd42 80 79 04 00     CMP        byte ptr [ECX + 0x4],0x0
        01b0bd46 0f 85 33        JNZ        LAB_01b0be7f
                 01 00 00
        01b0bd4c 80 7b 79 00     CMP        byte ptr [EBX + 0x79],0x0
        01b0bd50 75 25           JNZ        LAB_01b0bd77
        01b0bd52 39 7b 58        CMP        dword ptr [EBX + 0x58],EDI
        01b0bd55 75 37           JNZ        LAB_01b0bd8e
                             LAB_01b0bd57                                    XREF[1]:     01b0bfaa(j)  
        01b0bd57 80 63 4e fe     AND        byte ptr [EBX + 0x4e],0xfe
                             LAB_01b0bd5b                                    XREF[1]:     01b0be5a(j)  
        01b0bd5b 8b cb           MOV        ECX,EBX
        01b0bd5d e8 ee b5        CALL       FUN_01b07350                                     undefined FUN_01b07350()
                 ff ff
                             LAB_01b0bd62                                    XREF[3]:     01b0bd27(j), 01b0bd33(j), 
                                                                                          01b0c270(j)  
        01b0bd62 5f              POP        EDI
        01b0bd63 5e              POP        ESI
        01b0bd64 32 c0           XOR        AL,AL
        01b0bd66 5b              POP        EBX
        01b0bd67 8b 4d f4        MOV        ECX,dword ptr [EBP + local_10]
        01b0bd6a 64 89 0d        MOV        dword ptr FS:[0x0]=>ExceptionList,ECX            = 00000000
                 00 00 00 00
        01b0bd71 8b e5           MOV        ESP,EBP
        01b0bd73 5d              POP        EBP
        01b0bd74 c2 0c 00        RET        0xc
                             LAB_01b0bd77                                    XREF[1]:     01b0bd50(j)  
        01b0bd77 39 7b 58        CMP        dword ptr [EBX + 0x58],EDI
        01b0bd7a 75 12           JNZ        LAB_01b0bd8e
        01b0bd7c 8d 45 f3        LEA        EAX=>local_11,[EBP + -0xd]
        01b0bd7f 50              PUSH       EAX
        01b0bd80 68 00 4f        PUSH       s_ContentCode_02554f00                           = "ContentCode"
                 55 02
        01b0bd85 c6 45 f3 01     MOV        byte ptr [EBP + local_11],0x1
        01b0bd89 e8 72 17        CALL       FUN_01b0d500                                     undefined FUN_01b0d500()
                 00 00
                             LAB_01b0bd8e                                    XREF[2]:     01b0bd55(j), 01b0bd7a(j)  
        01b0bd8e 83 7b 58 03     CMP        dword ptr [EBX + 0x58],0x3
        01b0bd92 0f 85 a4        JNZ        LAB_01b0be3c
                 00 00 00
        01b0bd98 8b 7d 08        MOV        EDI,dword ptr [EBP + Stack[0x4]]
        01b0bd9b 85 ff           TEST       EDI,EDI
        01b0bd9d 0f 84 99        JZ         LAB_01b0be3c
                 00 00 00
        01b0bda3 83 c6 08        ADD        ESI,0x8
        01b0bda6 8b ce           MOV        ECX,ESI
        01b0bda8 e8 63 4d        CALL       FUN_01b00b10                                     undefined FUN_01b00b10()
                 ff ff
        01b0bdad 84 c0           TEST       AL,AL
        01b0bdaf 74 2e           JZ         LAB_01b0bddf
        01b0bdb1 8b 0e           MOV        ECX,dword ptr [ESI]
        01b0bdb3 8b 46 04        MOV        EAX,dword ptr [ESI + 0x4]
        01b0bdb6 89 4d d8        MOV        dword ptr [EBP + local_2c],ECX
        01b0bdb9 8b d0           MOV        EDX,EAX
        01b0bdbb 81 e2 00        AND        EDX,IMAGE_DOS_HEADER_00400000
                 00 40 00
        01b0bdc1 33 c9           XOR        ECX,ECX
        01b0bdc3 0b ca           OR         ECX,EDX
        01b0bdc5 75 18           JNZ        LAB_01b0bddf
        01b0bdc7 c1 e8 17        SHR        EAX,0x17
        01b0bdca 83 e0 3f        AND        EAX,0x3f
        01b0bdcd 83 f8 15        CMP        EAX,0x15
        01b0bdd0 75 04           JNZ        LAB_01b0bdd6
        01b0bdd2 85 c9           TEST       ECX,ECX
        01b0bdd4 74 14           JZ         LAB_01b0bdea
                             LAB_01b0bdd6                                    XREF[1]:     01b0bdd0(j)  
        01b0bdd6 83 f8 14        CMP        EAX,0x14
        01b0bdd9 75 04           JNZ        LAB_01b0bddf
        01b0bddb 85 c9           TEST       ECX,ECX
        01b0bddd 74 0b           JZ         LAB_01b0bdea
                             LAB_01b0bddf                                    XREF[3]:     01b0bdaf(j), 01b0bdc5(j), 
                                                                                          01b0bdd9(j)  
        01b0bddf 8b ce           MOV        ECX,ESI
        01b0bde1 e8 9a 28        CALL       FUN_0073e680                                     undefined FUN_0073e680()
                 c3 fe
        01b0bde6 84 c0           TEST       AL,AL
        01b0bde8 74 52           JZ         LAB_01b0be3c
                             LAB_01b0bdea                                    XREF[2]:     01b0bdd4(j), 01b0bddd(j)  
        01b0bdea 8b cf           MOV        ECX,EDI
        01b0bdec 33 f6           XOR        ESI,ESI
        01b0bdee e8 0d 32        CALL       FUN_01b0f000                                     undefined FUN_01b0f000()
                 00 00
        01b0bdf3 85 c0           TEST       EAX,EAX
        01b0bdf5 76 45           JBE        LAB_01b0be3c
        01b0bdf7 bf 00 10        MOV        EDI,0x1000
                 00 00
        01b0bdfc 8d 64 24 00     LEA        ESP=>local_16c,[ESP]
                             LAB_01b0be00                                    XREF[1]:     01b0be3a(j)  
        01b0be00 8b 53 1c        MOV        EDX,dword ptr [EBX + 0x1c]
        01b0be03 8b 4d 10        MOV        ECX,dword ptr [EBP + Stack[0xc]]
        01b0be06 6a 00           PUSH       0x0
        01b0be08 56              PUSH       ESI
        01b0be09 52              PUSH       EDX
        01b0be0a e8 d1 ae        CALL       FUN_01b56ce0                                     undefined FUN_01b56ce0()
                 04 00
        01b0be0f 85 c0           TEST       EAX,EAX
        01b0be11 74 1c           JZ         LAB_01b0be2f
        01b0be13 8b c8           MOV        ECX,EAX
        01b0be15 e8 26 62        CALL       FUN_01b02040                                     undefined FUN_01b02040()
                 ff ff
        01b0be1a 50              PUSH       EAX
        01b0be1b b9 b0 24        MOV        ECX,DAT_02a624b0
                 a6 02
        01b0be20 e8 bb 37        CALL       FUN_01aff5e0                                     undefined FUN_01aff5e0()
                 ff ff
        01b0be25 85 78 18        TEST       dword ptr [EAX + 0x18],EDI
        01b0be28 74 05           JZ         LAB_01b0be2f
        01b0be2a 8b 45 0c        MOV        EAX,dword ptr [EBP + Stack[0x8]]
        01b0be2d ff 08           DEC        dword ptr [EAX]
                             LAB_01b0be2f                                    XREF[2]:     01b0be11(j), 01b0be28(j)  
        01b0be2f 8b 4d 08        MOV        ECX,dword ptr [EBP + Stack[0x4]]
        01b0be32 46              INC        ESI
        01b0be33 e8 c8 31        CALL       FUN_01b0f000                                     undefined FUN_01b0f000()
                 00 00
        01b0be38 3b f0           CMP        ESI,EAX
        01b0be3a 72 c4           JC         LAB_01b0be00
                             LAB_01b0be3c                                    XREF[4]:     01b0bd92(j), 01b0bd9d(j), 
                                                                                          01b0bde8(j), 01b0bdf5(j)  
        01b0be3c f6 43 4e 80     TEST       byte ptr [EBX + 0x4e],0x80
        01b0be40 74 1d           JZ         LAB_01b0be5f
        01b0be42 8b 4b 04        MOV        ECX,dword ptr [EBX + 0x4]
        01b0be45 8d 45 0c        LEA        EAX=>Stack[0x8],[EBP + 0xc]
        01b0be48 50              PUSH       EAX
        01b0be49 68 e8 4c        PUSH       DAT_02554ce8                                     = 53h    S
                 55 02
        01b0be4e c7 45 0c        MOV        dword ptr [EBP + Stack[0x8]],0x0
                 00 00 00 00
        01b0be55 e8 36 16        CALL       FUN_01b0d490                                     undefined FUN_01b0d490()
                 00 00
        01b0be5a e9 fc fe        JMP        LAB_01b0bd5b
                 ff ff
                             LAB_01b0be5f                                    XREF[2]:     01b0be40(j), 01b0bfaa(j)  
        01b0be5f 8b 4d 0c        MOV        ECX,dword ptr [EBP + Stack[0x8]]
        01b0be62 51              PUSH       ECX
        01b0be63 8b cb           MOV        ECX,EBX
        01b0be65 e8 26 bd        CALL       FUN_01b07b90                                     undefined FUN_01b07b90()
                 ff ff
        01b0be6a 5f              POP        EDI
        01b0be6b 5e              POP        ESI
        01b0be6c b0 01           MOV        AL,0x1
        01b0be6e 5b              POP        EBX
        01b0be6f 8b 4d f4        MOV        ECX,dword ptr [EBP + local_10]
        01b0be72 64 89 0d        MOV        dword ptr FS:[0x0]=>ExceptionList,ECX            = 00000000
                 00 00 00 00
        01b0be79 8b e5           MOV        ESP,EBP
        01b0be7b 5d              POP        EBP
        01b0be7c c2 0c 00        RET        0xc
                             LAB_01b0be7f                                    XREF[1]:     01b0bd46(j)  
        01b0be7f 8a 53 4e        MOV        DL,byte ptr [EBX + 0x4e]
        01b0be82 8b 73 2c        MOV        ESI,dword ptr [EBX + 0x2c]
        01b0be85 8b 4b 30        MOV        ECX,dword ptr [EBX + 0x30]
        01b0be88 80 e2 fb        AND        DL,0xfb
        01b0be8b 80 ca 01        OR         DL,0x1
        01b0be8e 88 53 4e        MOV        byte ptr [EBX + 0x4e],DL
        01b0be91 89 7d e8        MOV        dword ptr [EBP + local_1c],EDI
        01b0be94 c6 45 ec 00     MOV        byte ptr [EBP + local_18],0x0
        01b0be98 8b 46 08        MOV        EAX,dword ptr [ESI + 0x8]
        01b0be9b 89 45 d8        MOV        dword ptr [EBP + local_2c],EAX
        01b0be9e 8b 46 0c        MOV        EAX,dword ptr [ESI + 0xc]
        01b0bea1 3b cf           CMP        ECX,EDI
        01b0bea3 74 3d           JZ         LAB_01b0bee2
        01b0bea5 c1 e8 10        SHR        EAX,0x10
        01b0bea8 83 e0 3f        AND        EAX,0x3f
        01b0beab 33 d2           XOR        EDX,EDX
        01b0bead 83 f8 18        CMP        EAX,0x18
        01b0beb0 75 04           JNZ        LAB_01b0beb6
        01b0beb2 3b d7           CMP        EDX,EDI
        01b0beb4 74 1a           JZ         LAB_01b0bed0
                             LAB_01b0beb6                                    XREF[1]:     01b0beb0(j)  
        01b0beb6 83 f8 17        CMP        EAX,0x17
        01b0beb9 75 04           JNZ        LAB_01b0bebf
        01b0bebb 3b d7           CMP        EDX,EDI
        01b0bebd 74 11           JZ         LAB_01b0bed0
                             LAB_01b0bebf                                    XREF[1]:     01b0beb9(j)  
        01b0bebf 51              PUSH       ECX
        01b0bec0 8b ce           MOV        ECX,ESI
        01b0bec2 88 55 13        MOV        byte ptr [EBP + Stack[0xf]],DL
        01b0bec5 e8 56 a9        CALL       FUN_01b56820                                     undefined FUN_01b56820()
                 04 00
        01b0beca 80 7d 13 00     CMP        byte ptr [EBP + Stack[0xf]],0x0
        01b0bece eb 32           JMP        LAB_01b0bf02
                             LAB_01b0bed0                                    XREF[2]:     01b0beb4(j), 01b0bebd(j)  
        01b0bed0 51              PUSH       ECX
        01b0bed1 8b ce           MOV        ECX,ESI
        01b0bed3 c6 45 13 01     MOV        byte ptr [EBP + Stack[0xf]],0x1
        01b0bed7 e8 44 a9        CALL       FUN_01b56820                                     undefined FUN_01b56820()
                 04 00
        01b0bedc 80 7d 13 00     CMP        byte ptr [EBP + Stack[0xf]],0x0
        01b0bee0 eb 20           JMP        LAB_01b0bf02
                             LAB_01b0bee2                                    XREF[1]:     01b0bea3(j)  
        01b0bee2 8a 56 0e        MOV        DL,byte ptr [ESI + 0xe]
        01b0bee5 33 c0           XOR        EAX,EAX
        01b0bee7 80 e2 3f        AND        DL,0x3f
        01b0beea 80 fa 18        CMP        DL,0x18
        01b0beed 0f 94 c0        SETZ       AL
        01b0bef0 8b ce           MOV        ECX,ESI
        01b0bef2 89 45 10        MOV        dword ptr [EBP + Stack[0xc]],EAX
        01b0bef5 8b 43 1c        MOV        EAX,dword ptr [EBX + 0x1c]
        01b0bef8 50              PUSH       EAX
        01b0bef9 e8 22 a9        CALL       FUN_01b56820                                     undefined FUN_01b56820()
                 04 00
        01b0befe 80 7d 10 00     CMP        byte ptr [EBP + Stack[0xc]],0x0
                             LAB_01b0bf02                                    XREF[2]:     01b0bece(j), 01b0bee0(j)  
        01b0bf02 0f 94 c1        SETZ       CL
        01b0bf05 89 45 e8        MOV        dword ptr [EBP + local_1c],EAX
        01b0bf08 8b 43 2c        MOV        EAX,dword ptr [EBX + 0x2c]
        01b0bf0b 88 4d ec        MOV        byte ptr [EBP + local_18],CL
        01b0bf0e 8b 10           MOV        EDX,dword ptr [EAX]
        01b0bf10 c1 ea 09        SHR        EDX,0x9
        01b0bf13 80 e2 01        AND        DL,0x1
        01b0bf16 0f b6 ca        MOVZX      ECX,DL
        01b0bf19 51              PUSH       ECX
        01b0bf1a 83 c0 08        ADD        EAX,0x8
        01b0bf1d 50              PUSH       EAX
        01b0bf1e 8d 55 e8        LEA        EDX=>local_1c,[EBP + -0x18]
        01b0bf21 52              PUSH       EDX
        01b0bf22 8d 4d ac        LEA        ECX=>local_58,[EBP + -0x54]
        01b0bf25 e8 36 62        CALL       FUN_01b42160                                     undefined FUN_01b42160()
                 03 00
        01b0bf2a 8d 45 d8        LEA        EAX=>local_2c,[EBP + -0x28]
        01b0bf2d 50              PUSH       EAX
        01b0bf2e b9 68 22        MOV        ECX,DAT_02a62268
                 a6 02
        01b0bf33 89 7d d8        MOV        dword ptr [EBP + local_2c],EDI
        01b0bf36 89 7d dc        MOV        dword ptr [EBP + local_28],EDI
        01b0bf39 e8 12 12        CALL       FUN_01aed150                                     undefined FUN_01aed150()
                 fe ff
        01b0bf3e 8d 4d d8        LEA        ECX=>local_2c,[EBP + -0x28]
        01b0bf41 51              PUSH       ECX
        01b0bf42 8d 4d ac        LEA        ECX=>local_58,[EBP + -0x54]
        01b0bf45 e8 b6 5f        CALL       FUN_01b41f00                                     undefined FUN_01b41f00()
                 03 00
        01b0bf4a 8d 9b 00        LEA        EBX,[EBX]
                 00 00 00
                             LAB_01b0bf50                                    XREF[1]:     01b0c26a(j)  
        01b0bf50 33 ff           XOR        EDI,EDI
        01b0bf52 39 7b 58        CMP        dword ptr [EBX + 0x58],EDI
        01b0bf55 74 05           JZ         LAB_01b0bf5c
        01b0bf57 8d 47 01        LEA        EAX,[EDI + 0x1]
        01b0bf5a eb 4e           JMP        LAB_01b0bfaa
                             LAB_01b0bf5c                                    XREF[1]:     01b0bf55(j)  
        01b0bf5c 8b 4b 04        MOV        ECX,dword ptr [EBX + 0x4]
        01b0bf5f 8b 11           MOV        EDX,dword ptr [ECX]
        01b0bf61 8b 42 1c        MOV        EAX,dword ptr [EDX + 0x1c]
        01b0bf64 ff d0           CALL       EAX
        01b0bf66 84 c0           TEST       AL,AL
        01b0bf68 74 04           JZ         LAB_01b0bf6e
        01b0bf6a 33 c0           XOR        EAX,EAX
        01b0bf6c eb 3c           JMP        LAB_01b0bfaa
                             LAB_01b0bf6e                                    XREF[1]:     01b0bf68(j)  
        01b0bf6e 8b 73 04        MOV        ESI,dword ptr [EBX + 0x4]
        01b0bf71 8b 16           MOV        EDX,dword ptr [ESI]
        01b0bf73 8b 42 08        MOV        EAX,dword ptr [EDX + 0x8]
        01b0bf76 68 00 4f        PUSH       s_ContentCode_02554f00                           = "ContentCode"
                 55 02
        01b0bf7b 8b ce           MOV        ECX,ESI
        01b0bf7d ff d0           CALL       EAX
        01b0bf7f 8b 16           MOV        EDX,dword ptr [ESI]
        01b0bf81 8b 92 98        MOV        EDX,dword ptr [EDX + 0x98]
                 00 00 00
        01b0bf87 8d 45 0b        LEA        EAX=>Stack[0x7],[EBP + 0xb]
        01b0bf8a 50              PUSH       EAX
        01b0bf8b 8b ce           MOV        ECX,ESI
        01b0bf8d ff d2           CALL       EDX
        01b0bf8f 8b 06           MOV        EAX,dword ptr [ESI]
        01b0bf91 8b 50 10        MOV        EDX,dword ptr [EAX + 0x10]
        01b0bf94 68 00 4f        PUSH       s_ContentCode_02554f00                           = "ContentCode"
                 55 02
        01b0bf99 8b ce           MOV        ECX,ESI
        01b0bf9b ff d2           CALL       EDX
        01b0bf9d 0f b6 45 0b     MOVZX      EAX,byte ptr [EBP + Stack[0x7]]
        01b0bfa1 83 f8 04        CMP        EAX,0x4
        01b0bfa4 0f 87 be        JA         LAB_01b0c268
                 02 00 00
                             LAB_01b0bfaa                                    XREF[2]:     01b0bf5a(j), 01b0bf6c(j)  
        01b0bfaa ff 24 85        JMP        dword ptr [EAX*0x4 + 0x1b0c2cc]=>DAT_01b0c2d0    = 01B0BD57h
                 cc c2 b0 01                                                                 = 01B0BE5Fh
        01b0bfb1 57              ??         57h    W
        01b0bfb2 8d              ??         8Dh
        01b0bfb3 8d              ??         8Dh
        01b0bfb4 2c              ??         2Ch    ,
        01b0bfb5 ff              ??         FFh
        01b0bfb6 ff              ??         FFh
        01b0bfb7 ff              ??         FFh
        01b0bfb8 e8              ??         E8h
        01b0bfb9 13              ??         13h
        01b0bfba b6              ??         B6h
        01b0bfbb 56              ??         56h    V
        01b0bfbc ff              ??         FFh
        01b0bfbd 8b              ??         8Bh
        01b0bfbe 4b              ??         4Bh    K
        01b0bfbf 04              ??         04h
        01b0bfc0 8d              ??         8Dh
        01b0bfc1 45              ??         45h    E
        01b0bfc2 cc              ??         CCh
        01b0bfc3 50              ??         50h    P
        01b0bfc4 68              ??         68h    h
        01b0bfc5 ec              ??         ECh                                              ?  ->  02554eec
        01b0bfc6 4e              ??         4Eh    N
        01b0bfc7 55              ??         55h    U
        01b0bfc8 02              ??         02h
        01b0bfc9 89              ??         89h
        01b0bfca 7d              ??         7Dh    }
        01b0bfcb fc              ??         FCh
        01b0bfcc e8              ??         E8h
        01b0bfcd bf              ??         BFh
        01b0bfce 14              ??         14h
        01b0bfcf 00              ??         00h
        01b0bfd0 00              ??         00h
        01b0bfd1 89              ??         89h
        01b0bfd2 7d              ??         7Dh    }
        01b0bfd3 d4              ??         D4h
        01b0bfd4 39              ??         39h    9
        01b0bfd5 7d              ??         7Dh    }
        01b0bfd6 cc              ??         CCh
        01b0bfd7 0f              ??         0Fh                                              ?  ->  0184860f
        01b0bfd8 86              ??         86h
        01b0bfd9 84              ??         84h
        01b0bfda 01              ??         01h
        01b0bfdb 00              ??         00h
        01b0bfdc 00              ??         00h                                              ?  ->  00498d00
        01b0bfdd 8d              ??         8Dh
        01b0bfde 49              ??         49h    I
        01b0bfdf 00              ??         00h
        01b0bfe0 8b              ??         8Bh
        01b0bfe1 73              ??         73h    s
        01b0bfe2 04              ??         04h
        01b0bfe3 8b              ??         8Bh
        01b0bfe4 16              ??         16h
        01b0bfe5 8b              ??         8Bh
        01b0bfe6 42              ??         42h    B
        01b0bfe7 08              ??         08h
        01b0bfe8 68              ??         68h    h
        01b0bfe9 d4              ??         D4h                                              ?  ->  02554ed4
        01b0bfea 4e              ??         4Eh    N
        01b0bfeb 55              ??         55h    U
        01b0bfec 02              ??         02h
        01b0bfed 8b              ??         8Bh
        01b0bfee ce              ??         CEh
        01b0bfef ff              ??         FFh
        01b0bff0 d0              ??         D0h
        01b0bff1 8b              ??         8Bh
        01b0bff2 16              ??         16h
        01b0bff3 8b              ??         8Bh                                              ?  ->  009c928b
        01b0bff4 92              ??         92h
        01b0bff5 9c              ??         9Ch
        01b0bff6 00              ??         00h
        01b0bff7 00              ??         00h
        01b0bff8 00              ??         00h
        01b0bff9 8d              ??         8Dh
        01b0bffa 45              ??         45h    E
        01b0bffb 10              ??         10h
        01b0bffc 50              ??         50h    P
        01b0bffd 8b              ??         8Bh
        01b0bffe ce              ??         CEh
        01b0bfff ff              ??         FFh
        01b0c000 d2              ??         D2h
        01b0c001 8b              ??         8Bh
        01b0c002 06              ??         06h
        01b0c003 8b              ??         8Bh
        01b0c004 50              ??         50h    P
        01b0c005 10              ??         10h
        01b0c006 68              ??         68h    h
        01b0c007 d4              ??         D4h                                              ?  ->  02554ed4
        01b0c008 4e              ??         4Eh    N
        01b0c009 55              ??         55h    U
        01b0c00a 02              ??         02h
        01b0c00b 8b              ??         8Bh
        01b0c00c ce              ??         CEh
        01b0c00d ff              ??         FFh
        01b0c00e d2              ??         D2h
        01b0c00f 83              ??         83h
        01b0c010 ce              ??         CEh
        01b0c011 ff              ??         FFh
        01b0c012 8b              ??         8Bh
        01b0c013 45              ??         45h    E
        01b0c014 10              ??         10h
        01b0c015 50              ??         50h    P
        01b0c016 46              ??         46h    F
        01b0c017 56              ??         56h    V
        01b0c018 8d              ??         8Dh
        01b0c019 4d              ??         4Dh    M
        01b0c01a ac              ??         ACh
        01b0c01b e8              ??         E8h
        01b0c01c d0              ??         D0h
        01b0c01d 63              ??         63h    c
        01b0c01e 03              ??         03h
        01b0c01f 00              ??         00h
        01b0c020 8d              ??         8Dh
        01b0c021 8d              ??         8Dh
        01b0c022 70              ??         70h    p
        01b0c023 ff              ??         FFh
        01b0c024 ff              ??         FFh
        01b0c025 ff              ??         FFh
        01b0c026 8b              ??         8Bh
        01b0c027 f0              ??         F0h
        01b0c028 51              ??         51h    Q
        01b0c029 8d              ??         8Dh
        01b0c02a 8d              ??         8Dh
        01b0c02b 2c              ??         2Ch    ,
        01b0c02c ff              ??         FFh
        01b0c02d ff              ??         FFh
        01b0c02e ff              ??         FFh
        01b0c02f 89              ??         89h
        01b0c030 75              ??         75h    u
        01b0c031 c4              ??         C4h
        01b0c032 e8              ??         E8h
        01b0c033 d9              ??         D9h
        01b0c034 96              ??         96h
        01b0c035 56              ??         56h    V
        01b0c036 ff              ??         FFh
        01b0c037 8d              ??         8Dh
        01b0c038 55              ??         55h    U
        01b0c039 c4              ??         C4h
        01b0c03a 52              ??         52h    R
        01b0c03b 8d              ??         8Dh
        01b0c03c 85              ??         85h
        01b0c03d a4              ??         A4h
        01b0c03e fe              ??         FEh
        01b0c03f ff              ??         FFh
        01b0c040 ff              ??         FFh
        01b0c041 50              ??         50h    P
        01b0c042 8d              ??         8Dh
        01b0c043 8d              ??         8Dh
        01b0c044 2c              ??         2Ch    ,
        01b0c045 ff              ??         FFh
        01b0c046 ff              ??         FFh
        01b0c047 ff              ??         FFh
        01b0c048 e8              ??         E8h
        01b0c049 13              ??         13h
        01b0c04a 9e              ??         9Eh
        01b0c04b 56              ??         56h    V
        01b0c04c ff              ??         FFh
        01b0c04d 8d              ??         8Dh
        01b0c04e 8d              ??         8Dh
        01b0c04f 74              ??         74h    t
        01b0c050 ff              ??         FFh
        01b0c051 ff              ??         FFh
        01b0c052 ff              ??         FFh
        01b0c053 51              ??         51h    Q
        01b0c054 8d              ??         8Dh
        01b0c055 8d              ??         8Dh
        01b0c056 a8              ??         A8h
        01b0c057 fe              ??         FEh
        01b0c058 ff              ??         FFh                                              ?  ->  01e8ffff
        01b0c059 ff              ??         FFh
        01b0c05a e8              ??         E8h
        01b0c05b 01              ??         01h
        01b0c05c 6e              ??         6Eh    n
        01b0c05d 56              ??         56h    V
        01b0c05e ff              ??         FFh
        01b0c05f 84              ??         84h
        01b0c060 c0              ??         C0h
        01b0c061 75              ??         75h    u
        01b0c062 05              ??         05h
        01b0c063 83              ??         83h
        01b0c064 fe              ??         FEh
        01b0c065 ff              ??         FFh
        01b0c066 75              ??         75h    u
        01b0c067 aa              ??         AAh
        01b0c068 8b              ??         8Bh
        01b0c069 15              ??         15h
        01b0c06a a8              ??         A8h                                              ?  ->  02a622a8
        01b0c06b 22              ??         22h    "
        01b0c06c a6              ??         A6h
        01b0c06d 02              ??         02h
        01b0c06e 52              ??         52h    R
        01b0c06f 56              ??         56h    V
        01b0c070 8d              ??         8Dh
        01b0c071 8d              ??         8Dh
        01b0c072 2c              ??         2Ch    ,
        01b0c073 ff              ??         FFh
        01b0c074 ff              ??         FFh
        01b0c075 ff              ??         FFh
        01b0c076 e8              ??         E8h
        01b0c077 c5              ??         C5h
        01b0c078 b5              ??         B5h
        01b0c079 56              ??         56h    V
        01b0c07a ff              ??         FFh
        01b0c07b 83              ??         83h
        01b0c07c fe              ??         FEh
        01b0c07d ff              ??         FFh
        01b0c07e 74              ??         74h    t
        01b0c07f 22              ??         22h    "
        01b0c080 8b              ??         8Bh
        01b0c081 4b              ??         4Bh    K
        01b0c082 2c              ??         2Ch    ,
        01b0c083 8b              ??         8Bh
        01b0c084 45              ??         45h    E                                         ?  ->  016a1045
        01b0c085 10              ??         10h
        01b0c086 6a              ??         6Ah    j
        01b0c087 01              ??         01h
        01b0c088 51              ??         51h    Q
        01b0c089 56              ??         56h    V
        01b0c08a 8d              ??         8Dh
        01b0c08b 4d              ??         4Dh    M
        01b0c08c ac              ??         ACh
        01b0c08d 89              ??         89h
        01b0c08e 43              ??         43h    C
        01b0c08f 74              ??         74h    t
        01b0c090 e8              ??         E8h
        01b0c091 5b              ??         5Bh    [
        01b0c092 62              ??         62h    b
        01b0c093 03              ??         03h
        01b0c094 00              ??         00h
        01b0c095 50              ??         50h    P
        01b0c096 8b              ??         8Bh
        01b0c097 cb              ??         CBh                                              ?  ->  0243e8cb
        01b0c098 e8              ??         E8h
        01b0c099 43              ??         43h    C
        01b0c09a 02              ??         02h
        01b0c09b 00              ??         00h
        01b0c09c 00              ??         00h                                              ?  ->  00afe900
        01b0c09d e9              ??         E9h
        01b0c09e af              ??         AFh
        01b0c09f 00              ??         00h
        01b0c0a0 00              ??         00h
        01b0c0a1 00              ??         00h
        01b0c0a2 8d              ??         8Dh
        01b0c0a3 73              ??         73h    s
        01b0c0a4 08              ??         08h
        01b0c0a5 b9              ??         B9h
        01b0c0a6 13              ??         13h
        01b0c0a7 00              ??         00h
        01b0c0a8 00              ??         00h
        01b0c0a9 00              ??         00h
        01b0c0aa 8d              ??         8Dh
        01b0c0ab bd              ??         BDh
        01b0c0ac e0              ??         E0h
        01b0c0ad fe              ??         FEh
        01b0c0ae ff              ??         FFh
        01b0c0af ff              ??         FFh
        01b0c0b0 f3              ??         F3h
        01b0c0b1 a5              ??         A5h
        01b0c0b2 80              ??         80h
        01b0c0b3 4b              ??         4Bh    K
        01b0c0b4 4e              ??         4Eh    N
        01b0c0b5 08              ??         08h
        01b0c0b6 8d              ??         8Dh
        01b0c0b7 8d              ??         8Dh
        01b0c0b8 7c              ??         7Ch    |
        01b0c0b9 ff              ??         FFh
        01b0c0ba ff              ??         FFh
        01b0c0bb ff              ??         FFh
        01b0c0bc e8              ??         E8h
        01b0c0bd ef              ??         EFh
        01b0c0be 49              ??         49h    I
        01b0c0bf 07              ??         07h
        01b0c0c0 00              ??         00h
        01b0c0c1 80              ??         80h                                              ?  ->  024e4b80
        01b0c0c2 4b              ??         4Bh    K
        01b0c0c3 4e              ??         4Eh    N
        01b0c0c4 02              ??         02h
        01b0c0c5 83              ??         83h
        01b0c0c6 7b              ??         7Bh    {
        01b0c0c7 30              ??         30h    0
        01b0c0c8 00              ??         00h
        01b0c0c9 c6              ??         C6h                                              ?  ->  01fc45c6
        01b0c0ca 45              ??         45h    E
        01b0c0cb fc              ??         FCh
        01b0c0cc 01              ??         01h
        01b0c0cd 8d              ??         8Dh
        01b0c0ce b5              ??         B5h
        01b0c0cf 7c              ??         7Ch    |
        01b0c0d0 ff              ??         FFh
        01b0c0d1 ff              ??         FFh
        01b0c0d2 ff              ??         FFh
        01b0c0d3 74              ??         74h    t
        01b0c0d4 27              ??         27h    '
        01b0c0d5 f6              ??         F6h
        01b0c0d6 85              ??         85h
        01b0c0d7 26              ??         26h    &
        01b0c0d8 ff              ??         FFh
        01b0c0d9 ff              ??         FFh
        01b0c0da ff              ??         FFh
        01b0c0db 08              ??         08h
        01b0c0dc 74              ??         74h    t
        01b0c0dd 1e              ??         1Eh
        01b0c0de f6              ??         F6h                                              ?  ->  01ac45f6
        01b0c0df 45              ??         45h    E
        01b0c0e0 ac              ??         ACh
        01b0c0e1 01              ??         01h
        01b0c0e2 74              ??         74h    t                                         ?  ->  006a1874
        01b0c0e3 18              ??         18h
        01b0c0e4 6a              ??         6Ah    j
        01b0c0e5 00              ??         00h
        01b0c0e6 8d              ??         8Dh
        01b0c0e7 4d              ??         4Dh    M
        01b0c0e8 ac              ??         ACh
        01b0c0e9 e8              ??         E8h
        01b0c0ea 32              ??         32h    2
        01b0c0eb 6d              ??         6Dh    m
        01b0c0ec 03              ??         03h                                              ?  ->  006a0003
        01b0c0ed 00              ??         00h
        01b0c0ee 6a              ??         6Ah    j
        01b0c0ef 00              ??         00h
        01b0c0f0 8d              ??         8Dh
        01b0c0f1 4d              ??         4Dh    M
        01b0c0f2 ac              ??         ACh
        01b0c0f3 e8              ??         E8h
        01b0c0f4 f8              ??         F8h
        01b0c0f5 61              ??         61h    a
        01b0c0f6 03              ??         03h
        01b0c0f7 00              ??         00h
        01b0c0f8 8b              ??         8Bh
        01b0c0f9 f0              ??         F0h
        01b0c0fa eb              ??         EBh
        01b0c0fb 28              ??         28h    (
        01b0c0fc 8b              ??         8Bh
        01b0c0fd 43              ??         43h    C
        01b0c0fe 2c              ??         2Ch    ,
        01b0c0ff 8d              ??         8Dh
        01b0c100 95              ??         95h
        01b0c101 7c              ??         7Ch    |
        01b0c102 ff              ??         FFh
        01b0c103 ff              ??         FFh
        01b0c104 ff              ??         FFh
        01b0c105 89              ??         89h
        01b0c106 53              ??         53h    S
        01b0c107 30              ??         30h    0
        01b0c108 8b              ??         8Bh
        01b0c109 08              ??         08h
        01b0c10a 8b              ??         8Bh
        01b0c10b 50              ??         50h    P
        01b0c10c 04              ??         04h
        01b0c10d 51              ??         51h    Q
        01b0c10e 8b              ??         8Bh
        01b0c10f 48              ??         48h    H
        01b0c110 0c              ??         0Ch
        01b0c111 8b              ??         8Bh
        01b0c112 40              ??         40h    @
        01b0c113 08              ??         08h
        01b0c114 51              ??         51h    Q
        01b0c115 50              ??         50h    P                                         ?  ->  006a5250
        01b0c116 52              ??         52h    R
        01b0c117 6a              ??         6Ah    j
        01b0c118 00              ??         00h
        01b0c119 8d              ??         8Dh
        01b0c11a 4d              ??         4Dh    M
        01b0c11b 94              ??         94h
        01b0c11c e8              ??         E8h
        01b0c11d 1f              ??         1Fh
        01b0c11e c1              ??         C1h
        01b0c11f 04              ??         04h
        01b0c120 00              ??         00h
        01b0c121 89              ??         89h
        01b0c122 43              ??         43h    C
        01b0c123 2c              ??         2Ch    ,
        01b0c124 8b              ??         8Bh
        01b0c125 4b              ??         4Bh    K                                         ?  ->  016a2c4b
        01b0c126 2c              ??         2Ch    ,
        01b0c127 6a              ??         6Ah    j
        01b0c128 01              ??         01h
        01b0c129 51              ??         51h    Q
        01b0c12a 56              ??         56h    V
        01b0c12b 8b              ??         8Bh
        01b0c12c cb              ??         CBh                                              ?  ->  01aee8cb
        01b0c12d e8              ??         E8h
        01b0c12e ae              ??         AEh
        01b0c12f 01              ??         01h
        01b0c130 00              ??         00h
        01b0c131 00              ??         00h
        01b0c132 b9              ??         B9h
        01b0c133 13              ??         13h
        01b0c134 00              ??         00h
        01b0c135 00              ??         00h
        01b0c136 00              ??         00h
        01b0c137 8d              ??         8Dh
        01b0c138 b5              ??         B5h
        01b0c139 e0              ??         E0h
        01b0c13a fe              ??         FEh
        01b0c13b ff              ??         FFh
        01b0c13c ff              ??         FFh
        01b0c13d 8d              ??         8Dh
        01b0c13e 7b              ??         7Bh    {
        01b0c13f 08              ??         08h
        01b0c140 f3              ??         F3h
        01b0c141 a5              ??         A5h
        01b0c142 8d              ??         8Dh
        01b0c143 8d              ??         8Dh
        01b0c144 7c              ??         7Ch    |
        01b0c145 ff              ??         FFh
        01b0c146 ff              ??         FFh
        01b0c147 ff              ??         FFh
        01b0c148 c6              ??         C6h                                              ?  ->  00fc45c6
        01b0c149 45              ??         45h    E
        01b0c14a fc              ??         FCh
        01b0c14b 00              ??         00h
        01b0c14c e8              ??         E8h
        01b0c14d af              ??         AFh
        01b0c14e 4b              ??         4Bh    K
        01b0c14f 07              ??         07h
        01b0c150 00              ??         00h
        01b0c151 8b              ??         8Bh
        01b0c152 45              ??         45h    E
        01b0c153 d4              ??         D4h
        01b0c154 40              ??         40h    @
        01b0c155 89              ??         89h
        01b0c156 45              ??         45h    E
        01b0c157 d4              ??         D4h
        01b0c158 3b              ??         3Bh    ;
        01b0c159 45              ??         45h    E
        01b0c15a cc              ??         CCh
        01b0c15b 0f              ??         0Fh
        01b0c15c 82              ??         82h
        01b0c15d 7f              ??         7Fh    
        01b0c15e fe              ??         FEh
        01b0c15f ff              ??         FFh
        01b0c160 ff              ??         FFh
        01b0c161 8d              ??         8Dh
        01b0c162 8d              ??         8Dh
        01b0c163 4c              ??         4Ch    L
        01b0c164 ff              ??         FFh
        01b0c165 ff              ??         FFh
        01b0c166 ff              ??         FFh
        01b0c167 c7              ??         C7h
        01b0c168 45              ??         45h    E
        01b0c169 fc              ??         FCh
        01b0c16a ff              ??         FFh
        01b0c16b ff              ??         FFh
        01b0c16c ff              ??         FFh
        01b0c16d ff              ??         FFh
        01b0c16e e8              ??         E8h
        01b0c16f 8d              ??         8Dh
        01b0c170 a0              ??         A0h
        01b0c171 56              ??         56h    V
        01b0c172 ff              ??         FFh
        01b0c173 e9              ??         E9h
        01b0c174 d8              ??         D8h
        01b0c175 fd              ??         FDh
        01b0c176 ff              ??         FFh
        01b0c177 ff              ??         FFh
        01b0c178 8b              ??         8Bh
        01b0c179 4b              ??         4Bh    K
        01b0c17a 04              ??         04h
        01b0c17b 8d              ??         8Dh
        01b0c17c 55              ??         55h    U
        01b0c17d d0              ??         D0h
        01b0c17e 52              ??         52h    R
        01b0c17f 68              ??         68h    h
        01b0c180 c0              ??         C0h                                              ?  ->  02554ec0
        01b0c181 4e              ??         4Eh    N
        01b0c182 55              ??         55h    U
        01b0c183 02              ??         02h
        01b0c184 e8              ??         E8h
        01b0c185 07              ??         07h
        01b0c186 13              ??         13h
        01b0c187 00              ??         00h
        01b0c188 00              ??         00h
        01b0c189 83              ??         83h                                              ?  ->  00d07d83
        01b0c18a 7d              ??         7Dh    }
        01b0c18b d0              ??         D0h
        01b0c18c 00              ??         00h
        01b0c18d 0f              ??         0Fh
        01b0c18e 86              ??         86h
        01b0c18f bd              ??         BDh
        01b0c190 fd              ??         FDh
        01b0c191 ff              ??         FFh
        01b0c192 ff              ??         FFh
        01b0c193 8b              ??         8Bh
        01b0c194 73              ??         73h    s
        01b0c195 04              ??         04h
        01b0c196 8b              ??         8Bh
        01b0c197 06              ??         06h
        01b0c198 8b              ??         8Bh
        01b0c199 50              ??         50h    P
        01b0c19a 08              ??         08h
        01b0c19b 68              ??         68h    h
        01b0c19c b0              ??         B0h                                              ?  ->  02554eb0
        01b0c19d 4e              ??         4Eh    N
        01b0c19e 55              ??         55h    U
        01b0c19f 02              ??         02h
        01b0c1a0 8b              ??         8Bh
        01b0c1a1 ce              ??         CEh
        01b0c1a2 ff              ??         FFh
        01b0c1a3 d2              ??         D2h
        01b0c1a4 8b              ??         8Bh
        01b0c1a5 06              ??         06h
        01b0c1a6 8b              ??         8Bh                                              ?  ->  0084908b
        01b0c1a7 90              ??         90h
        01b0c1a8 84              ??         84h
        01b0c1a9 00              ??         00h
        01b0c1aa 00              ??         00h
        01b0c1ab 00              ??         00h
        01b0c1ac 8d              ??         8Dh
        01b0c1ad 4d              ??         4Dh    M
        01b0c1ae e4              ??         E4h
        01b0c1af 51              ??         51h    Q
        01b0c1b0 8b              ??         8Bh
        01b0c1b1 ce              ??         CEh
        01b0c1b2 ff              ??         FFh
        01b0c1b3 d2              ??         D2h
        01b0c1b4 8b              ??         8Bh
        01b0c1b5 06              ??         06h
        01b0c1b6 8b              ??         8Bh
        01b0c1b7 50              ??         50h    P
        01b0c1b8 10              ??         10h
        01b0c1b9 68              ??         68h    h
        01b0c1ba b0              ??         B0h                                              ?  ->  02554eb0
        01b0c1bb 4e              ??         4Eh    N
        01b0c1bc 55              ??         55h    U
        01b0c1bd 02              ??         02h
        01b0c1be 8b              ??         8Bh
        01b0c1bf ce              ??         CEh
        01b0c1c0 ff              ??         FFh
        01b0c1c1 d2              ??         D2h
        01b0c1c2 8b              ??         8Bh
        01b0c1c3 45              ??         45h    E
        01b0c1c4 e4              ??         E4h
        01b0c1c5 50              ??         50h    P
        01b0c1c6 8d              ??         8Dh
        01b0c1c7 4d              ??         4Dh    M
        01b0c1c8 ac              ??         ACh
        01b0c1c9 e8              ??         E8h
        01b0c1ca 52              ??         52h    R
        01b0c1cb 6c              ??         6Ch    l
        01b0c1cc 03              ??         03h
        01b0c1cd 00              ??         00h
        01b0c1ce 8b              ??         8Bh
        01b0c1cf 4b              ??         4Bh    K                                         ?  ->  016a2c4b
        01b0c1d0 2c              ??         2Ch    ,
        01b0c1d1 6a              ??         6Ah    j
        01b0c1d2 01              ??         01h
        01b0c1d3 51              ??         51h    Q
        01b0c1d4 50              ??         50h    P
        01b0c1d5 8d              ??         8Dh
        01b0c1d6 4d              ??         4Dh    M
        01b0c1d7 ac              ??         ACh
        01b0c1d8 89              ??         89h
        01b0c1d9 45              ??         45h    E
        01b0c1da e4              ??         E4h
        01b0c1db e8              ??         E8h
        01b0c1dc 10              ??         10h
        01b0c1dd 61              ??         61h    a
        01b0c1de 03              ??         03h
        01b0c1df 00              ??         00h
        01b0c1e0 50              ??         50h    P
        01b0c1e1 8b              ??         8Bh
        01b0c1e2 cb              ??         CBh                                              ?  ->  00f8e8cb
        01b0c1e3 e8              ??         E8h
        01b0c1e4 f8              ??         F8h
        01b0c1e5 00              ??         00h
        01b0c1e6 00              ??         00h
        01b0c1e7 00              ??         00h
        01b0c1e8 47              ??         47h    G
        01b0c1e9 3b              ??         3Bh    ;
        01b0c1ea 7d              ??         7Dh    }
        01b0c1eb d0              ??         D0h
        01b0c1ec 72              ??         72h    r
        01b0c1ed a5              ??         A5h
        01b0c1ee e9              ??         E9h
        01b0c1ef 5d              ??         5Dh    ]
        01b0c1f0 fd              ??         FDh
        01b0c1f1 ff              ??         FFh
        01b0c1f2 ff              ??         FFh
        01b0c1f3 8b              ??         8Bh
        01b0c1f4 4b              ??         4Bh    K
        01b0c1f5 04              ??         04h
        01b0c1f6 8d              ??         8Dh
        01b0c1f7 55              ??         55h    U
        01b0c1f8 e0              ??         E0h
        01b0c1f9 52              ??         52h    R
        01b0c1fa 68              ??         68h    h
        01b0c1fb 9c              ??         9Ch                                              ?  ->  02554e9c
        01b0c1fc 4e              ??         4Eh    N
        01b0c1fd 55              ??         55h    U
        01b0c1fe 02              ??         02h
        01b0c1ff e8              ??         E8h
        01b0c200 8c              ??         8Ch
        01b0c201 12              ??         12h
        01b0c202 00              ??         00h
        01b0c203 00              ??         00h
        01b0c204 83              ??         83h                                              ?  ->  00e07d83
        01b0c205 7d              ??         7Dh    }
        01b0c206 e0              ??         E0h
        01b0c207 00              ??         00h
        01b0c208 0f              ??         0Fh
        01b0c209 86              ??         86h
        01b0c20a 42              ??         42h    B
        01b0c20b fd              ??         FDh
        01b0c20c ff              ??         FFh
        01b0c20d ff              ??         FFh
        01b0c20e 8b              ??         8Bh
        01b0c20f ff              ??         FFh
        01b0c210 8b              ??         8Bh
        01b0c211 73              ??         73h    s
        01b0c212 04              ??         04h
        01b0c213 8b              ??         8Bh
        01b0c214 06              ??         06h
        01b0c215 8b              ??         8Bh
        01b0c216 50              ??         50h    P
        01b0c217 08              ??         08h
        01b0c218 68              ??         68h    h
        01b0c219 8c              ??         8Ch                                              ?  ->  02554e8c
        01b0c21a 4e              ??         4Eh    N
        01b0c21b 55              ??         55h    U
        01b0c21c 02              ??         02h
        01b0c21d 8b              ??         8Bh
        01b0c21e ce              ??         CEh
        01b0c21f ff              ??         FFh
        01b0c220 d2              ??         D2h
        01b0c221 8b              ??         8Bh
        01b0c222 06              ??         06h
        01b0c223 8b              ??         8Bh                                              ?  ->  009c908b
        01b0c224 90              ??         90h
        01b0c225 9c              ??         9Ch
        01b0c226 00              ??         00h
        01b0c227 00              ??         00h
        01b0c228 00              ??         00h
        01b0c229 8d              ??         8Dh
        01b0c22a 4d              ??         4Dh    M
        01b0c22b c8              ??         C8h
        01b0c22c 51              ??         51h    Q
        01b0c22d 8b              ??         8Bh
        01b0c22e ce              ??         CEh
        01b0c22f ff              ??         FFh
        01b0c230 d2              ??         D2h
        01b0c231 8b              ??         8Bh
        01b0c232 06              ??         06h
        01b0c233 8b              ??         8Bh
        01b0c234 50              ??         50h    P
        01b0c235 10              ??         10h
        01b0c236 68              ??         68h    h
        01b0c237 8c              ??         8Ch                                              ?  ->  02554e8c
        01b0c238 4e              ??         4Eh    N
        01b0c239 55              ??         55h    U
        01b0c23a 02              ??         02h
        01b0c23b 8b              ??         8Bh
        01b0c23c ce              ??         CEh
        01b0c23d ff              ??         FFh
        01b0c23e d2              ??         D2h
        01b0c23f 8b              ??         8Bh
        01b0c240 45              ??         45h    E
        01b0c241 c8              ??         C8h                                              ?  ->  006a50c8
        01b0c242 50              ??         50h    P
        01b0c243 6a              ??         6Ah    j
        01b0c244 00              ??         00h
        01b0c245 8d              ??         8Dh
        01b0c246 4d              ??         4Dh    M
        01b0c247 ac              ??         ACh
        01b0c248 e8              ??         E8h
        01b0c249 a3              ??         A3h
        01b0c24a 61              ??         61h    a
        01b0c24b 03              ??         03h
        01b0c24c 00              ??         00h
        01b0c24d 83              ??         83h
        01b0c24e f8              ??         F8h
        01b0c24f ff              ??         FFh
        01b0c250 74              ??         74h    t                                         ?  ->  016a0b74
        01b0c251 0b              ??         0Bh
        01b0c252 6a              ??         6Ah    j
        01b0c253 01              ??         01h
        01b0c254 50              ??         50h    P
        01b0c255 8d              ??         8Dh
        01b0c256 4d              ??         4Dh    M
        01b0c257 ac              ??         ACh
        01b0c258 e8              ??         E8h
        01b0c259 63              ??         63h    c
        01b0c25a 6d              ??         6Dh    m
        01b0c25b 03              ??         03h
        01b0c25c 00              ??         00h
        01b0c25d 47              ??         47h    G
        01b0c25e 3b              ??         3Bh    ;
        01b0c25f 7d              ??         7Dh    }
        01b0c260 e0              ??         E0h
        01b0c261 72              ??         72h    r
        01b0c262 ad              ??         ADh
        01b0c263 e9              ??         E9h
        01b0c264 e8              ??         E8h
        01b0c265 fc              ??         FCh
        01b0c266 ff              ??         FFh
        01b0c267 ff              ??         FFh
                             LAB_01b0c268                                    XREF[1]:     01b0bfa4(j)  
        01b0c268 3b c7           CMP        EAX,EDI
        01b0c26a 0f 85 e0        JNZ        LAB_01b0bf50
                 fc ff ff
        01b0c270 e9 ed fa        JMP        LAB_01b0bd62
                 ff ff
                             LAB_01b0c275                                    XREF[1]:     01b0bd39(j)  
        01b0c275 8b 73 04        MOV        ESI,dword ptr [EBX + 0x4]
        01b0c278 8b 16           MOV        EDX,dword ptr [ESI]
        01b0c27a 8b 42 08        MOV        EAX,dword ptr [EDX + 0x8]
        01b0c27d 68 e8 4c        PUSH       DAT_02554ce8                                     = 53h    S
                 55 02
        01b0c282 8b ce           MOV        ECX,ESI
        01b0c284 ff d0           CALL       EAX
        01b0c286 8b 16           MOV        EDX,dword ptr [ESI]
        01b0c288 8b 45 0c        MOV        EAX,dword ptr [EBP + Stack[0x8]]
        01b0c28b 8b 92 84        MOV        EDX,dword ptr [EDX + 0x84]
                 00 00 00
        01b0c291 50              PUSH       EAX
        01b0c292 8b ce           MOV        ECX,ESI
        01b0c294 ff d2           CALL       EDX
        01b0c296 8b 06           MOV        EAX,dword ptr [ESI]
        01b0c298 8b 50 10        MOV        EDX,dword ptr [EAX + 0x10]
        01b0c29b 68 e8 4c        PUSH       DAT_02554ce8                                     = 53h    S
                 55 02
        01b0c2a0 8b ce           MOV        ECX,ESI
        01b0c2a2 ff d2           CALL       EDX
        01b0c2a4 8b 4b 04        MOV        ECX,dword ptr [EBX + 0x4]
        01b0c2a7 8b 01           MOV        EAX,dword ptr [ECX]
        01b0c2a9 8b 50 08        MOV        EDX,dword ptr [EAX + 0x8]
        01b0c2ac 68 4c 4c        PUSH       s_Values_02554c4c                                = "Values"
                 55 02
        01b0c2b1 ff d2           CALL       EDX
        01b0c2b3 80 4b 4e 01     OR         byte ptr [EBX + 0x4e],0x1
        01b0c2b7 8b 4d f4        MOV        ECX,dword ptr [EBP + local_10]
        01b0c2ba 5f              POP        EDI
        01b0c2bb 5e              POP        ESI
        01b0c2bc b0 01           MOV        AL,0x1
        01b0c2be 5b              POP        EBX
        01b0c2bf 64 89 0d        MOV        dword ptr FS:[0x0]=>ExceptionList,ECX            = 00000000
                 00 00 00 00
        01b0c2c6 8b e5           MOV        ESP,EBP
        01b0c2c8 5d              POP        EBP
        01b0c2c9 c2 0c 00        RET        0xc
                             DAT_01b0c2cc                                    XREF[1]:     FUN_01b0bcf0:01b0bfaa(R)  
        01b0c2cc 57 bd b0 01     undefined4 01B0BD57h                                        ?  ->  01b0bd57
                             DAT_01b0c2d0                                    XREF[1]:     FUN_01b0bcf0:01b0bfaa(R)  
        01b0c2d0 5f be b0 01     undefined4 01B0BE5Fh                                        ?  ->  01b0be5f
        01b0c2d4 b1              ??         B1h                                              ?  ->  01b0bfb1
        01b0c2d5 bf              ??         BFh
        01b0c2d6 b0              ??         B0h
        01b0c2d7 01              ??         01h
        01b0c2d8 78              ??         78h    x                                         ?  ->  01b0c178
        01b0c2d9 c1              ??         C1h
        01b0c2da b0              ??         B0h
        01b0c2db 01              ??         01h
        01b0c2dc f3              ??         F3h                                              ?  ->  01b0c1f3
        01b0c2dd c1              ??         C1h
        01b0c2de b0              ??         B0h
        01b0c2df 01              ??         01h
