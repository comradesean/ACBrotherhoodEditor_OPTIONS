
void __thiscall FUN_01b0c2e0(int param_1,uint *param_2,uint *param_3,char param_4)

{
  byte bVar1;
  char cVar2;
  undefined1 uVar3;
  undefined4 uVar4;
  uint uVar5;
  int iVar6;
  uint *puVar7;
  undefined4 *puVar8;
  undefined4 *puVar9;
  uint *puVar10;
  char cStack0000000f;
  undefined4 local_c0 [17];
  byte local_79;
  uint *local_44;
  uint *local_40;
  char local_3c;
  uint local_38;
  uint local_34;
  uint *local_30;
  uint *local_2c;
  uint local_28;
  uint local_24;
  uint *local_20;
  char local_1c;
  uint *local_18;
  uint local_14;
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  puVar7 = param_3;
  local_8 = 0xffffffff;
  puStack_c = &LAB_023c1d37;
  local_10 = ExceptionList;
  puVar10 = param_3 + 2;
  cStack0000000f = param_4 == '\0';
  local_28 = *puVar10;
  local_24 = param_3[3];
  if (param_4 == '\0') {
    iVar6 = 0x10;
  }
  else {
    iVar6 = 0x17;
  }
  ExceptionList = &local_10;
  local_2c = puVar10;
  switch(local_24 >> iVar6 & 0x3f) {
  case 0:
    ExceptionList = &local_10;
    FUN_01b09650(param_2,param_3);
    break;
  case 1:
    ExceptionList = &local_10;
    FUN_01b12060(param_3,param_2);
    break;
  case 2:
    ExceptionList = &local_10;
    FUN_01b121e0(param_3,param_2);
    break;
  case 3:
    ExceptionList = &local_10;
    FUN_01b12120(param_3,param_2);
    break;
  case 4:
    ExceptionList = &local_10;
    FUN_01b12360(param_3,param_2);
    break;
  case 5:
    ExceptionList = &local_10;
    FUN_01b122a0(param_3,param_2);
    break;
  case 6:
    ExceptionList = &local_10;
    FUN_01b12420(param_3,param_2);
    break;
  case 7:
    ExceptionList = &local_10;
    FUN_01b12fa0(param_3,param_2);
    break;
  case 8:
    ExceptionList = &local_10;
    FUN_01b12590(param_3,param_2);
    break;
  case 9:
    ExceptionList = &local_10;
    FUN_01b124e0(param_3,param_2);
    break;
  case 10:
    ExceptionList = &local_10;
    FUN_01b12640(param_3,param_2);
    break;
  case 0xb:
    ExceptionList = &local_10;
    FUN_01b126f0(param_3,param_2);
    break;
  case 0xc:
    ExceptionList = &local_10;
    FUN_01b127a0(param_3,param_2);
    break;
  case 0xd:
    ExceptionList = &local_10;
    FUN_01b12850(param_3,param_2);
    break;
  case 0xe:
    ExceptionList = &local_10;
    FUN_01b12a60(param_3,param_2);
    break;
  case 0xf:
    ExceptionList = &local_10;
    FUN_01b12900(param_3,param_2);
    break;
  case 0x10:
    ExceptionList = &local_10;
    FUN_01b129b0(param_3,param_2);
    break;
  case 0x11:
    ExceptionList = &local_10;
    FUN_01b09880(param_2,param_3);
    break;
  case 0x12:
  case 0x1e:
    ExceptionList = &local_10;
    FUN_01b099a0(local_28,param_2,param_3);
    break;
  case 0x13:
    ExceptionList = &local_10;
    FUN_01b0a460(param_2,param_3);
    break;
  case 0x14:
    ExceptionList = &local_10;
    FUN_01b0b2c0(param_2,param_3);
    break;
  case 0x15:
    ExceptionList = &local_10;
    iVar6 = FUN_01aff5e0(local_28);
    uVar4 = 0;
    if (iVar6 != 0) {
      uVar4 = *(undefined4 *)(iVar6 + 0x30);
    }
    FUN_01b0b8a0(local_28,uVar4,param_2,puVar7);
    break;
  case 0x16:
    ExceptionList = &local_10;
    iVar6 = FUN_01aff5e0(local_28);
    uVar4 = 0;
    if (iVar6 != 0) {
      uVar4 = *(undefined4 *)(iVar6 + 0x30);
    }
    FUN_01b0b710(local_28,uVar4,param_2,puVar7);
    break;
  case 0x17:
    local_14 = 0;
    ExceptionList = &local_10;
    FUN_01b07be0(&local_14,param_3);
    local_18 = (uint *)0x0;
    cVar2 = FUN_01b607b0();
    if (cVar2 != '\0') {
      local_18 = (uint *)FUN_01b60490(1);
    }
    bVar1 = *(byte *)(param_1 + 0x4e);
    puVar8 = (undefined4 *)(param_1 + 8);
    puVar9 = local_c0;
    for (iVar6 = 0x13; iVar6 != 0; iVar6 = iVar6 + -1) {
      *puVar9 = *puVar8;
      puVar8 = puVar8 + 1;
      puVar9 = puVar9 + 1;
    }
    if ((bVar1 & 2) == 0) {
      uVar5 = local_24 & 0x7fff;
      puVar10 = param_2;
      if ((uVar5 != 0) && (uVar5 < local_14)) {
        local_14 = uVar5;
      }
    }
    else {
      cVar2 = FUN_01b607b0();
      if ((cVar2 == '\0') ||
         (((*(byte *)(param_1 + 0x4e) & 8) != 0 && (cVar2 = FUN_0073e470(), cVar2 != '\0')))) {
        puVar10 = param_2;
        local_44 = param_2;
        local_8 = 0;
        if (param_2 != (uint *)0x0) {
          FUN_01ae4670(0);
        }
        local_8 = 0xffffffff;
        FUN_01b12e60(local_14,DAT_02a622a8);
        puVar10 = (uint *)*puVar10;
        *(byte *)(param_1 + 0x4e) = *(byte *)(param_1 + 0x4e) | 8;
        local_18 = (uint *)0x30;
      }
      else {
        local_40 = param_2;
        local_3c = '\0';
        FUN_01b42160(&local_40,&local_28,(byte)(*param_3 >> 9) & 1);
        FUN_01b42ba0(local_14);
        if (local_3c == '\0') {
          puVar10 = (uint *)*local_40;
        }
        else {
          puVar10 = (uint *)*local_40;
        }
      }
    }
    cVar2 = FUN_01b60620(&local_30,&local_2c);
    if (cVar2 == '\0') {
      uVar5 = 0;
      if (local_14 != 0) {
        do {
          FUN_01b0c2e0(puVar10,param_3,1);
          puVar10 = (uint *)((int)puVar10 + (int)local_18);
          uVar5 = uVar5 + 1;
        } while (uVar5 < local_14);
      }
    }
    else {
      FUN_01b074a0(puVar10,local_30,local_2c,local_14);
    }
    (**(code **)(**(int **)(param_1 + 4) + 0x10))("Values");
    local_79 = local_79 ^ (*(byte *)(param_1 + 0x4f) ^ local_79) & 1;
    puVar8 = local_c0;
    puVar9 = (undefined4 *)(param_1 + 8);
    for (iVar6 = 0x13; iVar6 != 0; iVar6 = iVar6 + -1) {
      *puVar9 = *puVar8;
      puVar8 = puVar8 + 1;
      puVar9 = puVar9 + 1;
    }
    break;
  case 0x18:
  case 0x1d:
    local_34 = param_3[3];
    local_38 = *puVar10;
    local_1c = (local_34 >> 0x10 & 0x3f) != 0x18;
    local_20 = param_2;
    ExceptionList = &local_10;
    param_2 = (uint *)FUN_01b0f000();
    cVar2 = FUN_01b0bcf0(&local_20,&param_2,puVar7);
    if (cVar2 == '\0') {
      cStack0000000f = '\0';
    }
    else {
      cVar2 = FUN_01b607b0();
      if (cVar2 == '\0') {
        if (local_1c == '\0') {
          FUN_01b12e60(param_2,DAT_02a622a8);
        }
        else {
          FUN_01b12ee0(param_2,DAT_02a622a8);
        }
        if (local_1c == '\0') {
          local_18 = (uint *)*local_20;
        }
        else {
          local_18 = (uint *)*local_20;
        }
        puVar8 = (undefined4 *)(param_1 + 8);
        puVar9 = local_c0;
        for (iVar6 = 0x13; iVar6 != 0; iVar6 = iVar6 + -1) {
          *puVar9 = *puVar8;
          puVar8 = puVar8 + 1;
          puVar9 = puVar9 + 1;
        }
        *(byte *)(param_1 + 0x4e) = *(byte *)(param_1 + 0x4e) | 8;
        puVar7 = (uint *)0x0;
        puVar10 = local_18;
        if (param_2 != (uint *)0x0) {
          do {
            FUN_01b0c2e0(puVar10,param_3,1);
            puVar7 = (uint *)((int)puVar7 + 1);
            puVar10 = puVar10 + 0xc;
          } while (puVar7 < param_2);
        }
        (**(code **)(**(int **)(param_1 + 4) + 0x10))("Values");
        puVar8 = local_c0;
        puVar9 = (undefined4 *)(param_1 + 8);
        for (iVar6 = 0x13; iVar6 != 0; iVar6 = iVar6 + -1) {
          *puVar9 = *puVar8;
          puVar8 = puVar8 + 1;
          puVar9 = puVar9 + 1;
        }
      }
      else {
        FUN_01b42160(&local_20,puVar10,(byte)(*puVar7 >> 9) & 1);
        cVar2 = FUN_00600b40();
        if ((cVar2 != '\0') && ((*puVar7 & 0x10000) == 0)) {
          iVar6 = FUN_01b60490(1);
          iVar6 = iVar6 * (int)param_2;
          uVar3 = FUN_01b60590(iVar6);
          local_14 = FUN_01b29680(uVar3,iVar6);
          if (local_14 != 0) {
            local_18 = param_2;
            if (local_1c == '\0') {
              FUN_00425360(local_14,0,param_2,1,1,1,1);
            }
            else {
              local_30 = local_20;
              param_3 = local_20 + 1;
              if (((~(byte)(local_20[1] >> 0xf) & 1) != 0) && (uVar5 = *local_20, uVar5 != 0)) {
                uVar4 = FUN_01abc2c0(uVar5);
                (**(code **)(*(int *)*DAT_02a5e0f4 + 0x14))(4,uVar5,uVar4,0,0);
              }
              *local_30 = local_14;
              *param_3 = *param_3 & 0x40004000 | (uint)local_18 & 0x3fff;
            }
          }
        }
        FUN_01b42ba0(param_2);
        if (param_2 != (uint *)0x0) {
          uVar4 = FUN_01b422f0(0);
          cVar2 = FUN_01b60620(&local_44,&param_3);
          if (cVar2 == '\0') {
            puVar10 = (uint *)0x0;
            if (param_2 != (uint *)0x0) {
              do {
                uVar4 = FUN_01b422f0(puVar10);
                FUN_01b0c2e0(uVar4,puVar7,1);
                puVar10 = (uint *)((int)puVar10 + 1);
              } while (puVar10 < param_2);
            }
          }
          else {
            FUN_01b074a0(uVar4,local_44,param_3,param_2);
          }
        }
        (**(code **)(**(int **)(param_1 + 4) + 0x10))("Values");
        puVar10 = local_2c;
        if (((*(byte *)(param_1 + 0x4e) & 4) != 0) && (cVar2 = FUN_008bb950(), cVar2 != '\0')) {
          local_40 = (uint *)*puVar10;
          uVar5 = puVar10[1];
          if (((uVar5 & 0x400000) == 0) &&
             ((uVar5 = uVar5 >> 0x17 & 0x3f, uVar5 == 0x15 || (uVar5 == 0x14)))) {
            uVar4 = FUN_01b60490(1);
            FUN_01b07fb0(&local_20,uVar4);
          }
        }
      }
    }
    break;
  case 0x19:
    ExceptionList = &local_10;
    FUN_01b09c10(local_28,param_2,param_3);
    break;
  case 0x1a:
    ExceptionList = &local_10;
    FUN_01b12cf0(param_3,param_2);
    break;
  case 0x1b:
    ExceptionList = &local_10;
    FUN_01b13180(param_3,param_2);
    break;
  case 0x1c:
    ExceptionList = &local_10;
    FUN_01b0ae60(local_28,param_2,param_3);
  }
  if ((*(int *)(param_1 + 0x58) == 0) && (cStack0000000f != '\0')) {
    (**(code **)(**(int **)(param_1 + 4) + 0x14))("Property");
  }
  ExceptionList = local_10;
  return;
}

