
undefined4 __thiscall FUN_01b0bcf0(int param_1,uint param_2,int *param_3,uint param_4)

{
  int iVar1;
  int *piVar2;
  char cVar3;
  uint uVar4;
  int iVar5;
  undefined4 uVar6;
  uint uVar7;
  undefined4 local_2c;
  undefined4 local_28;
  undefined4 local_1c;
  undefined1 local_18;
  undefined1 local_11;
  void *local_10;
  undefined1 *puStack_c;
  undefined4 uStack_8;
  
  uVar4 = param_4;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_023c1d1c;
  local_10 = ExceptionList;
  ExceptionList = &local_10;
  cVar3 = FUN_01b07940(param_4,0,0);
  if ((cVar3 == '\0') && (*(char *)(param_1 + 0x7a) == '\0')) {
    ExceptionList = local_10;
    return 0;
  }
  cVar3 = FUN_01b0d140(uVar4);
  if (cVar3 == '\0') {
    ExceptionList = local_10;
    return 0;
  }
  if (*(int *)(param_1 + 0x24) < 4) {
    piVar2 = *(int **)(param_1 + 4);
    (**(code **)(*piVar2 + 8))(&DAT_02554ce8);
    (**(code **)(*piVar2 + 0x84))(param_3);
    (**(code **)(*piVar2 + 0x10))(&DAT_02554ce8);
    (**(code **)(**(int **)(param_1 + 4) + 8))("Values");
    *(byte *)(param_1 + 0x4e) = *(byte *)(param_1 + 0x4e) | 1;
    ExceptionList = local_10;
    return 1;
  }
  if (*(char *)(*(int *)(param_1 + 4) + 4) != '\0') {
    iVar5 = *(int *)(param_1 + 0x2c);
    iVar1 = *(int *)(param_1 + 0x30);
    *(byte *)(param_1 + 0x4e) = *(byte *)(param_1 + 0x4e) & 0xfb | 1;
    local_1c = 0;
    local_18 = 0;
    local_2c = *(undefined4 *)(iVar5 + 8);
    if (iVar1 == 0) {
      param_4 = (uint)((*(byte *)(iVar5 + 0xe) & 0x3f) == 0x18);
      local_1c = FUN_01b56820(*(undefined4 *)(param_1 + 0x1c));
      local_18 = (char)param_4 == '\0';
    }
    else {
      uVar4 = *(uint *)(iVar5 + 0xc) >> 0x10 & 0x3f;
      if ((uVar4 == 0x18) || (uVar4 == 0x17)) {
        param_4 = CONCAT13(1,(undefined3)param_4);
        local_1c = FUN_01b56820(iVar1);
        local_18 = param_4._3_1_ == '\0';
      }
      else {
        param_4 = param_4 & 0xffffff;
        local_1c = FUN_01b56820(iVar1);
        local_18 = param_4._3_1_ == '\0';
      }
    }
    FUN_01b42160(&local_1c,*(uint **)(param_1 + 0x2c) + 2,
                 (byte)(**(uint **)(param_1 + 0x2c) >> 9) & 1);
    local_2c = 0;
    local_28 = 0;
    FUN_01aed150(&local_2c);
    FUN_01b41f00(&local_2c);
    do {
      if (*(int *)(param_1 + 0x58) != 0) {
        uVar4 = 1;
LAB_01b0bfaa:
                    /* WARNING: Could not recover jumptable at 0x01b0bfaa. Too many branches */
                    /* WARNING: Treating indirect jump as call */
        uVar6 = (*(code *)(&DAT_01b0c2cc)[uVar4])();
        return uVar6;
      }
      cVar3 = (**(code **)(**(int **)(param_1 + 4) + 0x1c))();
      if (cVar3 != '\0') {
        uVar4 = 0;
        goto LAB_01b0bfaa;
      }
      piVar2 = *(int **)(param_1 + 4);
      (**(code **)(*piVar2 + 8))("ContentCode");
      (**(code **)(*piVar2 + 0x98))((int)&param_2 + 3);
      (**(code **)(*piVar2 + 0x10))("ContentCode");
      uVar4 = param_2 >> 0x18;
      if (uVar4 < 5) goto LAB_01b0bfaa;
      if (uVar4 == 0) {
        ExceptionList = local_10;
        return 0;
      }
    } while( true );
  }
  if (*(char *)(param_1 + 0x79) == '\0') {
    if (*(int *)(param_1 + 0x58) == 0) {
      *(byte *)(param_1 + 0x4e) = *(byte *)(param_1 + 0x4e) & 0xfe;
      goto LAB_01b0bd5b;
    }
  }
  else if (*(int *)(param_1 + 0x58) == 0) {
    local_11 = 1;
    FUN_01b0d500("ContentCode",&local_11);
  }
  if ((*(int *)(param_1 + 0x58) == 3) && (param_2 != 0)) {
    cVar3 = FUN_01b00b10();
    if (cVar3 == '\0') {
LAB_01b0bddf:
      cVar3 = FUN_0073e680();
      if (cVar3 == '\0') goto LAB_01b0be3c;
    }
    else {
      local_2c = *(undefined4 *)(uVar4 + 8);
      if (((*(uint *)(uVar4 + 0xc) & 0x400000) != 0) ||
         ((uVar4 = *(uint *)(uVar4 + 0xc) >> 0x17 & 0x3f, uVar4 != 0x15 && (uVar4 != 0x14))))
      goto LAB_01b0bddf;
    }
    uVar4 = 0;
    iVar5 = FUN_01b0f000();
    if (iVar5 != 0) {
      do {
        iVar5 = FUN_01b56ce0(*(undefined4 *)(param_1 + 0x1c),uVar4,0);
        if (iVar5 != 0) {
          uVar6 = FUN_01b02040();
          iVar5 = FUN_01aff5e0(uVar6);
          if ((*(uint *)(iVar5 + 0x18) & 0x1000) != 0) {
            *param_3 = *param_3 + -1;
          }
        }
        uVar4 = uVar4 + 1;
        uVar7 = FUN_01b0f000();
      } while (uVar4 < uVar7);
    }
  }
LAB_01b0be3c:
  if ((*(byte *)(param_1 + 0x4e) & 0x80) == 0) {
    FUN_01b07b90(param_3);
    ExceptionList = local_10;
    return 1;
  }
  param_3 = (int *)0x0;
  FUN_01b0d490(&DAT_02554ce8,&param_3);
LAB_01b0bd5b:
  FUN_01b07350();
  ExceptionList = local_10;
  return 0;
}

