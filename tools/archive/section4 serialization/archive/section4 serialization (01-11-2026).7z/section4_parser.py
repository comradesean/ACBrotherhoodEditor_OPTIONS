#!/usr/bin/env python3
"""
Section 4 Binary Parser - TRACED CODE ONLY

Based on decompiled functions:
- FUN_01b48890: BeginSection (vtable+0x0C) - reads EXACTLY 4 bytes (section size)
  * Binary mode: reads 4-byte section size via stream vtable+0x1c
  * Maintains depth counter at serializer+0x1010 (uint16)
  * Stores section size at [serializer + depth*8 + 0x10]
  * Subtracts from parent's remaining bytes at [serializer + parent_depth*8 + 0x08]

- FUN_01b077d0: Property header reader (CRITICAL - MODE DEPENDENT)
  * MODE 3 (binary): reads EXACTLY 12 BYTES total:
    - 4 bytes: Property ID via vtable+0x84
    - 8 bytes: Type Descriptor via FUN_01b0e980
    - PropertyHeaderFlag (FUN_01b076f0) is SKIPPED!
  * MODE != 3 (text): reads property name, ID, type desc, AND flags

- FUN_01b0e980: TypeDescriptor reader (8 bytes via vtable+0x4c)
  * Reads 8 bytes: type_hash (4B) + type_info (4B)
  * Type code extraction: (type_info >> 16) & 0x3F

- FUN_01b0e3d0: Type mask helper (NO stream I/O)
  * Extracts type info fields using bit masks
  * Bits 16-21: type code (0x3F0000), Bits 23-28: element type (0x1F800000)

- FUN_01b0e7e0: Flag processing (NO stream I/O)
  * Pure bit manipulation on flag bytes

- FUN_01b076f0: PropertyHeaderFlag reader (SKIPPED in mode 3!)
  * Version >= 11: reads 1 byte via vtable+0x98 (UInt8)
  * Version < 11: reads 2 bytes via vtable+0x58 (two Bools: "Final" and "Owned")

- FUN_01b0c2e0: Type dispatcher (31-way switch)
- FUN_01b11fb0: NULL handler - binary analysis shows 2 bytes: inner_type + null_value
- FUN_01b07b90: MAP count reader (reads 4 bytes via vtable+0x84)
- FUN_01b07be0: ARRAY setup (in mode 3, does NOT read count - skips to BeginAttribute)
- FUN_01b0d490: Attribute Int32 reader (BeginAttr→4 bytes→EndAttr, no extras)
- FUN_01b12fa0: UInt32 handler (reads exactly 4 bytes, no extras)
- FUN_01b42160: Iterator setup (does NOT read from stream, just copies type descriptor)
- FUN_01b084a0: Cleanup/destructor (does NOT write to stream)
- FUN_01b41f00: Trivial setter (no stream I/O)

BINARY MODE: ctx+0x58 == 3
- FUN_01b077d0 reads EXACTLY 12 bytes for property header (ID + TypeDesc)
- FUN_01b076f0 (property flags) is SKIPPED in binary mode!
- BeginSection reads EXACTLY 4 bytes (section_size), no extra bytes
- Extra bytes must come from loop structure (FUN_01b091a0) or container nesting

String Constants (Traced):
- DAT_02554cbc = "Name" (property name attribute)
- DAT_02554cb0 = "Type" (type descriptor attribute)
"""

import struct
import sys
from dataclasses import dataclass
from typing import Any, Optional, List
from enum import IntEnum


class PropertyType(IntEnum):
    """Type codes from FUN_01b0c2e0 switch table"""
    NULL = 0
    BOOL = 1
    UINT8 = 2
    INT8 = 3
    UINT16 = 4
    INT16 = 5
    FLOAT32 = 6
    UINT32 = 7
    INT32 = 8
    UINT64 = 9
    INT64 = 10
    FLOAT64 = 11
    VECTOR2 = 12     # 0x0C
    VECTOR3 = 13     # 0x0D
    VECTOR4 = 14     # 0x0E
    MATRIX3X3 = 15   # 0x0F
    MATRIX4X4 = 16   # 0x10
    STRING = 17      # 0x11
    OBJECTREF = 18   # 0x12
    OBJECTREF_EMB = 19  # 0x13
    ENUM = 20        # 0x14
    STRUCT = 21      # 0x15
    CLASS = 22       # 0x16
    ARRAY = 23       # 0x17
    MAP = 24         # 0x18
    GUID = 26        # 0x1A
    TIMESTAMP = 27   # 0x1B
    POINTER = 28     # 0x1C
    MAP_ALT = 29     # 0x1D


# TRACED: Fixed-size types from vtable dispatch
TYPE_SIZES = {
    PropertyType.NULL: 1,    # TRACED: FUN_01b11fb0 reads 1 byte via vtable+0x58
    PropertyType.BOOL: 1,
    PropertyType.UINT8: 1,
    PropertyType.INT8: 1,
    PropertyType.UINT16: 2,
    PropertyType.INT16: 2,
    PropertyType.UINT32: 4,
    PropertyType.INT32: 4,
    PropertyType.UINT64: 8,
    PropertyType.INT64: 8,
    PropertyType.FLOAT32: 4,
    PropertyType.FLOAT64: 8,
    PropertyType.STRING: 4,  # Hash only
}


@dataclass
class DynamicProperty:
    """Property structure based on traced code"""
    offset: int
    section_size: int
    property_id: int
    type_descriptor: bytes
    type_code: int
    value: Any
    raw_bytes: bytes


class Section4Parser:
    def __init__(self, data: bytes):
        self.data = data
        self.pos = 0
        self.size = len(data)

    def read_bytes(self, n: int) -> bytes:
        result = self.data[self.pos:self.pos + n]
        self.pos += n
        return result

    def read_uint8(self) -> int:
        return self.read_bytes(1)[0]

    def read_int32(self) -> int:
        return struct.unpack('<i', self.read_bytes(4))[0]

    def read_uint32(self) -> int:
        return struct.unpack('<I', self.read_bytes(4))[0]

    def is_at_end(self) -> bool:
        return self.pos >= self.size

    def parse_type_descriptor(self) -> tuple:
        """
        TRACED: FUN_01b0e980 reads 8 bytes via vtable+0x4c

        Assembly trace shows:
          MOV  EDX,[EDX+0x4c]        ; vtable+0x4c = TypeDescriptor reader
          CALL EDX                   ; *** READS 8 BYTES ***
          MOV  EAX,[local_c]         ; Get first 4 bytes (type_hash)
          MOV  ECX,[local_8]         ; Get second 4 bytes (type_info)
          MOV  [EDI],EAX             ; Store to output[0]
          MOV  [EDI+0x4],ECX         ; Store to output[4]

        Type code extraction (via FUN_01b0e3d0 bit masks):
          - (type_info >> 16) & 0x3F = primary type code (bits 16-21)
          - (type_info >> 23) & 0x3F = element/value type for containers (bits 23-28)
        """
        raw = self.read_bytes(8)
        # First 4 bytes = type_hash, second 4 bytes = type_info
        type_hash = struct.unpack('<I', raw[0:4])[0]
        type_info = struct.unpack('<I', raw[4:8])[0]
        # Extract type code from bits 16-21 (mask 0x3F0000)
        type_code = (type_info >> 16) & 0x3F
        # Extract element/value type from bits 23-28 (for containers)
        element_type = (type_info >> 23) & 0x3F
        return raw, type_code, type_hash, element_type

    def parse_value(self, type_code: int, bytes_remaining: int, element_type: int = 0, type_hash: int = 0) -> tuple:
        """
        TRACED: FUN_01b0c2e0 type dispatch

        Returns (value, bytes_consumed)

        element_type: For containers, the value/element type from type_info bits 23-28
        type_hash: The type hash for objects with class type
        """
        start_pos = self.pos

        # TRACED: Case 0 - FUN_01b09650 → FUN_01b11fb0
        # Binary analysis shows NULL reads 2 bytes total:
        # - Byte 1: Inner type code (the wrapped type, e.g., 0x0B = FLOAT64)
        # - Byte 2: Null value (0 = absent, 1 = present)
        # NOTE: FUN_01b09650 needs full decompilation to confirm structure
        if type_code == PropertyType.NULL:
            # Read inner type code (wrapped type)
            inner_type = self.read_uint8()
            # Read null value (0 or 1)
            null_value = self.read_uint8()
            bytes_consumed = 2

            value = {
                'inner_type': inner_type,
                'inner_type_name': PropertyType(inner_type).name if inner_type < 32 else f'UNKNOWN_{inner_type}',
                'is_present': null_value != 0
            }

            return value, bytes_consumed

        # TRACED: Fixed-size types via vtable dispatch
        # Binary analysis shows fixed types have trailing byte (always 0x00)
        # This may be a null indicator or terminator - needs FUN_01b12fa0 trace to confirm
        elif type_code in TYPE_SIZES:
            size = TYPE_SIZES[PropertyType(type_code)]
            raw = self.read_bytes(size)

            if type_code == PropertyType.BOOL:
                value = bool(raw[0])
            elif type_code == PropertyType.UINT8:
                value = raw[0]
            elif type_code == PropertyType.INT8:
                value = struct.unpack('<b', raw)[0]
            elif type_code == PropertyType.UINT16:
                value = struct.unpack('<H', raw)[0]
            elif type_code == PropertyType.INT16:
                value = struct.unpack('<h', raw)[0]
            elif type_code == PropertyType.UINT32:
                value = struct.unpack('<I', raw)[0]
            elif type_code == PropertyType.INT32:
                value = struct.unpack('<i', raw)[0]
            elif type_code == PropertyType.UINT64:
                value = struct.unpack('<Q', raw)[0]
            elif type_code == PropertyType.INT64:
                value = struct.unpack('<q', raw)[0]
            elif type_code == PropertyType.FLOAT32:
                value = struct.unpack('<f', raw)[0]
            elif type_code == PropertyType.FLOAT64:
                value = struct.unpack('<d', raw)[0]
            elif type_code == PropertyType.STRING:
                value = struct.unpack('<I', raw)[0]  # Hash
            else:
                value = raw.hex()

            bytes_consumed = size

            # Read trailing byte if present (observed: always 0x00 for fixed types)
            # NOTE: Need to trace FUN_01b12fa0 etc. to confirm this is part of format
            if bytes_remaining > size:
                trailing = self.read_uint8()
                bytes_consumed += 1
                if trailing != 0:
                    print(f"    Type {type_code}: unexpected trailing byte 0x{trailing:02X} (expected 0x00)")

            return value, bytes_consumed

        # TRACED: Case 0x18/0x1D - MAP/MAP_ALT
        # Binary analysis:
        # - 0x0B byte: format marker (like other section markers)
        # - 0x01 byte: value/flag
        # - 4 bytes: count
        # - entries: element_type from type_info bits 23-28 determines size
        elif type_code == PropertyType.MAP or type_code == PropertyType.MAP_ALT:
            # Read marker and flag bytes
            marker = self.read_uint8()  # Usually 0x0B
            flag = self.read_uint8()    # Usually 0x01

            # TRACED: FUN_01b07b90 reads count via vtable+0x84 (4 bytes)
            count = self.read_int32()

            bytes_consumed = 2 + 4  # marker + flag + count

            # Get element size from element_type (from type_info bits 23-28)
            try:
                element_type_name = PropertyType(element_type).name
            except ValueError:
                element_type_name = f'UNKNOWN_{element_type}'

            try:
                elem_size = TYPE_SIZES.get(PropertyType(element_type), 0)
            except ValueError:
                elem_size = 0

            # Parse entries
            entries = []
            entry_data_size = bytes_remaining - bytes_consumed

            if count > 0 and elem_size > 0:
                # Fixed-size elements
                for i in range(count):
                    if elem_size == 1:
                        entries.append(self.read_uint8())
                    elif elem_size == 4:
                        val = self.read_uint32()
                        entries.append(f'0x{val:08X}')  # Show as hex for readability
                    elif elem_size == 8:
                        val = struct.unpack('<Q', self.read_bytes(8))[0]
                        entries.append(f'0x{val:016X}')
                    else:
                        entries.append(self.read_bytes(elem_size).hex())
                bytes_consumed += count * elem_size
            elif count > 0 and element_type == PropertyType.CLASS:  # CLASS - variable size
                # Parse nested CLASS entries
                # Structure: 10-byte key + 4-byte type_hash + 4-byte content_size + 4-byte prop_size + nested properties
                entries = []
                entry_size = entry_data_size // count if count > 0 else 0

                for entry_idx in range(count):
                    entry_start = self.pos

                    # Read entry header
                    entry_key = self.read_bytes(10)  # 10-byte key (usually zeros)
                    entry_type_hash = self.read_uint32()
                    entry_content_size = self.read_uint32()
                    entry_prop_size = self.read_uint32()

                    # Parse nested properties
                    nested_props = []
                    prop_end = self.pos + entry_prop_size

                    while self.pos < prop_end and self.pos < entry_start + entry_size - 4:
                        prop_section_size = self.read_int32()
                        if prop_section_size <= 0 or prop_section_size > 100:
                            break

                        prop_id = self.read_uint32()
                        prop_type_hash = self.read_uint32()
                        prop_type_info = self.read_uint32()
                        prop_type_code = (prop_type_info >> 16) & 0x3F

                        # Read value (section_size - 12 bytes of header)
                        value_size = prop_section_size - 12
                        if value_size > 0:
                            prop_value = self.read_bytes(value_size)
                        else:
                            prop_value = b''

                        nested_props.append({
                            'prop_id': f'0x{prop_id:08X}',
                            'type': prop_type_code,
                            'value': prop_value.hex()
                        })

                    # Skip any remaining bytes in entry
                    remaining = entry_start + entry_size - self.pos
                    if remaining > 0:
                        self.read_bytes(remaining)

                    entries.append({
                        'type_hash': f'0x{entry_type_hash:08X}',
                        'properties': nested_props
                    })

                bytes_consumed += entry_data_size
            elif count > 0:
                # Unknown element type - read raw
                raw_entries = self.read_bytes(entry_data_size)
                entries = f'<{count} raw entries: {raw_entries[:32].hex()}...>'
                bytes_consumed += entry_data_size

            value = {
                'marker': marker,
                'flag': flag,
                'element_type': element_type,
                'element_type_name': element_type_name,
                'count': count,
                'entries': entries
            }

            return value, bytes_consumed

        # TRACED: Case 0x17 - ARRAY
        # FUN_01b07be0 in mode 3 (binary) does NOT read the array count!
        # It skips directly to BeginAttribute("Values") which is a NO-OP
        # The count must be passed in from elsewhere (FUN_01b0c2e0 case 0x17)
        elif type_code == PropertyType.ARRAY:
            # TRACED: In mode 3, count comes from outer context, not read here
            # The count was read by FUN_01b0c2e0 before calling FUN_01b07be0
            print(f"    ARRAY: In mode 3, count not read by FUN_01b07be0 (passed from caller)")
            return f'<ARRAY: count from caller, elements follow>', 0

        # Other complex types
        else:
            print(f"    Type {type_code}: NEED handler function decompiled")
            return f'<NEED_TRACE: type {type_code}>', 0

    def parse_property(self) -> Optional[DynamicProperty]:
        """
        TRACED: FUN_01b077d0 for binary mode (ctx+0x58 == 3)

        Assembly trace shows mode 3 reads EXACTLY 12 BYTES for header:

        1. BeginSection - EXACTLY 4 bytes (section_size) via vtable+0x0C (FUN_01b48890)
           - FUN_01b48890 reads via stream vtable+0x1c (Read4Bytes)
           - Stores size at [serializer + depth*8 + 0x10]
           - Increments depth counter at serializer+0x1010
           - NO extra bytes read by BeginSection!

        2. Property Header (FUN_01b077d0 from LAB_01b07831):
           - PropertyID: 4 bytes via vtable+0x84 (ReadUInt32)
           - TypeDescriptor: 8 bytes via FUN_01b0e980

        3. SKIPPED in mode 3 (jump at 01b07890 to LAB_01b07932):
           - PropertyHeaderFlag via FUN_01b076f0 is NOT called!

        4. Value - variable via FUN_01b0c2e0

        Total header: 4 (section) + 4 (ID) + 8 (TypeDesc) = 16 bytes before value
        Property header portion: 12 bytes (ID + TypeDesc, no flags)
        """
        if self.is_at_end():
            return None

        prop_offset = self.pos

        # TRACED: BeginSection via vtable+0x0c (FUN_01b48890) reads 4-byte section size
        section_size = self.read_int32()
        section_end = self.pos + section_size

        # TRACED: FUN_01b077d0 from LAB_01b07831 (both modes converge here)
        # PropertyID via vtable+0x84 reads 4 bytes
        property_id = self.read_uint32()

        # TRACED: FUN_01b0e980 reads 8-byte TypeDescriptor
        type_desc, type_code, type_hash, element_type = self.parse_type_descriptor()

        # TRACED: Mode 3 SKIPS PropertyHeaderFlag (FUN_01b076f0)!
        # Jump at 01b07890 goes directly to LAB_01b07932, bypassing flags read
        # NO flags byte is read in binary mode!

        # Calculate bytes remaining for value
        # Property header in mode 3 = ID(4) + TypeDesc(8) = 12 bytes, no flags
        bytes_consumed = 4 + 8  # ID + TypeDesc (NO flags in mode 3!)
        bytes_remaining = section_size - bytes_consumed

        # TRACED: FUN_01b0c2e0 dispatches based on type
        value, value_bytes = self.parse_value(type_code, bytes_remaining, element_type, type_hash)

        # Skip to section end (handles any untraced trailing bytes)
        if self.pos != section_end:
            skipped = section_end - self.pos
            if skipped > 0:
                skip_data = self.read_bytes(skipped)
                print(f"    Skipping {skipped} untraced bytes: {skip_data.hex()}")
            self.pos = section_end

        raw_bytes = self.data[prop_offset:self.pos]

        return DynamicProperty(
            offset=prop_offset,
            section_size=section_size,
            property_id=property_id,
            type_descriptor=type_desc,
            type_code=type_code,
            value=value,
            raw_bytes=raw_bytes,
        )

    def parse(self) -> dict:
        """Parse Section 4 structure

        File format (observed, NEED TO TRACE entry point):
        - 0x0000: 10 bytes unknown prefix
        - 0x000A: 4 bytes header_type
        - 0x000E: 4 bytes field_0x04
        - 0x0012: 4 bytes section_size (BeginSection for properties)
        - 0x0016: properties start
        """
        # 10-byte zero prefix from LZSS decompression (not Section 4 data)
        prefix = self.read_bytes(10)
        if prefix != b'\x00' * 10:
            print(f"WARNING: Expected 10 zero bytes from LZSS, got: {prefix.hex()}")

        # Header type hash
        header_type = self.read_uint32()

        # field_0x04
        field_0x04 = self.read_uint32()

        # Dynamic properties section (BeginSection)
        dyn_section_size = self.read_int32()
        dyn_section_end = self.pos + dyn_section_size

        print(f"Header type: 0x{header_type:08X}")
        print(f"field_0x04: {field_0x04}")
        print(f"Dynamic section: {dyn_section_size} bytes (0x{self.pos:04X} to 0x{dyn_section_end:04X})")
        print()

        properties = []
        prop_num = 0

        while self.pos < dyn_section_end:
            print(f"Property {prop_num} at 0x{self.pos:04X}:")
            prop = self.parse_property()
            if prop is None:
                break
            properties.append(prop)
            print(f"  ID=0x{prop.property_id:08X}, type={prop.type_code}, value={prop.value}")
            print()
            prop_num += 1

        return {
            'header_type': header_type,
            'field_0x04': field_0x04,
            'dyn_section_size': dyn_section_size,
            'properties': properties,
            'final_pos': self.pos,
            'file_size': self.size,
        }


class Section4Serializer:
    """Serializer for Section 4 binary format - mirrors parser structure"""

    def __init__(self):
        self.buffer = bytearray()

    def write_bytes(self, data: bytes):
        self.buffer.extend(data)

    def write_uint8(self, value: int):
        self.buffer.append(value & 0xFF)

    def write_uint16(self, value: int):
        self.buffer.extend(struct.pack('<H', value))

    def write_int32(self, value: int):
        self.buffer.extend(struct.pack('<i', value))

    def write_uint32(self, value: int):
        self.buffer.extend(struct.pack('<I', value))

    def write_uint64(self, value: int):
        self.buffer.extend(struct.pack('<Q', value))

    def serialize_value(self, type_code: int, value: Any, element_type: int = 0, type_hash: int = 0) -> bytes:
        """Serialize a value based on type code"""
        buf = bytearray()

        # NULL type: inner_type + null_value
        if type_code == PropertyType.NULL:
            buf.append(value['inner_type'])
            buf.append(1 if value['is_present'] else 0)

        # Fixed types with trailing byte
        elif type_code in TYPE_SIZES:
            size = TYPE_SIZES[PropertyType(type_code)]

            if type_code == PropertyType.BOOL:
                buf.append(1 if value else 0)
            elif type_code == PropertyType.UINT8:
                buf.append(value & 0xFF)
            elif type_code == PropertyType.INT8:
                buf.extend(struct.pack('<b', value))
            elif type_code == PropertyType.UINT16:
                buf.extend(struct.pack('<H', value))
            elif type_code == PropertyType.INT16:
                buf.extend(struct.pack('<h', value))
            elif type_code == PropertyType.UINT32:
                buf.extend(struct.pack('<I', value))
            elif type_code == PropertyType.INT32:
                buf.extend(struct.pack('<i', value))
            elif type_code == PropertyType.UINT64:
                buf.extend(struct.pack('<Q', value))
            elif type_code == PropertyType.INT64:
                buf.extend(struct.pack('<q', value))
            elif type_code == PropertyType.FLOAT32:
                buf.extend(struct.pack('<f', value))
            elif type_code == PropertyType.FLOAT64:
                buf.extend(struct.pack('<d', value))
            elif type_code == PropertyType.STRING:
                buf.extend(struct.pack('<I', value))

            # Add trailing byte
            buf.append(0x00)

        # MAP/MAP_ALT types
        elif type_code == PropertyType.MAP or type_code == PropertyType.MAP_ALT:
            buf.append(value['marker'])
            buf.append(value['flag'])
            buf.extend(struct.pack('<i', value['count']))

            entries = value['entries']
            if isinstance(entries, list):
                if value['count'] > 0 and element_type == PropertyType.CLASS:
                    # Serialize CLASS entries
                    for entry in entries:
                        buf.extend(self.serialize_class_entry(entry))
                elif value['count'] > 0:
                    # Serialize fixed-type entries
                    for entry in entries:
                        if isinstance(entry, str) and entry.startswith('0x'):
                            # Hex string
                            val = int(entry, 16)
                            try:
                                elem_size = TYPE_SIZES.get(PropertyType(element_type), 4)
                            except ValueError:
                                elem_size = 4
                            if elem_size == 1:
                                buf.append(val & 0xFF)
                            elif elem_size == 4:
                                buf.extend(struct.pack('<I', val))
                            elif elem_size == 8:
                                buf.extend(struct.pack('<Q', val))
                        elif isinstance(entry, int):
                            # Integer value
                            try:
                                elem_size = TYPE_SIZES.get(PropertyType(element_type), 4)
                            except ValueError:
                                elem_size = 4
                            if elem_size == 1:
                                buf.append(entry & 0xFF)
                            elif elem_size == 4:
                                buf.extend(struct.pack('<I', entry))
                            elif elem_size == 8:
                                buf.extend(struct.pack('<Q', entry))

        return bytes(buf)

    def serialize_class_entry(self, entry: dict) -> bytes:
        """Serialize a CLASS entry (85-byte nested object)"""
        buf = bytearray()

        # Key: 10 zero bytes
        buf.extend(b'\x00' * 10)

        # Type hash
        type_hash = int(entry['type_hash'], 16)
        buf.extend(struct.pack('<I', type_hash))

        # Serialize nested properties to calculate sizes
        props_buf = bytearray()
        for prop in entry['properties']:
            prop_buf = self.serialize_nested_property(prop)
            props_buf.extend(prop_buf)

        # Content structure: prop_data_size (4) + prop_data (N) + padding (4)
        # Total entry = 10 (key) + 4 (type_hash) + 4 (content_size) + content = 85 bytes
        # So content = 85 - 18 = 67 bytes
        # content_size = prop_data_size_field (4) + props + padding (4)
        content_size = 4 + len(props_buf) + 4  # prop_size field + props + trailing padding
        buf.extend(struct.pack('<I', content_size))

        # Property data size
        buf.extend(struct.pack('<I', len(props_buf)))

        # Properties
        buf.extend(props_buf)

        # Pad to 85 bytes
        while len(buf) < 85:
            buf.append(0x00)

        return bytes(buf[:85])

    def serialize_nested_property(self, prop: dict) -> bytes:
        """Serialize a nested property within a CLASS entry"""
        buf = bytearray()

        # Parse property values
        prop_id = int(prop['prop_id'], 16)
        type_code = prop['type']
        value_hex = prop['value']

        # Build property content (without section_size)
        content = bytearray()
        content.extend(struct.pack('<I', prop_id))
        content.extend(struct.pack('<I', 0))  # type_hash always 0
        content.extend(struct.pack('<I', type_code << 16))  # type_info
        content.extend(bytes.fromhex(value_hex))

        # Write section_size + content
        buf.extend(struct.pack('<I', len(content)))
        buf.extend(content)

        return bytes(buf)

    def serialize_property(self, prop: DynamicProperty, element_type: int = 0, type_hash: int = 0) -> bytes:
        """Serialize a single property"""
        # Get type_hash and element_type from type_descriptor
        td = prop.type_descriptor
        th = struct.unpack('<I', td[0:4])[0]
        ti = struct.unpack('<I', td[4:8])[0]
        et = (ti >> 23) & 0x3F

        # Serialize the value
        value_bytes = self.serialize_value(prop.type_code, prop.value, et, th)

        # Build property content
        content = bytearray()
        content.extend(struct.pack('<I', prop.property_id))
        content.extend(prop.type_descriptor)
        content.extend(value_bytes)

        # Build full property with section_size
        result = bytearray()
        result.extend(struct.pack('<i', len(content)))
        result.extend(content)

        return bytes(result)

    def serialize(self, parsed: dict) -> bytes:
        """Serialize a parsed Section 4 structure back to binary"""
        self.buffer = bytearray()

        # 10-byte zero prefix
        self.write_bytes(b'\x00' * 10)

        # Header type
        self.write_uint32(parsed['header_type'])

        # field_0x04
        self.write_uint32(parsed['field_0x04'])

        # Serialize all properties first to get total size
        props_data = bytearray()
        for prop in parsed['properties']:
            td = prop.type_descriptor
            ti = struct.unpack('<I', td[4:8])[0]
            et = (ti >> 23) & 0x3F
            th = struct.unpack('<I', td[0:4])[0]
            props_data.extend(self.serialize_property(prop, et, th))

        # Write section size
        self.write_int32(len(props_data))

        # Write properties
        self.write_bytes(props_data)

        # 4-byte footer
        self.write_bytes(b'\x00' * 4)

        return bytes(self.buffer)


def roundtrip_test(filename: str) -> bool:
    """Test roundtrip: parse -> serialize -> compare"""
    with open(filename, 'rb') as f:
        original = f.read()

    print(f"Roundtrip test for {filename}")
    print("=" * 60)

    # Parse
    parser = Section4Parser(original)
    parsed = parser.parse()

    print()
    print("Serializing...")

    # Serialize
    serializer = Section4Serializer()
    serialized = serializer.serialize(parsed)

    # Compare
    print(f"Original size:   {len(original)} bytes")
    print(f"Serialized size: {len(serialized)} bytes")

    if original == serialized:
        print("ROUNDTRIP SUCCESS: Files are identical!")
        return True
    else:
        # Find first difference
        min_len = min(len(original), len(serialized))
        for i in range(min_len):
            if original[i] != serialized[i]:
                print(f"ROUNDTRIP FAILED: First difference at offset 0x{i:04X}")
                print(f"  Original:   0x{original[i]:02X}")
                print(f"  Serialized: 0x{serialized[i]:02X}")
                # Show context
                start = max(0, i - 8)
                end = min(min_len, i + 8)
                print(f"  Original context:   {original[start:end].hex()}")
                print(f"  Serialized context: {serialized[start:end].hex()}")
                break
        else:
            if len(original) != len(serialized):
                print(f"ROUNDTRIP FAILED: Size mismatch")

        # Save serialized for comparison
        out_file = filename.replace('.bin', '_serialized.bin')
        with open(out_file, 'wb') as f:
            f.write(serialized)
        print(f"Serialized output saved to: {out_file}")

        return False


def main():
    if len(sys.argv) < 2:
        print("Usage: python section4_parser.py <file.bin> [--roundtrip]")
        sys.exit(1)

    filename = sys.argv[1]
    do_roundtrip = '--roundtrip' in sys.argv

    with open(filename, 'rb') as f:
        data = f.read()

    print(f"Parsing {filename} ({len(data)} bytes)")
    print("=" * 60)
    print()

    parser = Section4Parser(data)
    result = parser.parse()

    print("=" * 60)
    print(f"Properties parsed: {len(result['properties'])}")
    print(f"Final position: 0x{result['final_pos']:04X} / 0x{result['file_size']:04X}")

    remaining = result['file_size'] - result['final_pos']
    if remaining > 0:
        print(f"Remaining: {remaining} bytes")

    if do_roundtrip:
        print()
        roundtrip_test(filename)


if __name__ == '__main__':
    main()
