# Section 4 Serialization Corrections

Based on hex dump analysis of game_uncompressed_4.bin properties.

---

## CRITICAL CORRECTION: FLAGS Byte Exists!

**Previous assumption:** MODE 3 (binary) skips the flags byte
**Correction:** Section 4 DOES have a FLAGS byte (0x0B) after type_descriptor

### Corrected Property Format
```
[4B] section_size
[4B] property_id
[8B] type_descriptor (type_hash + type_info)
[1B] FLAGS (0x0B)        ← WE WERE MISSING THIS!
[var] value
```

---

## Type Confirmation Table

| Offset | section_size | prop_id | type_hash | type_info | type_code | Proposed Type | value bytes | Notes |
|--------|-------------|---------|-----------|-----------|-----------|---------------|-------------|-------|
| 0x16 | 17 (0x11) | 0xBF4C2013 | 0x00000000 | 0x00070000 | 7 | UINT32 | 4 | flags(1)+value(4)=5, total=4+8+5=17 ✓ |
| 0x2B | 18 (0x12) | 0xF201D917 | 0x94DAAEE6 | 0x0B1D0000 | 0x1D=29 | MAP_ALT? | 5 | elem_type=0x16=CLASS, needs confirm |
| 0x41 | 18 (0x12) | 0xC021791A | ??? | ??? | 0x1D=29 | MAP_ALT? | 5 | 17 CLASS entries, skip for now |
| 0x5FC | 18 (0x12) | 0x49B0B6FE | 0x00000000 | 0x039D0000 | 0x1D=29 | MAP_ALT? | 5 | elem_type=0x07=UINT32, count=0 |
| 0x612 | 30 (0x1E) | 0xA5D5C8DE | 0x00000000 | 0x039D0000 | 0x1D=29 | MAP_ALT? | 17 | elem_type=0x07=UINT32, count=3 |
| 0x634 | 14 (0x0E) | 0xF6282AFE | 0x00000000 | 0x00000000 | 0 | **BOOL** | 1 | value=false |
| 0x646 | 14 (0x0E) | 0x9F1438A5 | 0x00000000 | 0x00000000 | 0 | **BOOL** | 1 | value=true |
| 0x658 | 14 (0x0E) | 0xAFBEEA25 | 0x00000000 | 0x00000000 | 0 | **BOOL** | 1 | value=false |
| 0x66A | 14 (0x0E) | 0x221991EF | 0x00000000 | 0x00000000 | 0 | **BOOL** | 1 | value=true |
| 0x67C | 14 (0x0E) | 0x20AD7434 | 0x00000000 | 0x00000000 | 0 | **BOOL** | 1 | value=true |
| 0x68E | 14 (0x0E) | 0xB6BA16BB | 0x00000000 | 0x00000000 | 0 | **BOOL** | 1 | value=true |
| 0x6A0 | 14 (0x0E) | 0x1A361AE1 | 0x00000000 | 0x00000000 | 0 | **BOOL** | 1 | value=true |
| 0x6B2 | 21 (0x15) | 0x605F5F37 | 0x00000000 | 0x00090000 | 9 | UINT64 | 8 | flags(1)+value(8)=9, total=4+8+9=21 ✓ |
| 0x6CB | 18 (0x12) | 0x25170D6B | 0x00000000 | 0x039D0000 | 0x1D=29 | MAP_ALT? | 5 | elem_type=0x07=UINT32, count=0 |

---

## CONFIRMED: type_code=0 is BOOL, not NULL!

### Evidence from Ghidra PropertyDescriptor structures:

**UINT32 field (DAT_027ecf90):**
```
+0x00: 01 00 00 02     flags = 0x02000001
+0x04: 13 20 4c bf     property_hash = 0xBF4C2013
+0x08: 00 00 00 00 00 00
+0x0E: 07 00           type_byte = 0x07 = UINT32
+0x10: 00 00 10 00     scaled_offset
```

**BOOL field (DAT_02973250):**
```
+0x00: 01 00 00 02     flags = 0x02000001
+0x04: 66 69 54 3b     property_hash = 0x3B546966
+0x08: 00 00 00 00 00 00
+0x0E: 00 00           type_byte = 0x00 = BOOL
+0x10: 00 00 80 00     scaled_offset
```

**UINT64 field (DAT_029732d0):**
```
+0x0E: 09 00           type_byte = 0x09 = UINT64
```

### Corrected PropertyType Enum:
```
0x00 = BOOL      (NOT NULL!)
0x07 = UINT32
0x09 = UINT64
0x18 = (untraced name) - same handler as 0x1D
0x1D = (untraced name) - same handler as 0x18
```

---

## FUN_01b0c2e0 - Type Dispatcher (31-way switch)

Type code extraction:
```c
if (param_4 == '\0') {
    iVar6 = 0x10;  // Primary type: bits 16-21
} else {
    iVar6 = 0x17;  // Element type: bits 23-28
}
switch(local_24 >> iVar6 & 0x3f) { ... }
```

### Complete Type Handler Table

| Case | Handler | Shared With | Notes |
|------|---------|-------------|-------|
| 0 | FUN_01b09650 | | BOOL (confirmed from PropertyDescriptor) |
| 1 | FUN_01b12060 | | |
| 2 | FUN_01b121e0 | | |
| 3 | FUN_01b12120 | | |
| 4 | FUN_01b12360 | | |
| 5 | FUN_01b122a0 | | |
| 6 | FUN_01b12420 | | |
| 7 | FUN_01b12fa0 | | UINT32 (confirmed from PropertyDescriptor) |
| 8 | FUN_01b12590 | | |
| 9 | FUN_01b124e0 | | UINT64 (confirmed from PropertyDescriptor) |
| 10 | FUN_01b12640 | | |
| 11 | FUN_01b126f0 | | |
| 12 | FUN_01b127a0 | | |
| 13 | FUN_01b12850 | | |
| 14 | FUN_01b12a60 | | |
| 15 | FUN_01b12900 | | |
| 16 | FUN_01b129b0 | | |
| 17 | FUN_01b09880 | | |
| 18 | FUN_01b099a0 | 30 | Same handler as case 30 |
| 19 | FUN_01b0a460 | | |
| 20 | FUN_01b0b2c0 | | |
| 21 | FUN_01b0b8a0 | | |
| 22 | FUN_01b0b710 | | |
| 23 | FUN_01b07be0 | | |
| **24 (0x18)** | **FUN_01b0bcf0** | **29** | **Same handler as case 29!** |
| 25 | FUN_01b09c10 | | |
| 26 | FUN_01b12cf0 | | |
| 27 | FUN_01b13180 | | |
| 28 | FUN_01b0ae60 | | |
| **29 (0x1D)** | **FUN_01b0bcf0** | **24** | **Same handler as case 24!** |
| 30 | FUN_01b099a0 | 18 | Same handler as case 18 |

### Key Finding: Types 24 and 29 are NOT different types!

```c
case 0x18:
case 0x1d:
    // SAME CODE - fall through
    local_1c = (local_34 >> 0x10 & 0x3f) != 0x18;  // Only difference: checks if NOT 0x18
    cVar2 = FUN_01b0bcf0(&local_20, &param_2, puVar7);
    ...
```

The names "MAP" and "MAP_ALT" were **invented** - they share identical handling via FUN_01b0bcf0.

### FUN_01b12fa0 confirms mode behavior:
```c
// CloseSection("Property") is SKIPPED in modes 1, 2, 3:
if ((iVar2 != 1) && (iVar2 != 2) && (iVar2 != 3)) {
    (*vtable+0x14)("Property");
}
```

### FUN_01b09620 confirms mode 3 behavior:
```c
if (ctx+0x58 == 3) {
    FUN_01b091a0(param_2);  // Serialize dynamic props immediately
} else {
    ctx+0x28 = param_2;     // Store pointer for later
}
```

---

## Confirmed Sizes (with FLAGS byte)

| Type | type_code | value_size | total_prop_size | formula |
|------|-----------|------------|-----------------|---------|
| BOOL | 0 | 1 | 14 | 4+8+1+1 |
| UINT32 | 7 | 4 | 17 | 4+8+1+4 |
| UINT64 | 9 | 8 | 21 | 4+8+1+8 |
| MAP_ALT (empty) | 29 (0x1D) | 5 | 18 | 4+8+1+1+1+4 (flags+marker+flag+count) |
| MAP_ALT (3 entries) | 29 (0x1D) | 17 | 30 | 4+8+1+1+1+4+12 |

---

## Parser Value Interpretation Errors

| Property | Current Parser | Correct Interpretation |
|----------|----------------|------------------------|
| UINT32 @ 0x16 | type=7, value=11 (0x0B) | type=7, flags=0x0B, value=0 |
| UINT64 @ 0x6B2 | type=9, value=11 | type=9, flags=0x0B, value=0 |
| BOOL @ 0x634 | type=0 (NULL), inner_type=11, null=0 | type=0 (BOOL), flags=0x0B, value=false |
| BOOL @ 0x646 | type=0 (NULL), inner_type=11, null=1 | type=0 (BOOL), flags=0x0B, value=true |

### Root Cause:
Parser reads FLAGS byte (0x0B) as part of value, shifting all value interpretation by 1 byte.

---

## TODO
- [x] Confirm BOOL vs NULL for type_code=0 → **BOOL confirmed!**
- [x] Determine what NULL type actually looks like → **NULL type likely doesn't exist!**
- [x] Trace type dispatcher → **FUN_01b0c2e0 - types 24 & 29 share FUN_01b0bcf0!**
- [x] Trace FUN_01b07b90 → **Reads "Size" (4 bytes) via vtable+0x84, no prefix bytes**
- [ ] Confirm what 0x0B byte is (FLAGS or type-specific?)
- [ ] Confirm what 0x01 byte is for types 24/29
- [ ] Update parser to read FLAGS byte BEFORE value
- [ ] Update PropertyType enum: BOOL=0, remove invented names

## Note on NULL Type

**NULL probably doesn't exist as a separate type code.**

Optionality is handled by:
1. Property not being serialized if null (absent from stream)
2. FLAGS byte may encode presence metadata
3. Dynamic property loop (IsAtEnd) handles variable property counts

The original "NULL with inner_type" interpretation was wrong - we were misreading FLAGS + BOOL value.
