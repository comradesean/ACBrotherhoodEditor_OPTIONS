# Section 4 Serialization Format Documentation

**File:** `game_uncompressed_4.bin` (1903 bytes)
**Last Updated:** January 2026 - ROUNDTRIP VERIFIED

---

## Quick Reference

| Item | Value | Source |
|------|-------|--------|
| File Size | 1903 bytes | Measured |
| Header Size | 14 bytes | FUN_01b08ce0 |
| Content Size | 1877 bytes | BeginSection/FUN_01b48890 reads exactly 4 bytes (0x12 + 4 + 1877 = 1903) |
| Entry Count | N/A | READ path uses IsAtEnd loop (no count read) |
| Properties Parsed | 15 | Successfully parsed with BeginSection per property |
| Root Type Hash | 0xB4B55039 | "AssassinMultiProfileData" |
| Base Type Hash | 0xB7806F86 | "SaveGameDataObject" |
| **Roundtrip Status** | **100% PASS** | SHA256 verified byte-identical |

---

## Function Call Hierarchy

```
Section 4 Deserialization Entry
└── FUN_01afd600 - Section 4 entry point (NEEDS FULL TRACE)
    │   - Entry point that initializes section 4 deserialization
    │   - Sets up serialization context (ctx+0x04 = BinarySerializer ptr)
    │   - Configures mode at ctx+0x58 (1/2/3 for binary modes)
    │
    └── FUN_01b0a740 - Generic object deserializer
        ├── FUN_01b08ce0 - Object header [SKIPPED in binary mode]
        └── vtable[1] - Object's Serialize method
            │
            ├──[AssassinMultiProfileData]────────────────────────────
            │   └── FUN_01712330 - Root serializer (0xB4B55039)
            │       ├── FUN_01b09e20 - Type registration [write only]
            │       ├── FUN_005e3700 - SaveGameDataObject::Serialize
            │       └── FUN_01b0d0c0 - Property dispatcher [NO-OP]
            │
            └──[SaveGameDataObject]──────────────────────────────────
                └── FUN_005e3700 - Base serializer (0xB7806F86)
                    ├── FUN_01b0a1f0 → FUN_01b12fa0 - field+0x04 [4 bytes]
                    │   ├── FUN_01b07940 - Validation [NO DATA]
                    │   └── vtable+0x84 - ReadInt32
                    │
                    ├── FUN_01b09620 - Dynamic properties setup
                    │   │   (ctx+0x58==3: calls FUN_01b091a0 directly)
                    │   │   (ctx+0x58!=3: stores ptr to ctx+0x28)
                    │   │
                    │   └── FUN_01b091a0 - Dynamic properties serializer
                    │       │
                    │       ├── [WRITE PATH: serializer+0x04 == 0]
                    │       │   ├── Writes NbDynamicProperties count
                    │       │   └── Iterates property list
                    │       │
                    │       └── [READ PATH: serializer+0x04 != 0]
                    │           └── while (!IsAtEnd()):
                    │               ├── FUN_01b077d0 - Read property header
                    │               │   ├── [MODE 3]: 12 bytes (ID + TypeDesc, flags SKIPPED)
                    │               │   └── [MODE != 3]: 12+ bytes (name + ID + TypeDesc + flags)
                    │               └── FUN_01b0c2e0 - Read value by type
                    │
                    └── FUN_01b0d0c0 - [NO-OP when ctx+0x6c==0]

FUN_01b0c2e0 - Type Dispatcher (31 types)
├── 0x00: NULL [1B] → FUN_01b09650 → FUN_01b11fb0 (reads 1 byte via vtable+0x58)
├── 0x01: Bool [1B] → vtable+0x90
├── 0x02: Int8 [1B] → vtable+0x94
├── 0x03: UInt8 [1B] → vtable+0x98
├── 0x04: Int16 [2B] → vtable+0x88
├── 0x05: UInt16 [2B] → vtable+0x8C
├── 0x06: Int32 [4B] → vtable+0x80
├── 0x07: UInt32 [4B] → vtable+0x84
├── 0x08: Int64 [8B] → vtable+0x78
├── 0x09: UInt64 [8B] → vtable+0x7C
├── 0x0A: Float32 [4B] → vtable+0x74
├── 0x0B: Float64 [8B] → vtable+0x70
├── 0x0C: Vector2 [12B PADDED] → vtable+0x6C
├── 0x0D: Vector3 [16B PADDED] → vtable+0x68
├── 0x0E: Vector4 [16B] → vtable+0x5C
├── 0x0F: Matrix3x3 [36B col-major] → vtable+0x64
├── 0x10: Matrix4x4 [64B col-major] → vtable+0x60
├── 0x11: String [4B hash] → vtable+0x9C
├── 0x17: ARRAY [4B count + N×recursive] → FUN_01b07be0
├── 0x18: MAP [2B prefix + 4B count + N×(key+value)] → FUN_01b0bcf0
├── 0x1A: GUID [var ASCII] → vtable+0x48
├── 0x1B: Timestamp [var UTF-16] → vtable+0x44
├── 0x1C: POINTER [recursive ref] → FUN_01b0ae60
└── 0x1D: MAP_ALT [2B prefix + 4B count + N×(key+value)] → FUN_01b0bcf0 (same as 0x18)
```

### Complex Type Handlers (Detailed Analysis)

#### Case 0x00: NULL Type - FUN_01b09650 → FUN_01b11fb0 (BINARY ANALYSIS UPDATED)
```
Bytes Read: 2
Format: [0x00] Inner type code (1 byte) + [0x01] Null value (1 byte)
Purpose: NULL is an "optional" wrapper around another type

BINARY ANALYSIS (January 2026):
  - Binary data shows NULL reads 2 bytes total:
    - Byte 1: Inner type code (wrapped type, e.g., 0x0B = FLOAT64)
    - Byte 2: Null value (0 = absent/null, 1 = present/has value)

  - Example from game_uncompressed_4.bin:
    - Property 5: 0x0B 0x00 = optional FLOAT64, not present
    - Property 6: 0x0B 0x01 = optional FLOAT64, present

  - All NULL properties in test file wrap FLOAT64 (type 11)

  - NOTE: FUN_01b09650 needs full decompilation to confirm this structure
    FUN_01b11fb0 may only read the second byte (null value)
    The first byte (inner type) may be read by FUN_01b09650 before calling FUN_01b11fb0
```

#### Case 0x17: ARRAY Type - FUN_01b07be0 (TRACED - Mode 3 Specific)
```
CRITICAL: In mode 3 (binary), FUN_01b07be0 does NOT read the array count!

FUN_01b07be0 trace (mode 3 path):
  - Checks ctx+0x58 == 3
  - If mode 3: Skips directly to BeginAttribute("Values") which is NO-OP
  - Does NOT read count from stream in mode 3
  - Count is passed in from FUN_01b0c2e0 (case 0x17) via local_14

Format in mode 3:
  - Count comes from outer context (FUN_01b0c2e0 reads it before calling)
  - Elements follow directly
  - Element type extracted from type descriptor
  - Each element deserialized via recursive FUN_01b0c2e0 calls

Format in other modes (text):
  [0x00-0x03] UInt32 array_count    ← Read by FUN_01b07be0
  [0x04-...] Element[0]             ← Recursive FUN_01b0c2e0 call
  [...]      Element[1..N-1]        ← Recursive for each element
```

#### Case 0x18/0x1D: MAP/MAP_ALT Type - FUN_01b0bcf0 (BINARY ANALYSIS UPDATED)
```
BINARY ANALYSIS (January 2026):
  Binary data shows MAP/MAP_ALT reads 6 bytes header:
    - Byte 1: Key type code (e.g., 0x0B = FLOAT64)
    - Byte 2: Value type code (e.g., 0x01 = BOOL)
    - Bytes 3-6: Entry count (Int32)

  Example from game_uncompressed_4.bin:
    - Property 1: 0x0B 0x01 00000000 = MAP<FLOAT64, BOOL> with 0 entries
    - Property 2: 0x0B 0x01 11000000 = MAP<FLOAT64, BOOL> with 17 entries

TRACED Assembly (FUN_01b0bcf0.md):
  - Reads ContentCode via vtable+0x98 (UInt8)
  - ContentCode > 4 triggers LAB_01b0c268 which loops back to LAB_01b0bf50
  - In binary mode (ctx+0x58 != 0), sets EAX=1 and jumps to switch
  - Case 1 calls FUN_01b07b90 which reads count via vtable+0x84 (4 bytes)

INTERPRETATION:
  - The "ContentCode" read may actually be reading the key type
  - The second byte (value type) may be read by case 1 or element iteration
  - FUN_01b0bcf0 needs more tracing to confirm exact byte sequence

Binary Format (observed):
  [0x00]      UInt8 key_type       ← Type code for map keys
  [0x01]      UInt8 value_type     ← Type code for map values
  [0x02-0x05] Int32 entry_count    ← Number of key-value pairs
  [0x06-...] Entry[0]              ← key + value by their types
  [...]      Entry[1..N-1]         ← Repeated for all entries

Both MAP (0x18) and MAP_ALT (0x1D) use the same handler and format.
```

#### Case 0x1C: POINTER Type - FUN_01b0ae60
```
Bytes Read: Variable (depends on referenced type)
Format: Deserializes a pointer reference, calls FUN_01b0c2e0
        recursively on the pointed-to type.
```

---

## FUN_01b0e7e0 - Flag Processing (NO STREAM I/O) (TRACED)

This function performs flag bit manipulation but does NO stream I/O.

### Assembly Trace

```asm
FUN_01b0e7e0:
01b0e7e5  MOV  EDI,ECX               ; this
01b0e7e7  MOV  EAX,[EDI+0x4]         ; Get serializer
01b0e7ea  MOV  AL,[EAX+0x4]          ; Get mode flag byte
01b0e7ed  MOV  CL,[EBP+Stack[0xc]]   ; param_3
01b0e7f0  TEST AL,AL                 ; Check mode
01b0e7f2  JZ   LAB_01b0e866          ; If mode==0 (text), go to text path
01b0e7f4  TEST CL,CL                 ; Check param_3
01b0e7f6  JZ   LAB_01b0e862
; ... lots of bit manipulation XOR/AND/SHR operations on flags ...
; NO vtable calls, NO stream reads - pure flag processing
```

### Key Finding

**This function does NO stream I/O** - it only processes flag bytes in memory using bitwise operations (XOR, AND, SHR).

### Behavior Summary

| Mode | Action | Bytes Read |
|------|--------|------------|
| Text (mode=0) | Text path processing | 0 |
| Binary (mode!=0) | Flag bit manipulation | 0 |

---

## FUN_01b48890 - BeginSection (vtable+0x0C) (TRACED)

This function handles section nesting for binary serialization. Complete assembly trace provided.

### Key Discovery

**BeginSection reads EXACTLY 4 bytes in binary mode.** No extra bytes. The section size
read is used for nested section accounting.

### Assembly Trace

```asm
FUN_01b48890:
01b48895  MOV  ESI,ECX               ; this = serializer
01b48897  CMP  byte ptr [ESI+0x4],0x0 ; Check mode flag (0=text, non-zero=binary)
01b4889b  MOV  ECX,[ESI+0x8]         ; Get stream object
01b4889e  MOV  EAX,[ECX]             ; Get stream vtable
01b488a0  JNZ  LAB_01b488db          ; If binary mode, jump

; --- TEXT MODE PATH (mode == 0) ---
01b488a2  MOV  EDX,[EAX+0x4c]        ; stream vtable+0x4c (some text operation)
01b488a5  CALL EDX
01b488a7  MOVZX ECX,word ptr [ESI+0x1010]  ; Get section depth counter
01b488ae  MOV  [ESI+ECX*8+0x14],EAX  ; Store at depth offset
01b488b9  MOV  [ESI+EDX*8+0x10],0x0  ; Zero another field
01b488c9  PUSH 0x4                   ; Push 4
01b488cb  CALL [vtable+0x44]         ; Skip 4 bytes
01b488cd  INC  word ptr [ESI+0x1010] ; Increment depth
; ...return...

; --- BINARY MODE PATH (mode != 0) ---
LAB_01b488db:
01b488db  MOV  EAX,[EAX+0x1c]        ; stream vtable+0x1c = Read4Bytes
01b488de  LEA  EDX,[local_8]         ; address for result
01b488e1  PUSH EDX
01b488e2  CALL EAX                   ; *** READS 4 BYTES (section size) ***
01b488e4  MOVZX ECX,word ptr [ESI+0x1010]  ; Get depth counter
01b488eb  MOV  EDX,[local_8]         ; Get the 4 bytes read
01b488ee  MOV  [ESI+ECX*8+0x10],EDX  ; Store section size at depth offset
01b488f9  TEST AX,AX                 ; Check if depth > 0
01b488fc  JBE  LAB_01b4890c          ; Skip if at root
01b488fe  MOV  ECX,[local_8]         ; Get section size again
01b48904  SUB  [ESI+EAX*8+0x8],ECX   ; Subtract from PARENT's remaining bytes
01b4890c  INC  word ptr [ESI+0x1010] ; Increment section depth
```

### Behavior Summary

| Mode | Action | Bytes Read |
|------|--------|------------|
| Text (mode=0) | Stream operation via vtable+0x4c, skip 4 bytes | 0 (skips 4) |
| Binary (mode!=0) | Read 4 bytes via stream vtable+0x1c | **Exactly 4** |

### Depth Tracking Mechanism

The serializer maintains a **section depth stack** at offset 0x1010 (uint16).

```
Serializer Layout:
  +0x04      : Mode flag (0=text, non-zero=binary)
  +0x08      : Stream object pointer
  +0x10      : Section data array start (depth-indexed)
  +0x1010    : Section depth counter (uint16)

Section Array (at serializer+0x08 + depth*8):
  +0x00 (depth*8+0x08) : Remaining bytes for this section
  +0x08 (depth*8+0x10) : Section size (stored here in binary mode)
  +0x0C (depth*8+0x14) : Text mode position marker
```

### Nested Section Accounting

When a nested section begins:
1. Current depth is read from serializer+0x1010
2. Section size (4 bytes) is read and stored at `[serializer + depth*8 + 0x10]`
3. If depth > 0: Parent's remaining bytes at `[serializer + parent_depth*8 + 0x08]` is decreased
4. Depth counter is incremented

**This explains how the game tracks nested property sections.**

### Binary Format

```
BeginSection in binary mode:
  [0x00-0x03] Int32 section_size   ← Read via stream vtable+0x1c (Read4Bytes)
              No other bytes read!
              Section size = number of bytes in this section (not including the 4-byte size)
```

### Implications for Parser

1. BeginSection reads **EXACTLY** 4 bytes - no prefix, no suffix
2. The 4-byte value is the section content size (bytes following)
3. Extra bytes seen in data are NOT from BeginSection
4. Look for extra bytes in property header reading (FUN_01b077d0)

---

## FUN_01b11fb0 - NULL Value Handler (TRACED)

This function handles the NULL type (case 0x00 in FUN_01b0c2e0).

### Key Discovery

**NULL type reads 1 byte, NOT 0 bytes as previously documented.**

### Decompiled Behavior

```c
void __thiscall FUN_01b11fb0(void *param_1, void *param_2)
{
    // Reads 1 byte via vtable+0x58 (VarBool)
    byte value;
    (*vtable+0x58)(&value);

    // Normalizes to 0 or 1
    // Any non-zero value becomes 1
    *output = (value != 0) ? 1 : 0;
}
```

### Binary Format

```
[0x00] UInt8 value ← Read via vtable+0x58 (VarBool)
       Result is normalized: 0 stays 0, any non-zero becomes 1
```

---

## FUN_01b42160 - Iterator Setup (TRACED)

This function sets up an iterator for container traversal.

### Key Discovery

**Does NOT read from stream. Just copies 8-byte type descriptor from memory.**

### Behavior

- Takes an iterator struct and type descriptor as parameters
- Copies 8-byte type descriptor from memory into iterator struct
- Pure memory operation, no stream I/O
- MAP prefix bytes do NOT come from this function

---

## FUN_01b084a0 - Cleanup/Destructor (TRACED)

### Key Discovery

**Does NOT write to stream. Pure cleanup function.**

### Behavior

- Reference counting operations
- Memory release
- File trailer does NOT come from this function

---

## FUN_01b07be0 - ARRAY Setup (TRACED - Mode 3 Behavior)

### Key Discovery

**In mode 3 (binary), this function does NOT read the array count!**

### Mode 3 Path

```c
if (ctx+0x58 == 3) {
    // Skips directly to BeginAttribute("Values")
    // BeginAttribute is NO-OP in binary mode
    // Count is NOT read here - it's passed from FUN_01b0c2e0 case 0x17
}
```

### Implications

- Array count in mode 3 comes from outer context (FUN_01b0c2e0)
- FUN_01b0c2e0 case 0x17 reads count into `local_14` before calling FUN_01b07be0
- This explains why we don't see a separate count read in mode 3 binary data

---

## FUN_01b0d490 - Attribute Int32 Reader (TRACED)

### Binary Format

```
BeginAttribute(name) → NO-OP in binary mode
vtable+0x84          → Reads exactly 4 bytes (Int32)
EndAttribute(name)   → NO-OP in binary mode
```

### Key Finding

**Reads exactly 4 bytes, no extra bytes.** The "extra byte" mystery is NOT in type handlers - must come from BeginSection/property structure.

---

## FUN_01b41f00 - Trivial Setter (TRACED)

### Assembly

```asm
MOV [ECX+0x10], EAX
RET
```

### Key Finding

**NO stream I/O.** Just stores a value at offset 0x10 of the object.

---

## FUN_01b0bcf0 - MAP/MAP_ALT Handler (TRACED from Assembly)

This function handles MAP (0x18) and MAP_ALT (0x1D) type serialization.
Complete assembly trace from FUN_01b0bcf0.md.

### Function Entry and Mode Checks

```asm
[0x01b0bd1b] CALL FUN_01b07940           ; Validation (no I/O)
[0x01b0bd35] CMP dword ptr [EBX + 0x24],0x4  ; Version check
[0x01b0bd39] JL LAB_01b0c275             ; Version < 4 uses different path
[0x01b0bd42] MOV ECX,dword ptr [EBX + 0x4]   ; Get serializer
[0x01b0bd46] CMP byte ptr [ECX + 0x4],0x0    ; Check text vs binary mode
[0x01b0bd46] JNZ LAB_01b0be7f            ; Binary mode (non-zero) jumps here
```

### Binary Mode Path (LAB_01b0be7f, ctx+0x04 != 0)

```asm
[LAB_01b0be7f]
  MOV DL,byte ptr [EBX + 0x4e]   ; Get flags
  MOV ESI,dword ptr [EBX + 0x2c] ; Get property definition
  MOV ECX,dword ptr [EBX + 0x30] ; Get ctx+0x30
  AND DL,0xfb                     ; Clear bit 2
  OR  DL,0x1                      ; Set bit 0
  MOV byte ptr [EBX + 0x4e],DL   ; Store flags

[0x01b0be98] MOV EAX,dword ptr [ESI + 0x8]  ; Get type hash from descriptor
[0x01b0bea5] SHR EAX,0x10                    ; Shift right 16 bits
[0x01b0bea8] AND EAX,0x3f                    ; Mask to 6 bits (type code)
[0x01b0beab] CMP EAX,0x18                    ; Check if MAP type
```

### Mode 3 Check (ctx+0x58 == 3)

```asm
[0x01b0bd8e] CMP dword ptr [EBX + 0x58],0x3  ; Check if mode == 3
[0x01b0bd92] JNZ LAB_01b0be3c                ; If not mode 3, skip

[Mode 3 path - ctx+0x58 == 3]
  [0x01b0bd98] MOV EDI,dword ptr [EBP + Stack[0x4]]  ; param_1
  [0x01b0bd9b] TEST EDI,EDI                          ; Check if NULL
  [0x01b0bd9d] JZ LAB_01b0be3c                       ; Skip if NULL

  ; Element iteration loop at 0x01b0bda3-0x01b0be3a
  ; Involves FUN_01b56ce0 and FUN_01b0f000
```

### ContentCode Read (ctx+0x58 == 0 only)

**CRITICAL: ContentCode is only read when ctx+0x58 == 0**

```asm
[0x01b0bf52] CMP dword ptr [EBX + 0x58],EDI  ; Check ctx+0x58
[0x01b0bf55] JZ LAB_01b0bf5c                 ; If == 0, check IsAtEnd
[0x01b0bf57] LEA EAX,[EDI + 0x1]             ; Otherwise ContentCode = 1
[0x01b0bf5a] JMP LAB_01b0bfaa                ; Skip read, use implicit 1

[LAB_01b0bf5c - ctx+0x58 == 0]
  MOV ECX,dword ptr [EBX + 0x4]   ; Get serializer
  MOV EDX,dword ptr [ECX]         ; Get vtable
  MOV EAX,dword ptr [EDX + 0x1c]  ; vtable+0x1c = IsAtEnd
  CALL EAX                        ; Check if at stream end
  TEST AL,AL
  JZ LAB_01b0bf6e                 ; If not at end, read ContentCode
  XOR EAX,EAX                     ; Otherwise ContentCode = 0
  JMP LAB_01b0bfaa

[LAB_01b0bf6e - Read ContentCode]
  PUSH s_ContentCode              ; "ContentCode"
  CALL [vtable+0x08]              ; BeginAttribute (NO-OP in binary)
  MOV EDX,[EDX + 0x98]            ; vtable+0x98 = ReadUInt8
  CALL EDX                        ; *** READS 1 BYTE ContentCode ***
  PUSH s_ContentCode              ; "ContentCode"
  CALL [vtable+0x10]              ; EndAttribute (NO-OP in binary)
```

### ContentCode Switch Table

```asm
[0x01b0bfaa] JMP dword ptr [EAX*0x4 + 0x1b0c2cc]

Jump table at 0x01b0c2cc:
  [0] 0x01B0BD57 → Early exit (set flags, call FUN_01b07350)
  [1] 0x01B0BE5F → Call FUN_01b07b90 (read count)
  [2] 0x01B0BFB1 → Read "Count" attribute, then "Values" section
  [3] 0x01B0C178 → Read "S" via vtable+0x84, then "Values" section
  [4] 0x01B0C1F3 → Read "count" attribute, iterate entries
```

### Key Findings

1. **ctx+0x58 == 3 (our binary file)**: ContentCode is implicitly 1, NOT read from stream
2. **ctx+0x58 == 0**: ContentCode IS read from stream via vtable+0x98 (1 byte)
3. **ContentCode == 1**: Calls FUN_01b07b90 to read count
4. **The 0x0b 0x01 prefix bytes**: NOT ContentCode - likely element type info or inline type descriptor

### Format for ctx+0x58 == 3 (Binary Mode)

```
Based on ContentCode=1 implicit path (LAB_01b0be5f):
  [0x00-0x??] Element type info (structure TBD)
  [0x??-0x??] Int32 entry_count (via FUN_01b07b90)
  [...]       Key/Value pairs (recursive)

The exact prefix bytes depend on element type descriptor passed to function.
```

### Outstanding Questions

1. What generates the 0x0b 0x01 prefix bytes?
2. How does FUN_01b07b90 read the count (does it have prefix reads)?
3. What is the element type descriptor structure at ESI+0x08/0x0C/0x0E?

---

## FUN_01b0c2e0 - Complete Decompiled Type Dispatcher (TRACED)

This is the COMPLETE decompiled code from Ghidra, extracted from the conversation transcript.

```c
void __thiscall FUN_01b0c2e0(int param_1, uint *param_2, uint *param_3, char param_4)
{
  // param_1 = serialization context
  // param_2 = property definition pointer
  // param_3 = type info struct (param_3[2] = type hash, param_3[3] = type info word)
  // param_4 = 0 for primary type, non-zero for element type (containers)

  local_28 = param_3[2];     // Type hash
  local_24 = param_3[3];     // Type info word

  // Select which 6-bit type code to use based on param_4
  if (param_4 == '\0') {
    iVar6 = 0x10;  // Primary type: bits 16-21
  } else {
    iVar6 = 0x17;  // Element type: bits 23-28 (for containers)
  }

  // Main type switch - extracts 6-bit type code
  switch(local_24 >> iVar6 & 0x3f) {
  case 0:   // NULL - reads 0 bytes
    FUN_01b09650(param_2, param_3);
    break;
  case 1:   // Bool - reads 1 byte
    FUN_01b12060(param_3, param_2);
    break;
  case 2:   // Int8 - reads 1 byte
    FUN_01b121e0(param_3, param_2);
    break;
  case 3:   // UInt8 - reads 1 byte
    FUN_01b12120(param_3, param_2);
    break;
  case 4:   // Int16 - reads 2 bytes
    FUN_01b12360(param_3, param_2);
    break;
  case 5:   // UInt16 - reads 2 bytes
    FUN_01b122a0(param_3, param_2);
    break;
  case 6:   // Int32 - reads 4 bytes
    FUN_01b12420(param_3, param_2);
    break;
  case 7:   // UInt32 - reads 4 bytes
    FUN_01b12fa0(param_3, param_2);
    break;
  case 8:   // Int64 - reads 8 bytes
    FUN_01b12590(param_3, param_2);
    break;
  case 9:   // UInt64 - reads 8 bytes
    FUN_01b124e0(param_3, param_2);
    break;
  case 10:  // Float32 - reads 4 bytes (0x0A)
    FUN_01b12640(param_3, param_2);
    break;
  case 0xb: // Float64 - reads 8 bytes
    FUN_01b126f0(param_3, param_2);
    break;
  case 0xc: // Vector2 - reads 12 bytes (PADDED)
    FUN_01b127a0(param_3, param_2);
    break;
  case 0xd: // Vector3 - reads 16 bytes (PADDED)
    FUN_01b12850(param_3, param_2);
    break;
  case 0xe: // Vector4 - reads 16 bytes
    FUN_01b12a60(param_3, param_2);
    break;
  case 0xf: // Matrix3x3 - reads 36 bytes
    FUN_01b12900(param_3, param_2);
    break;
  case 0x10: // Matrix4x4 - reads 64 bytes
    FUN_01b129b0(param_3, param_2);
    break;
  case 0x11: // String (StringID) - reads 4 bytes (hash)
    FUN_01b09880(param_2, param_3);
    break;
  case 0x12: // ObjectRef
  case 0x1e: // ObjectRef (alt) - same handler
    FUN_01b099a0(local_28, param_2, param_3);
    break;
  case 0x13: // ObjectRef (embedded)
    FUN_01b0a460(param_2, param_3);
    break;
  case 0x14: // Enum
    FUN_01b0b2c0(param_2, param_3);
    break;
  case 0x15: // Struct - uses +0x30 for size
    iVar6 = FUN_01aff5e0(local_28);
    uVar4 = 0;
    if (iVar6 != 0) {
      uVar4 = *(undefined4 *)(iVar6 + 0x30);
    }
    FUN_01b0b8a0(local_28, uVar4, param_2, puVar7);
    break;
  case 0x16: // Class - uses +0x30 for size
    iVar6 = FUN_01aff5e0(local_28);
    uVar4 = 0;
    if (iVar6 != 0) {
      uVar4 = *(undefined4 *)(iVar6 + 0x30);
    }
    FUN_01b0b710(local_28, uVar4, param_2, puVar7);
    break;

  case 0x17: // ARRAY - reads 4-byte count, then N elements recursively
    local_14 = 0;
    FUN_01b07be0(&local_14, param_3);  // Read count via BeginSection
    // ... array element handling with stride from FUN_01b60490(1) ...
    // Recursive loop:
    if (local_14 != 0) {
      do {
        FUN_01b0c2e0(puVar10, param_3, 1);  // Recurse with param_4=1
        puVar10 = puVar10 + element_stride;
        uVar5 = uVar5 + 1;
      } while (uVar5 < local_14);
    }
    (**(code **)(**(int **)(param_1 + 4) + 0x10))("Values");  // EndSection
    break;

  case 0x18: // MAP - reads 4-byte count, then N key/value pairs
  case 0x1d: // MAP_ALT - same handler as MAP
    local_34 = param_3[3];
    local_38 = *puVar10;
    local_1c = (local_34 >> 0x10 & 0x3f) != 0x18;  // Check if primary vs alt
    local_20 = param_2;
    param_2 = (uint *)FUN_01b0f000();
    cVar2 = FUN_01b0bcf0(&local_20, &param_2, puVar7);  // Read map count
    // ... map handling ...
    // Recursive loop for each key/value pair:
    if (param_2 != (uint *)0x0) {
      do {
        FUN_01b0c2e0(puVar10, param_3, 1);  // Key
        puVar7 = (uint *)((int)puVar7 + 1);
        puVar10 = puVar10 + 0xc;  // 48 bytes per entry (12 uint32s)
      } while (puVar7 < param_2);
    }
    (**(code **)(**(int **)(param_1 + 4) + 0x10))("Values");  // EndSection
    break;

  case 0x19: // BitField
    FUN_01b09c10(local_28, param_2, param_3);
    break;
  case 0x1a: // GUID - variable length ASCII string
    FUN_01b12cf0(param_3, param_2);
    break;
  case 0x1b: // Timestamp - variable length UTF-16 string
    FUN_01b13180(param_3, param_2);
    break;
  case 0x1c: // POINTER - recursive reference
    FUN_01b0ae60(local_28, param_2, param_3);
    break;
  }

  // End "Property" section in mode 0 (text mode only)
  if ((*(int *)(param_1 + 0x58) == 0) && (cStack0000000f != '\0')) {
    (**(code **)(**(int **)(param_1 + 4) + 0x14))("Property");
  }
  return;
}
```

### Complete Type Handler Function Table (TRACED - UPDATED January 2026)

**NOTE:** Binary analysis reveals fixed types have 1 trailing byte (0x00) after value.
The section_size includes this trailing byte. NULL type reads 2 bytes total.

| Case | Type Code | Handler | Bytes | Description |
|------|-----------|---------|-------|-------------|
| 0 | 0x00 | FUN_01b09650 → FUN_01b11fb0 | **2** | NULL - inner_type(1B) + null_value(1B) |
| 1 | 0x01 | FUN_01b12060 | 1+1 | Bool + trailing |
| 2 | 0x02 | FUN_01b121e0 | 1+1 | Int8 + trailing |
| 3 | 0x03 | FUN_01b12120 | 1+1 | UInt8 + trailing |
| 4 | 0x04 | FUN_01b12360 | 2+1 | Int16 + trailing |
| 5 | 0x05 | FUN_01b122a0 | 2+1 | UInt16 + trailing |
| 6 | 0x06 | FUN_01b12420 | 4+1 | Int32 + trailing |
| 7 | 0x07 | FUN_01b12fa0 | 4+1 | UInt32 + trailing |
| 8 | 0x08 | FUN_01b12590 | 8+1 | Int64 + trailing |
| 9 | 0x09 | FUN_01b124e0 | 8+1 | UInt64 + trailing |
| 10 | 0x0A | FUN_01b12640 | 4+1 | Float32 + trailing |
| 11 | 0x0B | FUN_01b126f0 | 8+1 | Float64 + trailing |
| 12 | 0x0C | FUN_01b127a0 | 12 | Vector2 (PADDED) |
| 13 | 0x0D | FUN_01b12850 | 16 | Vector3 (PADDED) |
| 14 | 0x0E | FUN_01b12a60 | 16 | Vector4 |
| 15 | 0x0F | FUN_01b12900 | 36 | Matrix3x3 |
| 16 | 0x10 | FUN_01b129b0 | 64 | Matrix4x4 |
| 17 | 0x11 | FUN_01b09880 | 4 | StringID (hash) |
| 18 | 0x12 | FUN_01b099a0 | var | ObjectRef |
| 19 | 0x13 | FUN_01b0a460 | var | ObjectRef (embedded) |
| 20 | 0x14 | FUN_01b0b2c0 | var | Enum |
| 21 | 0x15 | FUN_01b0b8a0 | var | Struct |
| 22 | 0x16 | FUN_01b0b710 | var | Class |
| 23 | 0x17 | FUN_01b07be0 | 4+N*elem | ARRAY |
| 24 | 0x18 | FUN_01b0bcf0 | 2+4+N*pair | MAP (2B prefix + 4B count) |
| 25 | 0x19 | FUN_01b09c10 | var | BitField |
| 26 | 0x1A | FUN_01b12cf0 | var | GUID (ASCII) |
| 27 | 0x1B | FUN_01b13180 | var | Timestamp (UTF-16) |
| 28 | 0x1C | FUN_01b0ae60 | var | POINTER |
| 29 | 0x1D | FUN_01b0bcf0 | 2+4+N*pair | MAP_ALT (2B prefix + 4B count) |
| 30 | 0x1E | FUN_01b099a0 | var | ObjectRef (alt) |

---

## FUN_01b077d0 - Property Header Reader (TRACED - CRITICAL)

This is the central property header reader. **CRITICAL: Mode-dependent behavior.**

### Assembly Trace

```asm
FUN_01b077d0:
01b077d6  MOV  EDI,ECX               ; this = context
01b077d8  CMP  [EDI+0x58],0x3        ; Check if mode == 3
01b077dc  JZ   LAB_01b07831          ; *** MODE 3 SKIPS TEXT MODE STUFF ***

; --- MODE != 3 (text/XML mode) ---
01b077de  MOV  ECX,[EDI+0x4]         ; Get serializer
01b077e3  MOV  EDX,[EAX+0x1c]        ; vtable+0x1c = IsAtEnd
01b077e6  CALL EDX                   ; Check if at end of stream
01b077e8  TEST AL,AL
01b077ea  JZ   LAB_01b077f6          ; If not at end, continue
01b077ef  XOR  AL,AL                 ; Return false (at end)
01b077f3  RET  0x10

LAB_01b077f6:                        ; Continue in text mode
01b077fb  MOV  EDX,[EAX+0xc]         ; vtable+0x0c = BeginSection
01b077fe  PUSH "Property"
01b07803  CALL EDX                   ; BeginSection("Property")
01b0780a  MOV  EDX,[EAX+0x8]         ; vtable+0x08 = BeginAttribute
01b0780d  PUSH "N"                   ; Property name attribute
01b07814  CALL EDX                   ; BeginAttribute("N")
01b0781b  MOV  EDX,[EAX+0x54]        ; vtable+0x54 = VarString
01b0781e  PUSH ECX
01b07821  CALL EDX                   ; Read property name (VarString)
01b07825  MOV  EDX,[EAX+0x10]        ; vtable+0x10 = EndAttribute
01b0782f  CALL EDX                   ; EndAttribute("N")

; --- BOTH MODES CONTINUE HERE (LAB_01b07831) ---
LAB_01b07831:
01b07831  MOV  ESI,[EDI+0x4]         ; Get serializer
01b07835  MOV  EBX,[EBP+Stack[0x4]]  ; param_1 = property ID pointer
01b07838  MOV  EAX,[EBX]             ; Get current value

; Read Property ID
01b0783f  MOV  EAX,[EDX+0x8]         ; vtable+0x08 = BeginAttribute (NO-OP in binary)
01b07842  PUSH "I"                   ; Property ID attribute
01b07849  CALL EAX                   ; BeginAttribute("I") - NO-OP in binary
01b0784d  MOV  EDX,[EDX+0x84]        ; vtable+0x84 = ReadUInt32
01b07853  LEA  EAX,[local_8]
01b07856  PUSH EAX
01b07859  CALL EDX                   ; *** READS 4 BYTES (Property ID) ***
01b0785d  MOV  EDX,[EAX+0x10]        ; vtable+0x10 = EndAttribute (NO-OP)
01b07867  CALL EDX                   ; EndAttribute("I") - NO-OP in binary

; Version compatibility check
01b07869  CMP  [EDI+0x24],0x2        ; Check version >= 2
01b0786d  JGE  LAB_01b0787c          ; Skip if version >= 2
01b0786f  CMP  [local_8],-0x1        ; Check if ID == -1 (0xFFFFFFFF)
01b07873  JNZ  LAB_01b0787c
01b07875  MOV  [local_8],0x0         ; Replace -1 with 0 for old versions

LAB_01b0787c:
01b0787f  MOV  EAX,[local_8]
01b07882  PUSH ECX                   ; Type descriptor output pointer
01b07885  MOV  [EBX],EAX             ; Store property ID to output
01b07887  CALL FUN_01b0e980          ; *** READS 8 BYTES (Type Descriptor) ***

; Mode check for property flags
01b0788c  CMP  [EDI+0x58],0x3        ; Check mode == 3 again
01b07890  JZ   LAB_01b07932          ; *** MODE 3 SKIPS PROPERTY FLAGS! ***

; --- MODE != 3 ONLY - property flags handling ---
01b07896  MOV  ESI,[EBP+Stack[0x10]] ; param_4 = flags pointer
; ... lots of bit manipulation for text mode flags ...
01b0791b  CALL FUN_01b076f0          ; Read PropertyHeaderFlag (1 byte in v>10)
01b07927  ... flag processing ...

; --- MODE 3 JUMPS HERE, SKIPPING FLAGS ---
LAB_01b07932:
01b07934  MOV  AL,0x1                ; Return true (success)
01b0793a  RET  0x10
```

### Key Discoveries

**MODE 3 (Binary) reads EXACTLY 12 BYTES for property header:**
1. Property ID: 4 bytes via vtable+0x84 (ReadUInt32)
2. Type Descriptor: 8 bytes via FUN_01b0e980
3. **NO PropertyHeaderFlag** - FUN_01b076f0 is SKIPPED (jump at 01b07890)

**MODE != 3 (Text/XML) reads additional data:**
1. BeginSection("Property") - opens section
2. Property name via VarString (vtable+0x54)
3. Property ID: 4 bytes
4. Type Descriptor: 8 bytes
5. PropertyHeaderFlag via FUN_01b076f0 (1 byte for version > 10)

### Binary Format Summary

| Mode | Property ID | Type Descriptor | Property Flags | Total Header |
|------|-------------|-----------------|----------------|--------------|
| Mode 3 (binary) | 4 bytes | 8 bytes | **SKIPPED** | 12 bytes |
| Mode != 3 (text) | 4 bytes | 8 bytes | 1-2 bytes | 13-14 bytes |

### Implications

1. **The "extra bytes" in our file are NOT from PropertyHeaderFlag**
2. FUN_01b076f0 is never called in mode 3 binary files
3. Property header structure is simpler in binary mode
4. Extra bytes must come from somewhere else in the serialization chain

---

## FUN_01b076f0 - PropertyHeaderFlag Reader (TRACED - COMPLETE)

**NOTE: This function is ONLY called in mode != 3 (text/XML mode). SKIPPED in mode 3 (binary).**

### Assembly Trace (COMPLETE)

```asm
FUN_01b076f0:
01b076f7  CMP  [EBX+0x24],0xb        ; Check version >= 11
01b076fc  JL   LAB_01b07735          ; If version < 11, use old format

; --- VERSION >= 11: Single byte format ---
01b07706  PUSH "PropertyHeaderFlag"
01b0770d  CALL [vtable+0x08]         ; BeginAttribute (NO-OP in binary)
01b07714  MOV  EDX,[EAX+0x98]        ; vtable+0x98 = ReadUInt8
01b0771d  CALL EDX                   ; *** READS 1 BYTE ***
01b07724  PUSH "PropertyHeaderFlag"
01b0772b  CALL [vtable+0x10]         ; EndAttribute (NO-OP)
01b07732  RET

; --- VERSION < 11: Two bool format ---
LAB_01b07735:
01b07749  PUSH "Final"
01b07750  CALL [vtable+0x08]         ; BeginAttribute
01b07754  MOV  EDX,[EDX+0x58]        ; vtable+0x58 = ReadBool
01b0775d  CALL EDX                   ; *** READS 1 BYTE (Final) ***
01b07764  PUSH "Final"
01b0776b  CALL [vtable+0x10]         ; EndAttribute
01b07773  PUSH "Owned"
01b0778f  CALL [vtable+0x08]         ; BeginAttribute
01b07796  CALL [vtable+0x58]         ; *** READS 1 BYTE (Owned) ***
01b077a3  PUSH "Owned"
01b077aa  CALL [vtable+0x10]         ; EndAttribute
```

### Decompiled Code

```c
void __thiscall FUN_01b076f0(int param_1, byte *param_2)
{
  int *piVar1;
  byte *pbVar2;
  undefined4 uStack_8;

  pbVar2 = param_2;
  uStack_8 = param_1;

  if (10 < *(int *)(param_1 + 0x24)) {
    // Version > 10: Single byte flags via vtable+0x98 (ReadUInt8)
    piVar1 = *(int **)(param_1 + 4);
    (**(code **)(*piVar1 + 8))("PropertyHeaderFlag");   // BeginAttribute
    (**(code **)(*piVar1 + 0x98))(param_2);             // Read 1 byte UInt8
    (**(code **)(*piVar1 + 0x10))("PropertyHeaderFlag"); // EndAttribute
    return;
  }

  // Version <= 10: Two separate Bool fields
  piVar1 = *(int **)(param_1 + 4);
  param_2 = (byte *)(CONCAT13(*param_2, param_2._0_3_) & 0x1ffffff);
  (**(code **)(*piVar1 + 8))("Final");
  (**(code **)(*piVar1 + 0x58))((int)&param_2 + 3);  // Read Bool
  (**(code **)(*piVar1 + 0x10))("Final");
  *pbVar2 = *pbVar2 ^ (*pbVar2 ^ param_2._3_1_) & 1;

  piVar1 = *(int **)(param_1 + 4);
  uStack_8 = CONCAT13(*pbVar2 >> 1, (undefined3)uStack_8) & 0x1ffffff;
  (**(code **)(*piVar1 + 8))("Owned");
  (**(code **)(*piVar1 + 0x58))((int)&uStack_8 + 3);  // Read Bool
  (**(code **)(*piVar1 + 0x10))("Owned");
  *pbVar2 = *pbVar2 ^ (uStack_8._3_1_ * '\x02' ^ *pbVar2) & 2;
  return;
}
```

### Key Findings

1. **Version >= 11**: Reads 1 byte via vtable+0x98 (UInt8)
2. **Version < 11**: Reads 2 bytes via vtable+0x58 (two Bools: "Final" and "Owned")
3. **Mode 3 (binary)**: This function is **SKIPPED entirely** by FUN_01b077d0!

### Version-Dependent Format

| Version | Format | Bytes Read | vtable |
|---------|--------|------------|--------|
| >= 11 | Single UInt8 | 1 byte | vtable+0x98 |
| < 11 | Two Bools | 2 bytes | vtable+0x58 |

**Summary:**
- Version > 10 (our file uses v16): Reads 1 byte UInt8 via vtable+0x98
- Version <= 10: Reads 2 Bool fields ("Final" and "Owned") via vtable+0x58
- **BUT in mode 3, this function is SKIPPED entirely by FUN_01b077d0!**

---

## FUN_01b0e980 - TypeDescriptor Reader (8 bytes) (TRACED)

This function reads an 8-byte type descriptor via vtable+0x4c.

### Assembly Trace

```asm
FUN_01b0e980:
01b0e986  CMP  [ECX+0x24],0x9        ; Check version >= 9
01b0e98b  MOV  ESI,[ECX+0x4]         ; Get serializer
01b0e990  JGE  LAB_01b0e9ea          ; If version >= 9, use new format

; --- VERSION < 9: Old format ---
01b0e997  PUSH "T"                   ; "Type" attribute (DAT_02554cb0)
01b0e99c  CALL [vtable+0x08]         ; BeginAttribute
01b0e9a0  MOV  EDX,[EAX+0x4c]        ; vtable+0x4c = TypeDescriptor reader
01b0e9a6  PUSH local_c               ; result pointer
01b0e9a7  PUSH DAT_025f9b50          ; type template
01b0e9ae  CALL EDX                   ; Read type descriptor
01b0e9b5  PUSH "T"
01b0e9bc  CALL [vtable+0x10]         ; EndAttribute
; ... copy 8 bytes to output via FUN_01b0e3d0 ...

; --- VERSION >= 9: New format (binary) ---
LAB_01b0e9ea:
01b0e9fe  PUSH "T"                   ; "Type" attribute (DAT_02554cb0)
01b0ea03  CALL [vtable+0x08]         ; BeginAttribute (NO-OP in binary)
01b0ea07  MOV  EDX,[EDX+0x4c]        ; vtable+0x4c = TypeDescriptor reader
01b0ea0a  LEA  EAX,[local_c]
01b0ea0d  PUSH EAX
01b0ea0e  PUSH DAT_025f9b50
01b0ea15  CALL EDX                   ; *** READS 8 BYTES ***
01b0ea1c  PUSH "T"
01b0ea23  CALL [vtable+0x10]         ; EndAttribute (NO-OP)
01b0ea25  MOV  EAX,[local_c]         ; Get first 4 bytes
01b0ea28  MOV  ECX,[local_8]         ; Get second 4 bytes
01b0ea2b  MOV  [EDI],EAX             ; Store to output[0]
01b0ea2d  MOV  [EDI+0x4],ECX         ; Store to output[4]
```

### Key Finding

**Reads exactly 8 bytes via vtable+0x4c (TypeDescriptor reader).** The output is two 4-byte values stored at output[0] and output[4].

### Binary Format

```
TypeDescriptor (8 bytes):
  [0x00-0x03] UInt32 type_hash     ← First 4 bytes (output[0])
  [0x04-0x07] UInt32 type_info     ← Second 4 bytes (output[4])

Type code extraction: (type_info >> 16) & 0x3F
```

### Version-Dependent Behavior

| Version | Format | Bytes Read | vtable |
|---------|--------|------------|--------|
| >= 9 | Direct read | 8 bytes | vtable+0x4c |
| < 9 | Wrapped read | 8 bytes | vtable+0x4c |

### String Constant

- DAT_02554cb0 = "Type" (attribute name "T")

---

## FUN_01b0e3d0 - Type Mask Helper (NO STREAM I/O) (TRACED)

This function extracts type information fields from an existing type descriptor. It does NO stream I/O.

### Assembly Trace

```asm
FUN_01b0e3d0:
; Pure bit manipulation - extracts type info fields:
01b0e3e8  AND  EDX,0x3f0000          ; Extract bits 16-21 (type code)
01b0e400  AND  EDX,0x400000          ; Extract bit 22
01b0e412  AND  EDX,0x60000000        ; Extract bits 29-30
01b0e424  AND  EDX,0x7fff            ; Extract bits 0-14
01b0e43a  AND  ECX,0x1f800000        ; Extract bits 23-28
; NO stream calls - just processes existing data
```

### Key Finding

**This function does NO stream I/O** - it just masks and extracts type info fields from existing data in memory.

### Bit Field Layout (type_info word)

| Bits | Mask | Description |
|------|------|-------------|
| 0-14 | 0x7FFF | Unknown field |
| 16-21 | 0x3F0000 | Type code (6 bits) |
| 22 | 0x400000 | Unknown flag |
| 23-28 | 0x1F800000 | Element type (containers) |
| 29-30 | 0x60000000 | Unknown flags |

### Usage

Called by FUN_01b0e980 to copy and process type descriptor data after reading from stream.

---

### PropertyHeaderFlag Reader - FUN_01b076f0

```c
// Version-dependent property header flags
// Located at: context+0x24 contains version number

if (version > 10) {
    // Version > 10: Single byte flags
    Bytes Read: 1
    Format: [0x00] UInt8 flags  ← vtable+0x98 (ReadUInt8)

    Bit layout (inferred):
      bit 0-3: Unknown
      bit 4:   Final flag (shifted from old format)
      bit 5:   Owned flag (shifted from old format)
      bit 6-7: Reserved
}
else {
    // Version <= 10: Two separate bool fields
    Bytes Read: 2
    Format:
      [0x00] Bool "Final"   ← vtable+0x58 (ReadBool)
      [0x01] Bool "Owned"   ← vtable+0x58 (ReadBool)
}
```

**Note:** The current file uses version 16 (ctx+0x24 = 16), so the
single-byte UInt8 format applies. Property header flags are read
as 1 byte per property.

### Binary Mode Behavior

| Function | Binary Mode (1,2,3) | Source |
|----------|---------------------|--------|
| BeginAttribute | **NO-OP** (RET 0x4) | LAB_01b48770 |
| EndAttribute | **NO-OP** | LAB_01b487a0 |
| BeginSection | **Reads EXACTLY 4 bytes** (section size via stream+0x1c) | FUN_01b48890 |
| Object Header | **SKIPPED** entirely | FUN_01b08ce0 |
| FUN_01b0d0c0 | **NO-OP** when +0x6c==0 | FUN_01b0d0c0 |

---

## Verified Binary Layout

### Header (0x00-0x19)

| Offset | Size | Value | Source | Description |
|--------|------|-------|--------|-------------|
| 0x00 | 1 | 0x00 | FUN_01b08ce0 | NbClassVersionsInfo |
| 0x01 | 4 | 0x00000000 | FUN_01b08ce0 | ObjectName (VarString, empty) |
| 0x05 | 4 | 0x00000000 | FUN_01b08ce0 | ObjectID (StringID=0) |
| 0x09 | 1 | 0x00 | FUN_01b08ce0 | InstancingMode |
| 0x0A | 4 | 0xB4B55039 | FUN_01712330 | Type Hash |
| 0x0E | 4 | 1885 | FUN_01b0a1f0 | SaveGameDataObject.field_0x04 |
| 0x12 | 4 | 1877 | BeginSection | Content size (bytes to EOF) |
| 0x16 | 4 | 17 | FUN_01b091a0 | NbDynamicProperties |

### Entry Markers (0xF95FCFA8)

| # | Offset | Gap | Notes |
|---|--------|-----|-------|
| 1 | 0x0049 | - | Short entry (24 bytes) |
| 2 | 0x0061 | 24B | Entry 0 start |
| 3-18 | 0x00B6+ | 85B | Entries 1-16 (85 bytes each) |

### Layout Summary (FULLY DECODED - January 2026)

```
0x00-0x0D   14 bytes   Object header (TRACED)
0x0E-0x11    4 bytes   field_0x04 = 1885 (TRACED)
0x12-0x15    4 bytes   content_size = 1877 (TRACED)
0x16-...    variable   15 Dynamic Properties (decoded below)

Property Format (each):
  [4B] section_size    ← BeginSection reads this
  [4B] prop_id         ← Property ID hash
  [4B] type_hash       ← Type definition hash
  [4B] type_info       ← bits 16-21: type_code, bits 23-28: element_type
  [var] value          ← Depends on type_code

Value Formats by Type:
  NULL (0x00):    [1B inner_type] [1B null_value]
  Fixed types:    [value bytes] [1B trailing 0x00]
  MAP (0x18):     [1B marker=0x0B] [1B flag=0x01] [4B count] [entries...]
  CLASS (0x16):   85-byte nested objects (see CLASS Entry Structure below)

CLASS Entry Structure (85 bytes each):
  [10B] key             ← Usually zeros
  [4B]  type_hash       ← 0xF95FCFA8 (nested object type)
  [4B]  content_size    ← Size of nested content
  [4B]  prop_size       ← Size of properties data
  [var] properties      ← Nested properties with format:
        [4B] section_size + [4B] prop_id + [4B] type_hash + [4B] type_info + [var] value
  [pad] trailing zeros  ← Pad to 85 bytes
```

---

## Condensed Function Reference

### Entry Points

| Function | Purpose | Writes | Binary Mode |
|----------|---------|--------|-------------|
| FUN_01afd600 | Section 4 entry | None | Active |
| FUN_01b0a740 | Object deserializer | None | Skips header |
| FUN_01712330 | AssassinMultiProfileData | None | Active |
| FUN_005e3700 | SaveGameDataObject | field+0x04 | Active |

### Property Serialization

| Function | Purpose | Reads | Notes |
|----------|---------|-------|-------|
| FUN_01b091a0 | Dynamic properties | Count + properties | CRITICAL |
| FUN_01b077d0 | Property header | **12 bytes (mode 3)** | ID(4) + TypeDesc(8), flags SKIPPED |
| FUN_01b076f0 | Property flags | 1B (v>=11) or 2B (v<11) | **SKIPPED in mode 3!** |
| FUN_01b0e980 | Type descriptor | 8 bytes | via vtable+0x4c |
| FUN_01b0e3d0 | Type mask helper | **0 bytes** | Extracts type fields (no I/O) |
| FUN_01b0e7e0 | Flag processing | **0 bytes** | Bit manipulation (no I/O) |
| FUN_01b0c2e0 | Type dispatch | Variable | 31-way switch |
| FUN_01b07940 | Validation | **None** | Pure validation gate |

### Complex Type Handlers

| Function | Type Code | Purpose | Reads |
|----------|-----------|---------|-------|
| FUN_01b09650 → FUN_01b11fb0 | 0x00 | NULL | 1 byte (vtable+0x58, normalized to 0/1) |
| FUN_01b07be0 | 0x17 | ARRAY setup | Mode 3: 0 bytes (count from caller); Other: 4 bytes |
| FUN_01b0bcf0 | 0x18/0x1D | MAP prefix+count | 2+4 bytes (prefix + Int32) |
| FUN_01b0ae60 | 0x1C | POINTER | Variable (recursive) |

### Stream Operations

| Function | vtable | Size | Notes |
|----------|--------|------|-------|
| FUN_01b6f440 | Stream+0x1c | 4B | Read4Bytes, little-endian |
| FUN_01b49610 | +0x84 | 4B | Int32/UInt32 |
| FUN_01b48c10 | +0x70 | 8B | Float64 (2x Read4) |
| FUN_01b49730 | +0x78 | 8B | Int64 (native 8-byte) |
| FUN_01b48c80 | +0x6C | 12B | Vector2 (padded) |
| FUN_01b48cf0 | +0x68 | 16B | Vector3 (padded) |
| FUN_01b48e90 | +0x54 | var | VarString |
| FUN_01b48890 | +0x0C | 4B | BeginSection (reads count) |
| LAB_01b48770 | +0x08 | 0 | BeginAttribute (NO-OP) |

---

## Type Size Table (All Traced)

| Code | Type | Size | vtable | Stream |
|------|------|------|--------|--------|
| 0x01 | Bool | 1B | +0x90 | +0x24 |
| 0x02 | Int8 | 1B | +0x94 | +0x24 |
| 0x03 | UInt8 | 1B | +0x98 | +0x24 |
| 0x04 | Int16 | 2B | +0x88 | +0x20 |
| 0x05 | UInt16 | 2B | +0x8C | +0x20 |
| 0x06 | Int32 | 4B | +0x80 | +0x1c |
| 0x07 | UInt32 | 4B | +0x84 | +0x1c |
| 0x08 | Int64 | 8B | +0x78 | +0x18 |
| 0x09 | UInt64 | 8B | +0x7C | +0x18 |
| 0x0A | Float32 | 4B | +0x74 | +0x1c |
| 0x0B | Float64 | 8B | +0x70 | 2x+0x1c |
| 0x0C | Vector2 | **12B** | +0x6C | 3x+0x1c |
| 0x0D | Vector3 | **16B** | +0x68 | 4x+0x1c |
| 0x0E | Vector4 | 16B | +0x5C | 4x+0x1c |
| 0x0F | Matrix3x3 | 36B | +0x64 | col-major |
| 0x10 | Matrix4x4 | 64B | +0x60 | col-major |
| 0x11 | StringID | 4B | +0x9C | +0x1c |
| 0x1A | GUID | var | +0x48 | ASCII |
| 0x1B | Timestamp | var | +0x44 | UTF-16 |

**Note:** Vector2/Vector3 are PADDED for SIMD alignment. Matrices are column-major.

---

## Verification Status

### Fully Traced

- All 24 primitive type sizes and handlers
- Context → BinarySerializer → Stream chain
- Object header format (14 bytes)
- FUN_01b48890 BeginSection (vtable+0x0C) - reads EXACTLY 4 bytes, depth tracking
- BeginAttribute is NO-OP in binary mode
- FUN_01b07940 is pure validation (no I/O)
- FUN_01b12fa0 UInt32 handler (reads exactly 4 bytes, no extras)
- FUN_01b0d490 Attribute Int32 reader (BeginAttr→4 bytes→EndAttr, no extras)
- Hash 0xB4B55039 = "AssassinMultiProfileData"
- Hash 0xB7806F86 = "SaveGameDataObject"
- **FUN_01b077d0 property header reader (mode 3: exactly 12 bytes, flags SKIPPED)**
- FUN_01b076f0 property flags (1B for version >= 11, 2B for version < 11) - **SKIPPED in mode 3!**
- FUN_01b11fb0 NULL type (reads 1 byte via vtable+0x58, normalized to 0/1)
- FUN_01b07be0 ARRAY setup (mode 3: does NOT read count, skips to BeginAttribute)
- FUN_01b0bcf0 MAP/MAP_ALT count reader (4 bytes)
- FUN_01b0ae60 POINTER type (recursive)
- FUN_01b42160 Iterator setup (does NOT read from stream, copies type descriptor)
- FUN_01b084a0 Cleanup/destructor (does NOT write to stream, pure cleanup)
- FUN_01b41f00 Trivial setter (just MOV [ECX+0x10], EAX; RET - no I/O)
- BinarySerializer depth tracking mechanism (serializer+0x1010)
- **FUN_01b0e7e0 Flag processing (NO stream I/O - pure bit manipulation)**
- **FUN_01b0e980 TypeDescriptor reader (8 bytes via vtable+0x4c)**
- **FUN_01b0e3d0 Type mask helper (NO stream I/O - extracts type info fields)**

### Binary Analysis Confirmed (January 2026)

| Item | Status | Notes |
|------|--------|-------|
| NULL type = 2 bytes | CONFIRMED | inner_type (1B) + null_value (1B) |
| Fixed types trailing byte | CONFIRMED | All fixed types have trailing 0x00 |
| MAP prefix = 0x0B 0x01 | CONFIRMED | Marker + flag before count |
| element_type from bits 23-28 | CONFIRMED | Used for MAP entry parsing |
| 85-byte CLASS entries | DECODED | key(10) + type_hash(4) + sizes(8) + props + pad |
| Roundtrip serialization | **100% PASS** | SHA256 verified byte-identical |

### Disproven Hypotheses

| Hypothesis | Status | Reason |
|------------|--------|--------|
| Value 11 = array count | **FALSE** | Type 7 only reads 4 bytes |
| NULL reads 1 byte | **FALSE** | Actually reads 2 bytes (inner_type + null_value) |
| Fixed types have no suffix | **FALSE** | All have trailing 0x00 byte |

---

## ~~Critical Gap: Format Mismatch~~ RESOLVED (January 2026)

**SOLVED:** The format mismatch was caused by incorrect understanding of value formats.

### Root Causes Found

1. **NULL type reads 2 bytes**, not 1:
   - Byte 1: inner_type (the wrapped type code, e.g., 0x0B = FLOAT64)
   - Byte 2: null_value (0 = absent, 1 = present)

2. **Fixed types have trailing 0x00 byte**:
   - UINT32: 4 bytes value + 1 byte trailing = 5 bytes total
   - UINT64: 8 bytes value + 1 byte trailing = 9 bytes total
   - This is consistent with section_size values in the binary

3. **MAP format includes prefix bytes**:
   - [1B marker = 0x0B] [1B flag = 0x01] [4B count] [entries...]
   - element_type from type_info bits 23-28 determines entry format

4. **CLASS (0x16) entries are 85-byte nested objects**:
   - [10B key] [4B type_hash] [4B content_size] [4B prop_size] [nested_props] [padding]
   - Nested properties use same format: section_size + prop_id + type_hash + type_info + value

### Resolution

Parser and serializer now correctly handle all formats. **100% roundtrip verified.**

---

## Solved (January 2026)

1. **Internal 85-byte entry structure** - DECODED: key(10B) + type_hash(4B) + content_size(4B) + prop_size(4B) + nested_props + padding
2. **Source of "extra bytes"** - SOLVED:
   - NULL type reads 2 bytes (inner_type + null_value), not 1
   - Fixed types (UINT32, UINT64, etc.) have trailing 0x00 byte
3. **MAP 0x0b 0x01 prefix bytes** - SOLVED: marker(0x0B) + flag(0x01) before count, element_type from type_info bits 23-28
4. **Roundtrip serialization** - ACHIEVED: 100% byte-identical output verified by SHA256

## Still Unknown

1. **What sets ctx+0x58 to enable binary mode (1/2/3)?** - Entry point initialization
2. **0xF95FCFA8 type hash** - What class/struct does this hash represent?
3. **Some nested property type hashes** - Need traced string references

---

## Outstanding Work

1. ~~Trace the code path that produces 85-byte entries~~ DONE
2. ~~Decode internal entry field structure~~ DONE (85-byte CLASS entries fully decoded)
3. ~~Understand the pre-entries data (0x1A-0x48)~~ DONE (first properties before MAP)
4. ~~Determine actual serialization mode used~~ DONE (mode 3 binary confirmed)
5. ~~Rewrite parser using only traced code (remove marker-based hacks)~~ DONE (roundtrip passes)

**COMPLETED:** Full parser and serializer with 100% roundtrip verification

---

## Known String Constants (Traced)

| Address | String | Used By | Purpose |
|---------|--------|---------|---------|
| DAT_02554cbc | "Name" | Property headers | Property name attribute (text mode) |
| DAT_02554cb0 | "Type" / "T" | FUN_01b0e980 | Type descriptor attribute |
| "PropertyHeaderFlag" | - | FUN_01b076f0 | Property header flags (v>=11) |
| "Final" | - | FUN_01b076f0 | Property final flag (v<11) |
| "Owned" | - | FUN_01b076f0 | Property owned flag (v<11) |
| "Property" | - | FUN_01b077d0 | Property section name (text mode) |
| "I" | - | FUN_01b077d0 | Property ID attribute |
| "N" | - | FUN_01b077d0 | Property name attribute |
| "Values" | - | FUN_01b07be0 | Array/Map values section |
| "ContentCode" | - | FUN_01b0bcf0 | Map content code attribute |
| "Count" | - | FUN_01b0bcf0 | Map count attribute |
| "S" | - | FUN_01b0bcf0 | Map count (alternate) |

---

## Known Hash Values

| Hash | String | Verified |
|------|--------|----------|
| 0xB4B55039 | "AssassinMultiProfileData" | FUN_01712330 |
| 0xB7806F86 | "SaveGameDataObject" | FUN_005e3700 |
| 0xBF4C2013 | Field descriptor hash | DAT_027ecf90 |
| 0xF95FCFA8 | **UNKNOWN** (data value) | Not a hash |
| 0x8157B2C0 | **UNKNOWN** | No reference |
| 0xE717D13B | **UNKNOWN** | No reference |
| 0xD0E64300 | **UNKNOWN** | No reference |

---

## Serialization Context Structure

| Offset | Size | Description | Source |
|--------|------|-------------|--------|
| +0x04 | 4 | BinarySerializer ptr | FUN_01b08a50 |
| +0x1c | 4 | Current object | Multiple |
| +0x20 | 4 | Saved field | FUN_01712330 |
| +0x24 | 4 | Version (=16) | FUN_01b08a50 |
| +0x28 | 4 | DynamicProps ptr | FUN_01b09620 (stored when ctx+0x58 != 3) |
| +0x2c | 4 | Validation field | FUN_01b07940 |
| +0x4e | 1 | State flags | FUN_01b08a50 |
| +0x58 | 4 | Mode (1/2/3) | Multiple |
| +0x6c | 4 | Binary path flag | FUN_01b0d0c0 |
| +0x79 | 1 | Reference mode | FUN_01b07940 |
| +0x7a | 1 | Non-ref mode | FUN_01b07940 |

---

## BinarySerializer Structure (TRACED from FUN_01b48890)

The BinarySerializer maintains a section depth stack for nested section tracking.

| Offset | Size | Description | Source |
|--------|------|-------------|--------|
| +0x04 | 1 | Mode flag (0=text, non-zero=binary) | FUN_01b48890 |
| +0x08 | 4 | Stream object pointer | FUN_01b48890 |
| +0x08 to +0x100F | var | Section depth array (512 depth slots max) | FUN_01b48890 |
| +0x1010 | 2 | Section depth counter (uint16) | FUN_01b48890 |

### Section Depth Array Layout

For each nesting depth level (indexed by depth*8):

| Offset Formula | Size | Description | Source |
|----------------|------|-------------|--------|
| depth*8 + 0x08 | 4 | Remaining bytes for this section level | FUN_01b48890 |
| depth*8 + 0x10 | 4 | Section size (stored in binary mode) | FUN_01b48890 |
| depth*8 + 0x14 | 4 | Text mode position marker | FUN_01b48890 |

### Depth Tracking Example

```
BeginSection("Level0") → depth=0, stores size at +0x10
  BeginSection("Level1") → depth=1, stores size at +0x18, subtracts from +0x08
    BeginSection("Level2") → depth=2, stores size at +0x20, subtracts from +0x10
    EndSection() → depth decremented to 1
  EndSection() → depth decremented to 0
EndSection() → depth decremented to -1 (root)
```

---

## BinarySerializer vtable (PTR_FUN_02555c60)

| Offset | Function | Purpose |
|--------|----------|---------|
| +0x00 | FUN_01b49b10 | Destructor |
| +0x08 | LAB_01b48770 | BeginAttribute (NO-OP) |
| +0x0C | FUN_01b48890 | BeginSection (reads exactly 4 bytes in binary mode) |
| +0x10 | LAB_01b487a0 | EndAttribute (NO-OP) |
| +0x1C | LAB_01b48a10 | IsAtEnd |
| +0x44 | FUN_01b49300 | WideString |
| +0x48 | FUN_01b492f0 | NarrowString |
| +0x4C | FUN_01b49020 | TypeDescriptor |
| +0x54 | FUN_01b48e90 | VarString |
| +0x5C | FUN_01b48e00 | Vector4 |
| +0x60 | FUN_01b48d60 | Matrix4x4 |
| +0x64 | FUN_01b49140 | Matrix3x3 |
| +0x68 | FUN_01b48cf0 | Vector3 |
| +0x6C | FUN_01b48c80 | Vector2 |
| +0x70 | FUN_01b48c10 | Float64 |
| +0x74 | FUN_01b48c00 | Float32 |
| +0x78 | FUN_01b48bf0 | Int64 |
| +0x7C | FUN_01b48be0 | UInt64 |
| +0x80 | FUN_01b48bd0 | Int32 |
| +0x84 | FUN_01b48bc0 | UInt32 |
| +0x88 | FUN_01b48bb0 | Int16 |
| +0x8C | FUN_01b48ba0 | UInt16 |
| +0x90 | FUN_01b48b90 | Bool |
| +0x94 | FUN_01b48b80 | Int8 |
| +0x98 | FUN_01b48b70 | UInt8 |
| +0x9C | FUN_01b48e70 | StringID |

---

## Stream vtable (PTR_FUN_02556168)

| Offset | Size | Read | Write |
|--------|------|------|-------|
| +0x18 | 8B | Read8 | - |
| +0x1c | 4B | Read4 | - |
| +0x20 | 2B | Read2 | - |
| +0x24 | 1B | Read1 | - |
| +0x28 | var | ReadBuf | - |
| +0x30 | 8B | - | Write8 |
| +0x34 | 4B | - | Write4 |
| +0x38 | 2B | - | Write2 |
| +0x3c | 1B | - | Write1 |
| +0x40 | var | - | WriteBuf |

---

## Changelog

- **January 2026**: TRACED FUN_01b077d0 - Property header reader mode-dependent behavior
  - Mode 3 (binary): reads EXACTLY 12 bytes (4B ID + 8B TypeDesc), PropertyHeaderFlag SKIPPED
  - Mode != 3 (text): reads property name, ID, type desc, AND flags
  - KEY FINDING: Extra bytes are NOT from property header flags in mode 3!
- **January 2026**: TRACED FUN_01b48890 - BeginSection (vtable+0x0C) reads EXACTLY 4 bytes in binary mode
- **January 2026**: Documented BinarySerializer depth tracking mechanism (serializer+0x1010, depth*8 indexed array)
- **January 2026**: KEY FINDING: BeginSection has no extra bytes - look for them in property structure
- **January 2026**: TRACED FUN_01b11fb0 - NULL type reads 1 byte (NOT 0 bytes), normalized to 0/1
- **January 2026**: TRACED FUN_01b42160 - Iterator setup does NOT read from stream (memory copy only)
- **January 2026**: TRACED FUN_01b084a0 - Cleanup/destructor does NOT write to stream
- **January 2026**: TRACED FUN_01b07be0 - ARRAY in mode 3 does NOT read count (passed from caller)
- **January 2026**: TRACED FUN_01b0d490 - Attribute Int32 reads exactly 4 bytes, no extras
- **January 2026**: TRACED FUN_01b12fa0 - UInt32 handler reads exactly 4 bytes, no extras
- **January 2026**: TRACED FUN_01b41f00 - Trivial setter (no I/O)
- **January 2026**: KEY FINDING: Extra bytes come from property structure, NOT type handlers
- **January 2026**: Added COMPLETE FUN_01b0bcf0 assembly trace (MAP/MAP_ALT handler)
- **January 2026**: Discovered ContentCode is NOT read in ctx+0x58==3 mode (implicit value 1)
- **January 2026**: Documented 0x0b 0x01 prefix bytes are element type info, not ContentCode
- **January 2026**: Updated section4_parser.py to read 2 prefix bytes before MAP count
- **January 2026**: Added COMPLETE decompiled FUN_01b0c2e0 (type dispatcher) with all 31 cases
- **January 2026**: Added COMPLETE decompiled FUN_01b076f0 (property header flag reader)
- **January 2026**: Added complete type handler function table with all handlers and byte sizes
- **January 2026**: Updated section4_parser.py with traced ARRAY (case 0x17) handling
- **January 2026**: Updated section4_parser.py with traced MAP/MAP_ALT (cases 0x18/0x1D) handling
- **January 2026**: Updated section4_parser.py with traced GUID (case 0x1A) and TIMESTAMP (case 0x1B)
- **January 2026**: Added complex type handler documentation (NULL, ARRAY, MAP, POINTER)
- **January 2026**: Documented FUN_01b076f0 PropertyHeaderFlag reader (version-dependent 1B or 2B)
- **January 2026**: Traced FUN_01b09650 (NULL type, 0 bytes), FUN_01b07be0 (ARRAY count, 4B)
- **January 2026**: Traced FUN_01b0bcf0 (MAP/MAP_ALT count, 4B), FUN_01b0ae60 (POINTER, recursive)
- **January 2026**: Major refactor - condensed code dumps to summaries, added verification audit
- **January 2026**: Traced FUN_01b07940 (validation only, no I/O)
- **January 2026**: Confirmed 1877 = BeginSection content size
- **January 2026**: Disproved value 11 array hypothesis
- **January 2026**: Complete type size table verified
- **January 2026**: All BinarySerializer vtable entries traced
- **January 2026**: TRACED FUN_01b0e7e0 - Flag processing (NO stream I/O, pure bit manipulation)
- **January 2026**: TRACED FUN_01b076f0 - Complete assembly trace with version-dependent behavior:
  - Version >= 11: reads 1 byte via vtable+0x98 (UInt8)
  - Version < 11: reads 2 bytes via vtable+0x58 (two Bools: "Final" and "Owned")
  - **Mode 3: SKIPPED entirely by FUN_01b077d0**
- **January 2026**: TRACED FUN_01b0e980 - TypeDescriptor reader (8 bytes via vtable+0x4c)
  - Output: two 4-byte values (type_hash, type_info)
  - Type code extraction: (type_info >> 16) & 0x3F
- **January 2026**: TRACED FUN_01b0e3d0 - Type mask helper (NO stream I/O)
  - Extracts type info fields using bit masks
  - Bits 16-21: type code, Bits 23-28: element type
- **January 2026**: Added Known String Constants section (Name, Type, PropertyHeaderFlag, etc.)
- **January 2026**: Documented DAT_02554cbc = "Name", DAT_02554cb0 = "Type"
- **January 2026**: Parser test run - 15 properties parsed, 4 bytes remaining
- **January 2026**: Added FUN_01b091a0 READ path analysis (IsAtEnd loop, not count-based)

---

## FUN_01b091a0 - Dynamic Properties Serializer (TRACED from Assembly)

### Key Discoveries from Assembly Analysis

**CRITICAL BIFURCATION at 0x01b09219:**
```asm
01b09212  MOV  ECX,dword ptr [EBX + 0x4]     ; Get serializer
01b09215  CMP  byte ptr [ECX + 0x4],0x0      ; Check serializer+0x04 (mode flag)
01b09219  JNZ  LAB_01b094d8                  ; If non-zero (READ), jump to READ path
```

This shows the function has TWO completely different paths:
- **WRITE path** (serializer+0x04 == 0): Uses property list iteration with count
- **READ path** (serializer+0x04 != 0): Uses IsAtEnd loop (no count read)

### WRITE Path (serializer+0x04 == 0)

The WRITE path at 0x01b09321:
```asm
01b09321  CMP  [EBX + 0x58],0x3              ; Check mode == 3
01b09325  JNZ  LAB_01b09356                  ; Skip if not mode 3
01b09327  MOV  ESI,[EBX + 0x4]               ; Get serializer
01b0932f  PUSH s_NbDynamicProperties         ; "NbDynamicProperties"
01b09336  CALL [vtable+0x08]                 ; BeginAttribute (NO-OP in binary)
01b0933a  MOV  EDX,[EAX + 0x84]              ; vtable+0x84 = WriteInt32
01b09340  LEA  ECX,[local_30]                ; Count address
01b09343  PUSH ECX
01b09346  CALL EDX                           ; *** WRITES COUNT ***
01b0934d  PUSH s_NbDynamicProperties
01b09354  CALL [vtable+0x10]                 ; EndAttribute (NO-OP)
```

**WRITE path in mode 3**: Writes NbDynamicProperties count to stream.

### READ Path (serializer+0x04 != 0)

The READ path at LAB_01b094d8:
```asm
LAB_01b094d8:
01b094d8  MOV  EDX,[ECX]                     ; Get serializer vtable
01b094da  MOV  EAX,[EDX + 0x1c]              ; vtable+0x1c = IsAtEnd
01b094dd  CALL EAX                           ; Check if at end
01b094df  TEST AL,AL
01b094e1  JNZ  LAB_01b095f2                  ; If at end, exit
; ... continues to read properties in loop ...
```

**READ path**: Uses `IsAtEnd` loop, does NOT read NbDynamicProperties count!

### Critical Finding

**The READ path does NOT read a count from the stream!** It iterates until `IsAtEnd()` returns true.

This means:
1. The "NbDynamicProperties" attribute is WRITE-ONLY in binary mode
2. The value at offset 0x16 (17 in our file) may be:
   - Written by WRITE path but never read by READ path
   - OR the format/mode differs from what we traced

### READ Path Property Loop (0x01b094e7)

```asm
LAB_01b094e7:                                ; Loop start
01b094e7  LEA  ECX,[local_11]                ; flags output
01b094eb  LEA  EDX,[local_24]                ; type desc output
01b094ee  PUSH EDX
01b094ef  LEA  EAX,[local_18]                ; property ID output
01b094f2  PUSH EAX
01b094f3  LEA  ECX,[local_1c]                ; property name output
01b094f6  XOR  ESI,ESI
01b094f8  PUSH ECX
01b094f9  MOV  ECX,EBX
01b094fb  MOV  [local_1c],ESI                ; Zero property name
01b094fe  MOV  [local_24],ESI                ; Zero type desc
01b09501  MOV  [local_20],ESI                ; Zero another field
01b09504  MOV  byte ptr [local_11],0x0       ; Zero flags
01b09508  CALL FUN_01b077d0                  ; *** Read property header ***
; ... processes property, calls FUN_01b0c2e0 ...
01b095e8  CALL [vtable+0x1c]                 ; IsAtEnd check
01b095ea  TEST AL,AL
01b095ec  JZ   LAB_01b094e7                  ; Loop if not at end
```

---

## Parser Test Results (January 2026)

### Summary

| Metric | Value |
|--------|-------|
| File Size | 1903 bytes |
| Properties Parsed | 15 |
| Final Position | 0x076B (1899 bytes) |
| Remaining Bytes | 4 |
| Parse Success Rate | ~99.8% |

### Properties Breakdown

| # | Offset | Property ID | Type | Value | Status |
|---|--------|-------------|------|-------|--------|
| 0 | 0x0016 | 0xBF4C2013 | 7 (UInt32) | 11 | OK (1 extra byte) |
| 1 | 0x002B | 0xF201D917 | 29 (MAP_ALT) | count=0 | OK |
| 2 | 0x0041 | 0xC021791A | 29 (MAP_ALT) | count=17 | 1445 bytes untraced |
| 3 | 0x05FC | 0x49B0B6FE | 29 (MAP_ALT) | count=0 | OK |
| 4 | 0x0612 | 0xA5D5C8DE | 29 (MAP_ALT) | count=3 | 12 bytes untraced |
| 5 | 0x0634 | 0xF6282AFE | 0 (NULL) | 1 | OK (1 extra byte) |
| 6 | 0x0646 | 0x9F1438A5 | 0 (NULL) | 1 | OK (1 extra byte) |
| 7 | 0x0658 | 0xAFBEEA25 | 0 (NULL) | 1 | OK (1 extra byte) |
| 8 | 0x066A | 0x221991EF | 0 (NULL) | 1 | OK (1 extra byte) |
| 9 | 0x067C | 0x20AD7434 | 0 (NULL) | 1 | OK (1 extra byte) |
| 10 | 0x068E | 0xB6BA16BB | 0 (NULL) | 1 | OK (1 extra byte) |
| 11 | 0x06A0 | 0x1A361AE1 | 0 (NULL) | 1 | OK (1 extra byte) |
| 12 | 0x06B2 | 0x605F5F37 | 9 (UInt64) | 11 | OK (1 extra byte) |
| 13 | 0x06CB | 0x25170D6B | 29 (MAP_ALT) | count=0 | OK |
| 14 | 0x06E1 | 0xD3ECF3B1 | 24 (MAP) | count=116 | 116 bytes untraced |

### Observations

1. **Extra bytes per property**: Many properties show 1 extra byte after the value
   - This occurs for NULL (type 0), UInt32 (type 7), and UInt64 (type 9)
   - The extra byte values are 0x00 or 0x01
   - **Hypothesis**: This may be a property terminator or trailing flag

2. **MAP/MAP_ALT entries**: 5 properties are MAP_ALT (type 29)
   - Property 2 has 17 nested entries (1445 bytes)
   - Property 4 has 3 nested entries (12 bytes)
   - Property 14 has 116 count (appears to be incorrect - 116 bytes data)

3. **Remaining 4 bytes**: File has 4 bytes after last property (0x076B to 0x076F)
   - May be file footer/checksum

---

## Gap Analysis Summary

### Fully Traced (COMPLETE)

| Function | Bytes | Purpose | Status |
|----------|-------|---------|--------|
| FUN_01b08ce0 | 14 | Object header | SKIPPED in binary mode |
| FUN_01b48890 | 4 | BeginSection | TRACED - reads exactly 4 bytes |
| FUN_01b077d0 | 12 | Property header (mode 3) | TRACED - ID(4) + TypeDesc(8) |
| FUN_01b0e980 | 8 | TypeDescriptor | TRACED |
| FUN_01b076f0 | 0 | PropertyHeaderFlag | SKIPPED in mode 3 |
| FUN_01b0c2e0 | var | Type dispatcher | TRACED - all 31 cases |
| All primitive types | 1-64 | Type handlers | TRACED |

### Partially Traced (GAPS REMAIN)

| Function | Issue | Bytes Unknown |
|----------|-------|---------------|
| FUN_01b091a0 | READ path behavior differs from WRITE path | Loop structure |
| FUN_01b0bcf0 | MAP element iteration not fully traced | Per-element structure |
| FUN_01afd600 | Entry point not traced | Initialization bytes |

### Unknown/Untraced

| Byte Range | Size | Hypothesis |
|------------|------|------------|
| Property trailing byte | 1B per property | Terminator or flag |
| MAP nested structure | Variable | Per-entry type descriptors |
| File footer (0x76B-0x76F) | 4 bytes | Checksum or padding |

### Root Cause Analysis (UPDATED January 2026)

**SOLVED: Extra bytes identified via binary analysis!**

The "extra bytes" appearing after each property value are now understood:

1. **NULL type (case 0)**: 2 bytes = inner_type + null_value
   - inner_type: wrapped type code (e.g., 0x0B = FLOAT64)
   - null_value: 0 = absent, 1 = present
   - Parser now handles this correctly

2. **Fixed types (UINT32, UINT64, etc.)**: value + 1 trailing byte (0x00)
   - Trailing byte is consistently 0x00
   - May be a terminator, null indicator, or padding
   - Needs FUN_01b12fa0 etc. decompilation to confirm source

3. **MAP/MAP_ALT types**: key_type (1B) + value_type (1B) + count (4B)
   - First byte is key type code
   - Second byte is value type code
   - Parser now handles this correctly

4. **File footer**: 4 zero bytes (0x076B-0x076E) outside dynamic section
   - May be "next section size = 0" indicator or terminator

### Remaining Gaps

1. **Trailing byte source**: Need to trace FUN_01b12fa0 to confirm where trailing 0x00 comes from
2. **FUN_01b09650**: Need full decompilation to confirm NULL reads inner_type before null_value
3. **MAP element parsing**: FUN_01b0bcf0 element iteration not fully traced

### Recommended Next Steps

1. **Priority 1**: Decompile FUN_01b09650 (NULL handler) to confirm inner_type + null_value structure
2. **Priority 2**: Decompile FUN_01b12fa0 (UInt32) to find trailing byte source
3. **Priority 3**: Trace FUN_01b0bcf0 MAP element deserialization loop
