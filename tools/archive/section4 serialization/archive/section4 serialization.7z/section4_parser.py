#!/usr/bin/env python3
"""
Section 4 Binary Parser - TRACED CODE ONLY

Based on decompiled functions from both Section 3 and Section 4 WinDbg TTD traces.
Section 3 and Section 4 use the SAME serialization system but different modes:
  - Section 3 (OPTIONS): Mode 0 (text-like) - includes property flags byte
  - Section 4 (MULTI PROFILE): Mode 3 (binary) - skips property flags

=== SERIALIZER MODE VTABLE (PTR_FUN_02555c60 / 0x02c35c60 WinDbg) ===
Offset | Ghidra Addr | Function      | Purpose
-------|-------------|---------------|----------------------------------------
0x00   | 02555c60    | FUN_01b49b10  | Destructor
0x08   | 02555c68    | LAB_01b48770  | StartElement (NO-OP in binary WRITE)
0x0c   | 02555c6c    | FUN_01b48890  | OpenSection - reads 4-byte section size
0x10   | 02555c70    | LAB_01b487a0  | EndElement (NO-OP in binary WRITE)
0x14   | 02555c74    | FUN_01b48920  | CloseSection - backpatches size
0x50   | 02555cb0    | FUN_01b48fb0  | TypeInfo serializer (4-byte hash)
0x54   | 02555cb4    | FUN_01b48e90  | String serializer (4-byte len + data)
0x58   | 02555cb8    | FUN_01b48e80  | Bool (1 byte) → FUN_01b49430
0x70   | 02555cd0    | FUN_01b48c10  | vec2 (8 bytes)
0x74   | 02555cd4    | FUN_01b48c00  | float32 (4 bytes) → FUN_01b49790
0x78   | 02555cd8    | FUN_01b48bf0  | float64 (8 bytes) → FUN_01b49730
0x7c   | 02555cdc    | FUN_01b48be0  | uint64 (8 bytes) → FUN_01b496d0
0x80   | 02555ce0    | FUN_01b48bd0  | int32 (4 bytes) → FUN_01b49670
0x84   | 02555ce4    | FUN_01b48bc0  | uint32 (4 bytes) → FUN_01b49610
0x88   | 02555ce8    | FUN_01b48bb0  | uint16 (2 bytes) → FUN_01b495b0
0x8c   | 02555cec    | FUN_01b48ba0  | int16 (2 bytes) → FUN_01b49550
0x90   | 02555cf0    | FUN_01b48b90  | uint8 (1 byte) → FUN_01b494f0
0x94   | 02555cf4    | FUN_01b48b80  | int8 (1 byte) → FUN_01b49490
0x98   | 02555cf8    | FUN_01b48b70  | WriteByte → FUN_01b49430
0x9c   | 02555cfc    | FUN_01b48e70  | uint32 (ObjectID) → FUN_01b49610

=== STREAM INNER VTABLE (PTR_FUN_02556168 / 0x02c36168 WinDbg) ===
Offset | Index | Purpose                | Read Function   | Write Function
-------|-------|------------------------|-----------------|----------------
0x0c   | [3]   | IsAtEnd               | LAB_01b6f010    | LAB_01b6f010
0x18   | [6]   | 8-byte read/write      | FUN_01b6f490    | FUN_01b6f4e0
0x1c   | [7]   | 4-byte read/write      | FUN_01b6f440    | FUN_01b6f4d0
0x20   | [8]   | 2-byte read            | FUN_01b6f400    | -
0x24   | [9]   | 1-byte read            | FUN_01b6f150    | -
0x28   | [10]  | N-byte read            | FUN_01b6f030    | -
0x34   | [13]  | 4-byte write           | -               | FUN_01b6fea0
0x3c   | [15]  | 1-byte write           | -               | FUN_01b6f370
0x40   | [16]  | N-byte write           | -               | FUN_01b6f3b0

=== KEY FUNCTIONS ===
- FUN_01b48890: BeginSection (vtable+0x0C) - reads EXACTLY 4 bytes (section size)
  * Binary mode: reads 4-byte section size via stream vtable+0x1c
  * Maintains depth counter at serializer+0x1010 (uint16)
  * Stores section size at [serializer + depth*8 + 0x10]

- FUN_01b077d0: Property header reader (CRITICAL - MODE DEPENDENT)
  * MODE 3 (binary): reads EXACTLY 12 BYTES total:
    - 4 bytes: Property ID via vtable+0x84
    - 8 bytes: Type Descriptor via FUN_01b0e980
    - PropertyHeaderFlag (FUN_01b076f0) is SKIPPED!
  * MODE 0 (text): reads property name, ID, type desc, AND flags

- FUN_01b0d140: Property header WRITER (Section 3 traced)
  * MODE 0: Writes [size 4][hash 4][type_info 8][flags 1][value N]
  * MODE 1/2/3: Returns early, skips writing header!

- FUN_01b0e980: TypeDescriptor reader (8 bytes via vtable+0x4c)
  * Reads 8 bytes: type_hash (4B) + type_info (4B)
  * Type code extraction: (type_info >> 16) & 0x3F

- FUN_01b076f0: PropertyHeaderFlag reader/writer
  * Version >= 11: 1 byte via vtable+0x98 (always 0x0b in Section 3)
  * SKIPPED in modes 1, 2, 3 (binary)

- FUN_01b0c2e0: Type dispatcher (31-way switch)
- FUN_01b11fb0: NULL handler (reads 1 byte via vtable+0x58)
- FUN_01b09650: Bool property serializer → FUN_01b11fb0
- FUN_01b09760: uint64 property serializer → FUN_01b124e0
- FUN_01b07b90: MAP count reader (4 bytes via vtable+0x84)
- FUN_01b0bcf0: MAP/MAP_ALT handler

BINARY MODE: ctx+0x58 == 3
- FUN_01b077d0 reads EXACTLY 12 bytes for property header (ID + TypeDesc)
- FUN_01b076f0 (property flags) is SKIPPED in binary mode!
- BeginSection reads EXACTLY 4 bytes (section_size), no extra bytes
"""

import struct
import sys
from dataclasses import dataclass
from typing import Any, Optional, List
from enum import IntEnum


class PropertyType(IntEnum):
    """
    Type codes from FUN_01b0c2e0 switch table (31 cases)

    Vtable offsets traced from Section 3 WinDbg TTD trace:
    - Primitives use vtable entries directly (e.g., vtable+0x58 for bool)
    - Complex types call dedicated handler functions
    """
    NULL = 0         # FUN_01b09650 → FUN_01b11fb0 (1 byte via vtable+0x58)
    BOOL = 1         # vtable+0x90 (1 byte)
    UINT8 = 2        # vtable+0x94 (1 byte)
    INT8 = 3         # vtable+0x98 (1 byte)
    UINT16 = 4       # vtable+0x88 (2 bytes)
    INT16 = 5        # vtable+0x8C (2 bytes)
    FLOAT32 = 6      # vtable+0x74 (4 bytes) - NOTE: swapped with INT32 in FUN_01b0c2e0
    UINT32 = 7       # vtable+0x84 (4 bytes)
    INT32 = 8        # vtable+0x80 (4 bytes)
    UINT64 = 9       # vtable+0x7C (8 bytes)
    INT64 = 10       # vtable+0x78 (8 bytes) - shares with FLOAT64 dispatcher
    FLOAT64 = 11     # vtable+0x70 (8 bytes)
    VECTOR2 = 12     # vtable+0x6C (8 bytes, 2 floats)
    VECTOR3 = 13     # vtable+0x68 (12 bytes, 3 floats + padding)
    VECTOR4 = 14     # vtable+0x5C (16 bytes, 4 floats)
    MATRIX3X3 = 15   # vtable+0x64 (36 bytes, 9 floats col-major)
    MATRIX4X4 = 16   # vtable+0x60 (64 bytes, 16 floats col-major)
    STRING = 17      # vtable+0x9C (4-byte hash only in binary mode)
    OBJECTREF = 18   # 0x12 - Object reference
    OBJECTREF_EMB = 19  # 0x13 - Embedded object reference
    ENUM = 20        # 0x14 - Enumeration
    STRUCT = 21      # 0x15 - Structure
    CLASS = 22       # 0x16 - Class object (nested serialization)
    ARRAY = 23       # 0x17 - FUN_01b07be0 (mode 3: skips count read)
    MAP = 24         # 0x18 - FUN_01b0bcf0 (2-byte prefix + 4-byte count)
    GUID = 26        # 0x1A - vtable+0x48 (variable ASCII)
    TIMESTAMP = 27   # 0x1B - vtable+0x44 (variable UTF-16)
    POINTER = 28     # 0x1C - FUN_01b0ae60 (recursive reference)
    MAP_ALT = 29     # 0x1D - FUN_01b0bcf0 (same handler as MAP)


# TRACED: Fixed-size types from vtable dispatch (Section 3 WinDbg TTD trace)
# Note: In MODE 3 (binary), fixed types have trailing 0x00 byte (terminator/padding)
TYPE_SIZES = {
    PropertyType.NULL: 1,    # FUN_01b11fb0: reads 1 byte via vtable+0x58 (null_value)
    PropertyType.BOOL: 1,    # vtable+0x90 → FUN_01b497f0 → inner_vtable[9]
    PropertyType.UINT8: 1,   # vtable+0x94 → FUN_01b494f0
    PropertyType.INT8: 1,    # vtable+0x98 → FUN_01b49490
    PropertyType.UINT16: 2,  # vtable+0x88 → FUN_01b495b0
    PropertyType.INT16: 2,   # vtable+0x8C → FUN_01b49550
    PropertyType.UINT32: 4,  # vtable+0x84 → FUN_01b49610 → inner_vtable[7]
    PropertyType.INT32: 4,   # vtable+0x80 → FUN_01b49670
    PropertyType.UINT64: 8,  # vtable+0x7C → FUN_01b496d0 → inner_vtable[6]
    PropertyType.INT64: 8,   # vtable+0x78 → FUN_01b49730
    PropertyType.FLOAT32: 4, # vtable+0x74 → FUN_01b49790
    PropertyType.FLOAT64: 8, # vtable+0x70 → FUN_01b49730 (same as INT64)
    PropertyType.VECTOR2: 8,    # vtable+0x6C → 2× inner_vtable[13] (2 floats)
    PropertyType.VECTOR3: 12,   # vtable+0x68 → 3× inner_vtable[13] (3 floats + pad)
    PropertyType.VECTOR4: 16,   # vtable+0x5C → 4× inner_vtable[13] (4 floats)
    PropertyType.MATRIX3X3: 36, # vtable+0x64 → 9× inner_vtable[13] (col-major)
    PropertyType.MATRIX4X4: 64, # vtable+0x60 → 16× inner_vtable[13] (col-major)
    PropertyType.STRING: 4,     # vtable+0x9C → 4-byte hash only in binary mode
}


@dataclass
class DynamicProperty:
    """Property structure based on traced code"""
    offset: int
    section_size: int
    property_id: int
    type_descriptor: bytes
    type_code: int
    value: Any
    raw_bytes: bytes


class Section4Parser:
    def __init__(self, data: bytes):
        self.data = data
        self.pos = 0
        self.size = len(data)

    def read_bytes(self, n: int) -> bytes:
        result = self.data[self.pos:self.pos + n]
        self.pos += n
        return result

    def read_uint8(self) -> int:
        return self.read_bytes(1)[0]

    def read_int32(self) -> int:
        return struct.unpack('<i', self.read_bytes(4))[0]

    def read_uint32(self) -> int:
        return struct.unpack('<I', self.read_bytes(4))[0]

    def is_at_end(self) -> bool:
        return self.pos >= self.size

    def parse_type_descriptor(self) -> tuple:
        """
        TRACED: FUN_01b0e980 reads 8 bytes via vtable+0x4c (Section 3 TTD trace)

        Section 3 WinDbg Trace (E68A1B:2D0):
          - Version check: [ECX + 0x24] >= 9 → current path (direct 8-byte)
          - Version < 9: legacy path with FUN_01b0e3d0 conversion
          - vtable[0x08]("Type") → StartElement (NO-OP in binary)
          - vtable[0x4c](format, &local_c) → FUN_01b49020 → FUN_01b496d0
          - vtable[0x10]("Type") → EndElement (NO-OP in binary)

        Type code extraction (via FUN_01b0e3d0 bit masks):
          - (type_info >> 16) & 0x3F = primary type code (bits 16-21)
          - (type_info >> 23) & 0x3F = element/value type for containers (bits 23-28)

        Returns:
          (raw_bytes, type_code, type_hash, element_type)
        """
        raw = self.read_bytes(8)
        # First 4 bytes = type_hash, second 4 bytes = type_info
        type_hash = struct.unpack('<I', raw[0:4])[0]
        type_info = struct.unpack('<I', raw[4:8])[0]
        # Extract type code from bits 16-21 (mask 0x3F0000)
        type_code = (type_info >> 16) & 0x3F
        # Extract element/value type from bits 23-28 (for containers)
        element_type = (type_info >> 23) & 0x3F
        return raw, type_code, type_hash, element_type

    def parse_value(self, type_code: int, bytes_remaining: int, element_type: int = 0, type_hash: int = 0) -> tuple:
        """
        TRACED: FUN_01b0c2e0 type dispatch (31-way switch)

        Section 3 TTD Trace confirms:
          - Each type code dispatches to a specific vtable entry or handler function
          - Primitives use vtable entries (e.g., case 0x07 → vtable+0x84 for uint32)
          - Complex types call dedicated functions (e.g., case 0x18 → FUN_01b0bcf0 for MAP)
          - Mode 3 (binary) has simplified paths without XML element markers

        Returns (value, bytes_consumed)

        Args:
            type_code: Primary type from (type_info >> 16) & 0x3F
            bytes_remaining: Section size minus header bytes
            element_type: For containers, from (type_info >> 23) & 0x3F
            type_hash: Type hash for objects with class type
        """
        start_pos = self.pos

        # TRACED: Case 0 - FUN_01b09650 → FUN_01b11fb0
        # Binary analysis shows NULL reads 2 bytes total:
        # - Byte 1: Inner type code (the wrapped type, e.g., 0x0B = FLOAT64)
        # - Byte 2: Null value (0 = absent, 1 = present)
        # NOTE: FUN_01b09650 needs full decompilation to confirm structure
        if type_code == PropertyType.NULL:
            # Read inner type code (wrapped type)
            inner_type = self.read_uint8()
            # Read null value (0 or 1)
            null_value = self.read_uint8()
            bytes_consumed = 2

            value = {
                'inner_type': inner_type,
                'inner_type_name': PropertyType(inner_type).name if inner_type < 32 else f'UNKNOWN_{inner_type}',
                'is_present': null_value != 0
            }

            return value, bytes_consumed

        # TRACED: Fixed-size types via vtable dispatch
        # Binary analysis shows fixed types have trailing byte (always 0x00)
        # This may be a null indicator or terminator - needs FUN_01b12fa0 trace to confirm
        elif type_code in TYPE_SIZES:
            size = TYPE_SIZES[PropertyType(type_code)]
            raw = self.read_bytes(size)

            if type_code == PropertyType.BOOL:
                value = bool(raw[0])
            elif type_code == PropertyType.UINT8:
                value = raw[0]
            elif type_code == PropertyType.INT8:
                value = struct.unpack('<b', raw)[0]
            elif type_code == PropertyType.UINT16:
                value = struct.unpack('<H', raw)[0]
            elif type_code == PropertyType.INT16:
                value = struct.unpack('<h', raw)[0]
            elif type_code == PropertyType.UINT32:
                value = struct.unpack('<I', raw)[0]
            elif type_code == PropertyType.INT32:
                value = struct.unpack('<i', raw)[0]
            elif type_code == PropertyType.UINT64:
                value = struct.unpack('<Q', raw)[0]
            elif type_code == PropertyType.INT64:
                value = struct.unpack('<q', raw)[0]
            elif type_code == PropertyType.FLOAT32:
                value = struct.unpack('<f', raw)[0]
            elif type_code == PropertyType.FLOAT64:
                value = struct.unpack('<d', raw)[0]
            elif type_code == PropertyType.STRING:
                value = struct.unpack('<I', raw)[0]  # Hash
            else:
                value = raw.hex()

            bytes_consumed = size

            # Read trailing byte if present (observed: always 0x00 for fixed types)
            # NOTE: Need to trace FUN_01b12fa0 etc. to confirm this is part of format
            if bytes_remaining > size:
                trailing = self.read_uint8()
                bytes_consumed += 1
                if trailing != 0:
                    print(f"    Type {type_code}: unexpected trailing byte 0x{trailing:02X} (expected 0x00)")

            return value, bytes_consumed

        # TRACED: Case 0x18/0x1D - MAP/MAP_ALT
        # Binary analysis:
        # - 0x0B byte: format marker (like other section markers)
        # - 0x01 byte: value/flag
        # - 4 bytes: count
        # - entries: element_type from type_info bits 23-28 determines size
        elif type_code == PropertyType.MAP or type_code == PropertyType.MAP_ALT:
            # Read marker and flag bytes
            marker = self.read_uint8()  # Usually 0x0B
            flag = self.read_uint8()    # Usually 0x01

            # TRACED: FUN_01b07b90 reads count via vtable+0x84 (4 bytes)
            count = self.read_int32()

            bytes_consumed = 2 + 4  # marker + flag + count

            # Get element size from element_type (from type_info bits 23-28)
            try:
                element_type_name = PropertyType(element_type).name
            except ValueError:
                element_type_name = f'UNKNOWN_{element_type}'

            try:
                elem_size = TYPE_SIZES.get(PropertyType(element_type), 0)
            except ValueError:
                elem_size = 0

            # Parse entries
            entries = []
            entry_data_size = bytes_remaining - bytes_consumed

            if count > 0 and elem_size > 0:
                # Fixed-size elements
                for i in range(count):
                    if elem_size == 1:
                        entries.append(self.read_uint8())
                    elif elem_size == 4:
                        val = self.read_uint32()
                        entries.append(f'0x{val:08X}')  # Show as hex for readability
                    elif elem_size == 8:
                        val = struct.unpack('<Q', self.read_bytes(8))[0]
                        entries.append(f'0x{val:016X}')
                    else:
                        entries.append(self.read_bytes(elem_size).hex())
                bytes_consumed += count * elem_size
            elif count > 0 and element_type == PropertyType.CLASS:  # CLASS - variable size
                # Parse nested CLASS entries
                # Structure: 10-byte key + 4-byte type_hash + 4-byte content_size + 4-byte prop_size + nested properties
                entries = []
                entry_size = entry_data_size // count if count > 0 else 0

                for entry_idx in range(count):
                    entry_start = self.pos

                    # Read entry header
                    entry_key = self.read_bytes(10)  # 10-byte key (usually zeros)
                    entry_type_hash = self.read_uint32()
                    entry_content_size = self.read_uint32()
                    entry_prop_size = self.read_uint32()

                    # Parse nested properties
                    nested_props = []
                    prop_end = self.pos + entry_prop_size

                    while self.pos < prop_end and self.pos < entry_start + entry_size - 4:
                        prop_section_size = self.read_int32()
                        if prop_section_size <= 0 or prop_section_size > 100:
                            break

                        prop_id = self.read_uint32()
                        prop_type_hash = self.read_uint32()
                        prop_type_info = self.read_uint32()
                        prop_type_code = (prop_type_info >> 16) & 0x3F

                        # Read value (section_size - 12 bytes of header)
                        value_size = prop_section_size - 12
                        if value_size > 0:
                            prop_value = self.read_bytes(value_size)
                        else:
                            prop_value = b''

                        nested_props.append({
                            'prop_id': f'0x{prop_id:08X}',
                            'type': prop_type_code,
                            'value': prop_value.hex()
                        })

                    # Skip any remaining bytes in entry
                    remaining = entry_start + entry_size - self.pos
                    if remaining > 0:
                        self.read_bytes(remaining)

                    entries.append({
                        'type_hash': f'0x{entry_type_hash:08X}',
                        'properties': nested_props
                    })

                bytes_consumed += entry_data_size
            elif count > 0:
                # Unknown element type - read raw
                raw_entries = self.read_bytes(entry_data_size)
                entries = f'<{count} raw entries: {raw_entries[:32].hex()}...>'
                bytes_consumed += entry_data_size

            value = {
                'marker': marker,
                'flag': flag,
                'element_type': element_type,
                'element_type_name': element_type_name,
                'count': count,
                'entries': entries
            }

            return value, bytes_consumed

        # TRACED: Case 0x17 - ARRAY
        # FUN_01b07be0 in mode 3 (binary) does NOT read the array count!
        # It skips directly to BeginAttribute("Values") which is a NO-OP
        # The count must be passed in from elsewhere (FUN_01b0c2e0 case 0x17)
        elif type_code == PropertyType.ARRAY:
            # TRACED: In mode 3, count comes from outer context, not read here
            # The count was read by FUN_01b0c2e0 before calling FUN_01b07be0
            print(f"    ARRAY: In mode 3, count not read by FUN_01b07be0 (passed from caller)")
            return f'<ARRAY: count from caller, elements follow>', 0

        # Other complex types
        else:
            print(f"    Type {type_code}: NEED handler function decompiled")
            return f'<NEED_TRACE: type {type_code}>', 0

    def parse_property(self) -> Optional[DynamicProperty]:
        """
        TRACED: FUN_01b077d0 for binary mode (ctx+0x58 == 3)

        Section 3 TTD Trace (FUN_01b0d140 - Property Header Writer):
          - MODE 0: Writes [size 4][hash 4][type_info 8][flags 1][value N]
          - MODE 1/2/3: Returns early at check for iVar3 == 1/2/3, skips writing!

        For READ path in MODE 3 (binary), FUN_01b077d0 reads EXACTLY 12 BYTES:

        1. BeginSection - EXACTLY 4 bytes (section_size) via vtable+0x0C (FUN_01b48890)
           - FUN_01b48890 reads via stream vtable+0x1c (inner_vtable[7])
           - Stores size at [serializer + depth*8 + 0x10]
           - Increments depth counter at serializer+0x1010
           - NO extra bytes read by BeginSection!

        2. Property Header (FUN_01b077d0 from LAB_01b07831):
           - PropertyID: 4 bytes via vtable+0x84 (FUN_01b49610)
           - TypeDescriptor: 8 bytes via FUN_01b0e980

        3. SKIPPED in mode 3 (jump at 01b07890 to LAB_01b07932):
           - PropertyHeaderFlag via FUN_01b076f0 is NOT called!
           - In MODE 0 (Section 3), this writes 0x0b flags byte

        4. Value - variable via FUN_01b0c2e0

        Total header: 4 (section) + 4 (ID) + 8 (TypeDesc) = 16 bytes before value
        Property header portion: 12 bytes (ID + TypeDesc, no flags)
        """
        if self.is_at_end():
            return None

        prop_offset = self.pos

        # TRACED: BeginSection via vtable+0x0c (FUN_01b48890) reads 4-byte section size
        section_size = self.read_int32()
        section_end = self.pos + section_size

        # TRACED: FUN_01b077d0 from LAB_01b07831 (both modes converge here)
        # PropertyID via vtable+0x84 reads 4 bytes
        property_id = self.read_uint32()

        # TRACED: FUN_01b0e980 reads 8-byte TypeDescriptor
        type_desc, type_code, type_hash, element_type = self.parse_type_descriptor()

        # TRACED: Mode 3 SKIPS PropertyHeaderFlag (FUN_01b076f0)!
        # Jump at 01b07890 goes directly to LAB_01b07932, bypassing flags read
        # NO flags byte is read in binary mode!

        # Calculate bytes remaining for value
        # Property header in mode 3 = ID(4) + TypeDesc(8) = 12 bytes, no flags
        bytes_consumed = 4 + 8  # ID + TypeDesc (NO flags in mode 3!)
        bytes_remaining = section_size - bytes_consumed

        # TRACED: FUN_01b0c2e0 dispatches based on type
        value, value_bytes = self.parse_value(type_code, bytes_remaining, element_type, type_hash)

        # Skip to section end (handles any untraced trailing bytes)
        if self.pos != section_end:
            skipped = section_end - self.pos
            if skipped > 0:
                skip_data = self.read_bytes(skipped)
                print(f"    Skipping {skipped} untraced bytes: {skip_data.hex()}")
            self.pos = section_end

        raw_bytes = self.data[prop_offset:self.pos]

        return DynamicProperty(
            offset=prop_offset,
            section_size=section_size,
            property_id=property_id,
            type_descriptor=type_desc,
            type_code=type_code,
            value=value,
            raw_bytes=raw_bytes,
        )

    def parse(self) -> dict:
        """Parse Section 4 structure

        File format (observed, NEED TO TRACE entry point):
        - 0x0000: 10 bytes unknown prefix
        - 0x000A: 4 bytes header_type
        - 0x000E: 4 bytes field_0x04
        - 0x0012: 4 bytes section_size (BeginSection for properties)
        - 0x0016: properties start
        """
        # 10-byte zero prefix from LZSS decompression (not Section 4 data)
        prefix = self.read_bytes(10)
        if prefix != b'\x00' * 10:
            print(f"WARNING: Expected 10 zero bytes from LZSS, got: {prefix.hex()}")

        # Header type hash
        header_type = self.read_uint32()

        # field_0x04
        field_0x04 = self.read_uint32()

        # Dynamic properties section (BeginSection)
        dyn_section_size = self.read_int32()
        dyn_section_end = self.pos + dyn_section_size

        print(f"Header type: 0x{header_type:08X}")
        print(f"field_0x04: {field_0x04}")
        print(f"Dynamic section: {dyn_section_size} bytes (0x{self.pos:04X} to 0x{dyn_section_end:04X})")
        print()

        properties = []
        prop_num = 0

        while self.pos < dyn_section_end:
            print(f"Property {prop_num} at 0x{self.pos:04X}:")
            prop = self.parse_property()
            if prop is None:
                break
            properties.append(prop)
            print(f"  ID=0x{prop.property_id:08X}, type={prop.type_code}, value={prop.value}")
            print()
            prop_num += 1

        return {
            'header_type': header_type,
            'field_0x04': field_0x04,
            'dyn_section_size': dyn_section_size,
            'properties': properties,
            'final_pos': self.pos,
            'file_size': self.size,
        }


class Section4Serializer:
    """Serializer for Section 4 binary format - mirrors parser structure"""

    def __init__(self):
        self.buffer = bytearray()

    def write_bytes(self, data: bytes):
        self.buffer.extend(data)

    def write_uint8(self, value: int):
        self.buffer.append(value & 0xFF)

    def write_uint16(self, value: int):
        self.buffer.extend(struct.pack('<H', value))

    def write_int32(self, value: int):
        self.buffer.extend(struct.pack('<i', value))

    def write_uint32(self, value: int):
        self.buffer.extend(struct.pack('<I', value))

    def write_uint64(self, value: int):
        self.buffer.extend(struct.pack('<Q', value))

    def serialize_value(self, type_code: int, value: Any, element_type: int = 0, type_hash: int = 0) -> bytes:
        """Serialize a value based on type code"""
        buf = bytearray()

        # NULL type: inner_type + null_value
        if type_code == PropertyType.NULL:
            buf.append(value['inner_type'])
            buf.append(1 if value['is_present'] else 0)

        # Fixed types with trailing byte
        elif type_code in TYPE_SIZES:
            size = TYPE_SIZES[PropertyType(type_code)]

            if type_code == PropertyType.BOOL:
                buf.append(1 if value else 0)
            elif type_code == PropertyType.UINT8:
                buf.append(value & 0xFF)
            elif type_code == PropertyType.INT8:
                buf.extend(struct.pack('<b', value))
            elif type_code == PropertyType.UINT16:
                buf.extend(struct.pack('<H', value))
            elif type_code == PropertyType.INT16:
                buf.extend(struct.pack('<h', value))
            elif type_code == PropertyType.UINT32:
                buf.extend(struct.pack('<I', value))
            elif type_code == PropertyType.INT32:
                buf.extend(struct.pack('<i', value))
            elif type_code == PropertyType.UINT64:
                buf.extend(struct.pack('<Q', value))
            elif type_code == PropertyType.INT64:
                buf.extend(struct.pack('<q', value))
            elif type_code == PropertyType.FLOAT32:
                buf.extend(struct.pack('<f', value))
            elif type_code == PropertyType.FLOAT64:
                buf.extend(struct.pack('<d', value))
            elif type_code == PropertyType.STRING:
                buf.extend(struct.pack('<I', value))

            # Add trailing byte
            buf.append(0x00)

        # MAP/MAP_ALT types
        elif type_code == PropertyType.MAP or type_code == PropertyType.MAP_ALT:
            buf.append(value['marker'])
            buf.append(value['flag'])
            buf.extend(struct.pack('<i', value['count']))

            entries = value['entries']
            if isinstance(entries, list):
                if value['count'] > 0 and element_type == PropertyType.CLASS:
                    # Serialize CLASS entries
                    for entry in entries:
                        buf.extend(self.serialize_class_entry(entry))
                elif value['count'] > 0:
                    # Serialize fixed-type entries
                    for entry in entries:
                        if isinstance(entry, str) and entry.startswith('0x'):
                            # Hex string
                            val = int(entry, 16)
                            try:
                                elem_size = TYPE_SIZES.get(PropertyType(element_type), 4)
                            except ValueError:
                                elem_size = 4
                            if elem_size == 1:
                                buf.append(val & 0xFF)
                            elif elem_size == 4:
                                buf.extend(struct.pack('<I', val))
                            elif elem_size == 8:
                                buf.extend(struct.pack('<Q', val))
                        elif isinstance(entry, int):
                            # Integer value
                            try:
                                elem_size = TYPE_SIZES.get(PropertyType(element_type), 4)
                            except ValueError:
                                elem_size = 4
                            if elem_size == 1:
                                buf.append(entry & 0xFF)
                            elif elem_size == 4:
                                buf.extend(struct.pack('<I', entry))
                            elif elem_size == 8:
                                buf.extend(struct.pack('<Q', entry))

        return bytes(buf)

    def serialize_class_entry(self, entry: dict) -> bytes:
        """Serialize a CLASS entry (85-byte nested object)"""
        buf = bytearray()

        # Key: 10 zero bytes
        buf.extend(b'\x00' * 10)

        # Type hash
        type_hash = int(entry['type_hash'], 16)
        buf.extend(struct.pack('<I', type_hash))

        # Serialize nested properties to calculate sizes
        props_buf = bytearray()
        for prop in entry['properties']:
            prop_buf = self.serialize_nested_property(prop)
            props_buf.extend(prop_buf)

        # Content structure: prop_data_size (4) + prop_data (N) + padding (4)
        # Total entry = 10 (key) + 4 (type_hash) + 4 (content_size) + content = 85 bytes
        # So content = 85 - 18 = 67 bytes
        # content_size = prop_data_size_field (4) + props + padding (4)
        content_size = 4 + len(props_buf) + 4  # prop_size field + props + trailing padding
        buf.extend(struct.pack('<I', content_size))

        # Property data size
        buf.extend(struct.pack('<I', len(props_buf)))

        # Properties
        buf.extend(props_buf)

        # Pad to 85 bytes
        while len(buf) < 85:
            buf.append(0x00)

        return bytes(buf[:85])

    def serialize_nested_property(self, prop: dict) -> bytes:
        """Serialize a nested property within a CLASS entry"""
        buf = bytearray()

        # Parse property values
        prop_id = int(prop['prop_id'], 16)
        type_code = prop['type']
        value_hex = prop['value']

        # Build property content (without section_size)
        content = bytearray()
        content.extend(struct.pack('<I', prop_id))
        content.extend(struct.pack('<I', 0))  # type_hash always 0
        content.extend(struct.pack('<I', type_code << 16))  # type_info
        content.extend(bytes.fromhex(value_hex))

        # Write section_size + content
        buf.extend(struct.pack('<I', len(content)))
        buf.extend(content)

        return bytes(buf)

    def serialize_property(self, prop: DynamicProperty, element_type: int = 0, type_hash: int = 0) -> bytes:
        """Serialize a single property"""
        # Get type_hash and element_type from type_descriptor
        td = prop.type_descriptor
        th = struct.unpack('<I', td[0:4])[0]
        ti = struct.unpack('<I', td[4:8])[0]
        et = (ti >> 23) & 0x3F

        # Serialize the value
        value_bytes = self.serialize_value(prop.type_code, prop.value, et, th)

        # Build property content
        content = bytearray()
        content.extend(struct.pack('<I', prop.property_id))
        content.extend(prop.type_descriptor)
        content.extend(value_bytes)

        # Build full property with section_size
        result = bytearray()
        result.extend(struct.pack('<i', len(content)))
        result.extend(content)

        return bytes(result)

    def serialize(self, parsed: dict) -> bytes:
        """Serialize a parsed Section 4 structure back to binary"""
        self.buffer = bytearray()

        # 10-byte zero prefix
        self.write_bytes(b'\x00' * 10)

        # Header type
        self.write_uint32(parsed['header_type'])

        # field_0x04
        self.write_uint32(parsed['field_0x04'])

        # Serialize all properties first to get total size
        props_data = bytearray()
        for prop in parsed['properties']:
            td = prop.type_descriptor
            ti = struct.unpack('<I', td[4:8])[0]
            et = (ti >> 23) & 0x3F
            th = struct.unpack('<I', td[0:4])[0]
            props_data.extend(self.serialize_property(prop, et, th))

        # Write section size
        self.write_int32(len(props_data))

        # Write properties
        self.write_bytes(props_data)

        # 4-byte footer
        self.write_bytes(b'\x00' * 4)

        return bytes(self.buffer)


def roundtrip_test(filename: str) -> bool:
    """Test roundtrip: parse -> serialize -> compare"""
    with open(filename, 'rb') as f:
        original = f.read()

    print(f"Roundtrip test for {filename}")
    print("=" * 60)

    # Parse
    parser = Section4Parser(original)
    parsed = parser.parse()

    print()
    print("Serializing...")

    # Serialize
    serializer = Section4Serializer()
    serialized = serializer.serialize(parsed)

    # Compare
    print(f"Original size:   {len(original)} bytes")
    print(f"Serialized size: {len(serialized)} bytes")

    if original == serialized:
        print("ROUNDTRIP SUCCESS: Files are identical!")
        return True
    else:
        # Find first difference
        min_len = min(len(original), len(serialized))
        for i in range(min_len):
            if original[i] != serialized[i]:
                print(f"ROUNDTRIP FAILED: First difference at offset 0x{i:04X}")
                print(f"  Original:   0x{original[i]:02X}")
                print(f"  Serialized: 0x{serialized[i]:02X}")
                # Show context
                start = max(0, i - 8)
                end = min(min_len, i + 8)
                print(f"  Original context:   {original[start:end].hex()}")
                print(f"  Serialized context: {serialized[start:end].hex()}")
                break
        else:
            if len(original) != len(serialized):
                print(f"ROUNDTRIP FAILED: Size mismatch")

        # Save serialized for comparison
        out_file = filename.replace('.bin', '_serialized.bin')
        with open(out_file, 'wb') as f:
            f.write(serialized)
        print(f"Serialized output saved to: {out_file}")

        return False


def main():
    if len(sys.argv) < 2:
        print("Usage: python section4_parser.py <file.bin> [--roundtrip]")
        sys.exit(1)

    filename = sys.argv[1]
    do_roundtrip = '--roundtrip' in sys.argv

    with open(filename, 'rb') as f:
        data = f.read()

    print(f"Parsing {filename} ({len(data)} bytes)")
    print("=" * 60)
    print()

    parser = Section4Parser(data)
    result = parser.parse()

    print("=" * 60)
    print(f"Properties parsed: {len(result['properties'])}")
    print(f"Final position: 0x{result['final_pos']:04X} / 0x{result['file_size']:04X}")

    remaining = result['file_size'] - result['final_pos']
    if remaining > 0:
        print(f"Remaining: {remaining} bytes")

    if do_roundtrip:
        print()
        roundtrip_test(filename)


if __name__ == '__main__':
    main()
